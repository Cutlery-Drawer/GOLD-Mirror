#define PS_EOF          0  // (EOF)
#define PS_ERROR        1  // (Error)
#define PS_WHITESPACE   2  // (Whitespace)
#define PS_COMMENTEND   3  // (Comment End)
#define PS_COMMENTLINE  4  // (Comment Line)
#define PS_COMMENTSTART 5  // (Comment Start)
#define PS_NUMBER       6  // Number
#define PS_WORD         7  // Word
#define PS_MAIN         8  // <Main>
#define PS_RNUMBER		9  // <Number>
#define PS_VALUE        10 // <Value>
#define PS_RWORD		11 // <Word>
