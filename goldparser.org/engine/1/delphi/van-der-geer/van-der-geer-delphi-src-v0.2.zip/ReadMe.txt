24 April 2002

GOLDParser Delphi version!

Version: Alpha 0.2



How to install:

Extract the files to a directory, and install GOLDParserD6.dpk (open this file in delphi, click compile and then install)



You can use the GOLDParser Delphi version in 2 ways:

Via the component, or the GOLDParser.pas file. Both have the same result. Its just a matter of tast wich one to use.



More documentation will follow soon!



Martin van der Geer

Beany@cloud.demon.nl