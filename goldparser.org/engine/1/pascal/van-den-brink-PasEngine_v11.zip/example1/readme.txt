===============================================================================
PASPARSE
===============================================================================
(c) Rob F.M. van den Brink
R.F.M.vandenBrink@hccnet.nl
aug, 2006



This is a simple example of how to use the inline parser engine, as defined by
Pascal_Engine.pgt, and what output it will generate.
The program can read simple pascal statements, and dumps the tokens and rules
as soon as the are recognized. (Only usefull for demonstration purposes).

USAGE 1:	PasParse.exe test.pas 
USAGE 2:	PasParse.exe test.pas test.out



FILES
-------------------------------------------------------------------------------
..\Pascal_Engine.pgt	-- program template, 
PasParse.grm	-- grammar file for this example
PasParse.bat	-- batch file to do the conversion (set path to gold directories first()

PasParse.cgt	-- result of converting the grammer into a cgt file
PasParse.pas	-- result of converting the cgt+pgt file into a program
PasParse.exe	-- result of compiling pascal program
test.pas	-- test file, based on grammer of the GNU pascal compiler
test.out	-- result from calling "PasParse.exe test.y test.out"
-------------------------------------------------------------------------------




