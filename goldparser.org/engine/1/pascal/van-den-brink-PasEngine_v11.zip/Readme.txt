-------------------------------------------------------------------------------
AN INLINE ENGINE FOR THE GOLDPARSER, TO GENERATE (OBJECT) PASCAL CODE
-------------------------------------------------------------------------------
(c) Rob F.M. van den Brink, The Netherlands
R.F.M.vandenBrink@hccnet.nl
Aug, 2006

Pascal_Engine.pgt, Version 1.1

(for compilers like Delphi, Virtual Pascal, Free Pascal)




VERSION HISTORY 
(V1.1, Aug 2006)
- BugFix: Lexer did not handle comments correctly
- Added:  multiple comment tags
- Added:  LexTable with lexemes, to improve readability of error messages
- Added:  Directive 'IsDELPHI' to compile under Delphi 7 too, (changefile extention to 'dpr')
- Added:  Several refinements
(V1.0, June 2006)
- first release




SUMMARY

The template creates a full-functioning program that does not require you to load 
a Compiled Grammar Table file. It generates an inline parser engine, in (object) 
pascal code, with full support of error recovery by means of error productions.
The lexer and parser are fully embedded in the rest of your code, so that 
other modules are not required anymore.
The resulting code can be compiled directly into a stand-alone program with 
a good Object Pascal compiler (like Virtual Pascal or Delphi). 
I have tested it with the following compilers:
	"virtual-pascal" (www.vpascal.com - freeware)
	"Delphi 7.0" (www.borland.com - payware)
	"free-pascal" (www.freepascal.org - freeware)
It should work with Kylix and GNU pascal as well, but this has not been verified.
Virtual Pascal and Delphi are highly recommended since these are stable compilers, 
producing compact and efficient code. Virtual Pascal is completely free, and comes 
with a powerfull debugger (but its website appeared to be down for a while).




USAGE
The associate examples illustrate how to use this engine.

Example1, uses the engine without any modification. The resulting progam will 
read an input file (specified on the command line) with simple pascal statements,
and emits the tokens and associated actions to the screen.
The emitted pascal code has already lots of comments on board, so it should not
be difficult to tailor the output to your own needs, since each application is 
different. 

Example2, is more advanced, but still uses the engine without any modification.
It generates a parser that can read 99% of the statements allowed in Delphi 7.0. 
The grammar has a few error productions to demonstrate the concept.

Example3, is also advanced, and uses a taylored version of the program template.
The resulting program can read a Yacc or Bison grammar, and emits the same
grammar in a near goldparser format. It shows how to implement actions.




WHAT MAKES AN INLINE PARSER ENGINE SO DIFFERENT AND ATTRACTIVE?

The many examples provided with GoldParser give the impression that when a parser 
is generated from a PGT program template, several additional files are to be 
linked with your code. This includes (a) a binary CGT file with tables, and (b) 
a separate engine (eg a *.dll library) that can read and parse accoring to that
CGT file.
Such an approach is inconvenient, and causes lots of unnecesairy overhead. It 
means that each time you run your program, your code has to read a CGT file 
first, and has to fill a table with it, before it can perform its primary task:
parsing. No need to explain that this is not only inefficient, but the code size
increases significantly as well.
However it reflects some of the history of how GoldParser has grown into its 
current state.

Fortunately, the capabilities of the PGT format for emitting code are rich 
enough to do a much better job: direct generation of an INLINE parser and lexer. 
This means that if GoldParser has to generate (object) Pascal code, the code and 
all associated tables are embedded in the same file. By doing so, the full power 
of your compiler can be used to make the code as lean and fast as possible. 
In addition, you can skip a lot of documentation on how to interface with an *.dll 
file and how to call all kinds of routines or so: its all solved by a single program 
template!

I have worked this out for Object Pascal, but I am convinced that it should be 
possible to follow the same approach for generating inline engines for C+ as well, 
or for any other mature programming language.




MANDATORY ADDITIONS TO YOUR GRAMMAR

The engine adds a few capabilities, that are currently not supported by GoldParser.
This includes 'nested comments' and 'error productions'. This wil be explained below
Your grammar is free to use or ignore it, but when not used, a few terminals
have to be declared in your grammar:
	CommentStart1	as "virtual terminal" (when not used) or as true terminal
	CommentEnd1	as "virtual terminal" (when not used) or as true terminal
	CommentStart2	as "virtual terminal" (when not used) or as true terminal
	CommentEnd2	as "virtual terminal" (when not used) or as true terminal
	SynError	always as "virtual terminal"
This wil be explained below




USING NESTED COMMENT BLOCKS

Languages like pascal have different means for inserting block comments:
	{ ..... } 
	(* ..... *) 
It depends on the dialect being used, how the compiler behaves when mixing these
comments, or when nesting them. For instance
   A:	(* braces like { and } are used for comments *)
   B:	{  you can also use (* and *) for comments }
   C:	{  braces like { and } are used for comments }
In Goldparser you may specifcy this as 
	Comment Start =  '{' | '(*'
	Comment End   =  '}' | '*)'
but then the nesting fails and '*)' will terminate a comment startiung with '{'
Therefore the tokenizer in the engine recognizes different lexemes for comment,
to keep them separated. Comment type A and B are handled correctly when
specified as
	"Virtual Terminals" = SynError CommentStart2 CommentEnd2
	Comment Start =  '{' 
	Comment End   =  '}' 
	CommentStart1 =  '(*'
	CommentEnd1   =  '*)'
Or when '[:' and ':]' is also available for comment
	"Virtual Terminals" = SynError 
	Comment Start =  '{' 
	Comment End   =  '}' 
	CommentStart1 =  '(*'
	CommentEnd1   =  '*)'
	CommentStart2 =  '[:'
	CommentEnd2   =  ':]'
Mark then when the terminals 'CommentStart2' and 'CommentEnd2' are not defined, you should
define them as virtual terminal.
In both examples comment type C is not supported, but when you define the compiler
directive 'IsNESTED' inside the engine, a true unlimited nesting is feasible
	  {$DEFINE  IsNESTED}       
	  
	  


USING ERROR PRODUCTIONS

The engine supports "error productions" as a convenient mechanism to recover from 
errors. The magic trick is to extend the list of rules by recovery rules, using 
the virtual terminals "SynError". For instance in the following two example fragments

	<Statement>	::= <Label> <Statement>
			  | <AssignmentStmt>
			  | <AssemblerStmt>
			  |  SynError
			  |

	<AssemblerStmt>	::= ASM <AsmLanguage> END
			  | ASM SynError END

In case a syntax error occurs in the middle of a <statement>, the error will be 
reported. In stead of an emergency stop, the parser will try to recover from 
a syntax error by invalidating several tokens that have been read, as well as 
several others that are still to be read. This invalidation process proceeds
until tokens are found that demarcate the end of the previous <statement> and 
the beginning of a next statement. 
The error "production" will now reduce all these invalidated tokens into a
single "SynError", as if a "valid" <statement> has been discovered. 
This may sufficiently please other rules, so when the parser proceeds from that. 
it has a good change that it has recovered, and can report other syntax errors 
as well. If this still fails, the invalidation process will be repeated as often
as required. This is often better than a full stop of the parsing process.
See and play with the examples to get this understood.




ONE PARSER ENGINE FOR ALL PASCAL PROGRAMS?

Well I don't think so. The range of applications that needs some parsing is too 
wide for that. In addition, the current version of GoldParser (and many other 
parser generators) is not well equipped to parse input streams with changing 
lexical and syntactical characteristics. 
This is more common then you may think at a first glance. Suppose you have to 
parse a valid program that can be handled by compilers like Delphi or Virtual 
Pascal. It has:
	(a) pascal lexemes like 'IF', 'THEN', 'Integer'
	(b) nested comment {like {it's is shown} here}, restricted to the 
	    lexemes '{' and '}'
	(c) compiler directives like {$IFDEF Delphi then insert some extra code}
	(d) inline assembler lexemes like 'eax', 'mov', 'call', 'jne'
A parser that handles this all has to switch all the time between different 
lexical readers to understand that for instance 'mov' is an identifier in (a), 
are just some irrelevant characters in (b) and (c) and is a keyword in (d). 
Moreover the "'" in example (b) should not be interpreted as the beginning of 
a string, and that {$IFDEF ..} is a directive while {$ IFDEF ..} and { $IFDEF ..} 
are not.

The solution for that is probably to give each parsing application its own 
program template, and to insert hand-written code in that template where needed. 
The template in this directory will then only serve as a good start, from which 
you can reuse the most difficult parts: the lexer and parser.
The following description of the generated code is therefore of interest:




THE PROGRAM STRUCTURE OF THE GENERATED PARSER

[A] Your program should call the parser via TParser.DoParse. This is the most 
complex routine, but GoldParser, in combination with Pascal_Engine.pgt has solved 
it for you. I don't think you will have to modify this routine, because it 
calls a few other routines when parsing progresses. 
All the changes are expected to be done in these routines:
	TParser.DoAction,  each time a group of lexemes/tokens is recognized 
			   and reduced to a rule
	TParser.DoError,   when a syntax error is found, and should be reported 
			   before parsing proceeds
	TParser.DoCleanup, when parse trees are build-up on the MemoryHeap, and
			   parsing is finished or interupted, this routine
			   should free memory.
	TParser.DoAccept,  when the full input stream has been parsed, and should 
			   result in something
	TLexer.GetToken,   when more tokens are to be consumed by the parser.
The routine TParser.DoAction should link with the rest of your code, to make 
something happen (like building a parse tree or whatsoever). The engine in 
Pascal_Engine.pgt generates for each rule a dedicated action procedure, and 
let TParser.DoAction jump to that. It is a very elegant way of interfacing 
the actions that should follow the parsing process, since each action is 
isolated in its own procedure, and gets convenient access to the tokens by 
one parameter of that procedure.
However, this is only one way to do it, and mainly preferable when each action 
is rather complex. If only a few simple actions are required, the procedure 
TParser.DoAction may do a better job if it only contains a big CASE statement, 
for jumping to the associated rule number (RuleNr) with some action code. 
Suit yourself.

[B] When the parser calls the tokenizer TLexer.GetToken, it calls TLexer.GetLexeme
to read the input stream, or GetComment to consume characters as if it was whitespace.
In most cases TLexer.GetToken will only build a token from that lexeme (a Tag number, 
the file position, a pointer to a string that contains the content of the lexeme, etc)
In special cases it may decide to skip comments first and to read the next lexeme,
or it may insert a "virtual terminal" or may switch to another lexical reader.
It may be obvious that this is very application dependent, so tailor TLexer.GetToken
to your own needs

[C] When the tokenizer calls the lexer in TLexer.GetLexeme, it calls TLexer.GetChar
frequently. This routine is also a very complex one (GoldParser has solved this 
one as well for you) and I don't think you will ever have to modify this one. 
It can be called in two modes. In "Normal" mode, via TLexer.GetLexeme(false), 
or in "Skip" mode, via TLexer.GetLexeme(true). 
In skip mode it can only read lexemes that are one or two characters long, and 
skips all the others. This enables TLexer.GetToken to skip most characters within 
a block comment, until the magic closure token occurs (like '}' or '*)' in Pascal).

[D] When the lexer calls the character reader TLexer.GetChar, it calls TScanner.Get, 
and keeps track of issues like line number and the row position of a character 
in that line. It may serve most needs, so changing it is not so likely.

[E] Everything in TScanner can be subject of change, dependent on the type of 
input stream, and if reading can be speed-up by buffering the charecters first.




COMPILER DIRECTIVES IN THE PROGRAM CODE
A parser is to be rather silent. It should only call action routines with your 
dedicated code, plus reporting error messages if needed.
Once the pascal code has been created, you can still control the type of output.
By switching a few compiler directives on or off, you can follow or debug the 
progress of the lexer and the parser routines. On default, the following settings
apply:

  {$UNDEF  IsDELPHI       //define to compile with Delphi specific needs}
  {$UNDEF  IsNESTED       //define to nest comment blocks within comments}

  {$UNDEF  Debug_LEXER    //define if lexer  (DFA) are to be dumped to screen} 
  {$UNDEF  Debug_LEXEMES  //define if lexemes are to be dumped, before they are tokenized}
  {$DEFINE Debug_TOKENS   //define if tokenized lexemes are to be dumped} 
  {$UNDEF  Debug_PARSER   //define if parser (LALR) states are to be dumped} 
  {$DEFINE Debug_ACTIONS  //define if called actions are to be dumped } 
  {$DEFINE Debug_ERRORS   //undefine if not used} 
  {$UNDEF  Debug_HEAPMEM  //define if status of memory heap is to be reported} 

With these settings, the parser emits when it has reads an input token, what
action routines have been called, and what tokens have been invalidated when
a syntax error is catched by an error production in your grammar.



Have some fun with it!


Rob F.M. van den Brink
The Netherlands
R.F.M.vandenBrink@hccnet.nl


