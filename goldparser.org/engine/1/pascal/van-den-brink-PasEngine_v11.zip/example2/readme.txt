===============================================================================
D7GRAMMAR
===============================================================================
(c) Rob F.M. van den Brink, The Netherlands
R.F.M.vandenBrink@hccnet.nl
Aug, 2006 (version 1.1)



This is an advanced example, showing the full power of the inline parser engine, 
as defined by Pascal_Engine.pgt. The example can parse the object pascal dialect
being used within Delphi 7.0 from Borland.

USAGE 1:	D7Grammar test.pas test.out
USAGE 2:	D7Grammar test.pas 

I created D7Grammar.grm from scratch, and version 1.1 can now handle almost all 
Delphi 7.0 statements. However there are still a few issues to be resolved that
needs some features that currently beyond the capabilities of GoldParser 
(see notes in the grammar)
When you generate a parser from this grammar, the codesize will be around 2.5 Mbyte 
due to the huge tables (1048 LALR states, with more then 36000 edges). 
The resulting executable should not exceed 300 kbyte. 

It has also a few error production on board to show the mechanism of recovery
from syntax errors. If it encounters a syntax error, the parser will report a 
syntax error, and will try to recover from that by invalidating some code first 
before proceding with the next statement.
(the addition of error productions to the grammar is not mature enough to recover 
from almost all errors made in practice, but ik can already do an amazing job)





FILES
-------------------------------------------------------------------------------
..\Pascal_Engine.pgt	-- program template, 
D&Grammar.grm	-- grammar file for this example
D&Grammar.bat	-- batch file to do the conversion (set path to Gold directories first)

D&Grammar.exe	-- result of compiled pascal program
test.pas	-- test file, based on some library from Delphi
-------------------------------------------------------------------------------


