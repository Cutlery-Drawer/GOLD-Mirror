===============================================================================
YACC2GOLD
===============================================================================
(c) Rob F.M. van den Brink, The Netherlands
R.F.M.vandenBrink@hccnet.nl
Aug, 2006



This is an advanced example of how to combine a grammer with actions, for creating
a  usefull program. It reads a grammer in the format of the Yacc or Bison parser, 
and dumps that grammer in a format that is very close to that of Gold parser. 
It does most of the work, but you have to do a manual update afterwards

USAGE:	Yacc2gold.exe test.y test.out



The program template yacc2gold.pgt is derived from the general Pascal_Engine.pgt,
but tailored to this application. 
- One of the changes is that the tokenizer (TLexer.GetToken) is enhanced with 
issues that cannot be done with the grammar alone. An extra "Virtual Terminal" 
is used (RuleName) to convert an "identifier" into an "RuleName" if it starts 
on the first position of a line, or if it is immediately proceeded with a ':'. 
This makes the program very tolerant to Yacc-grammers with missing ';' between 
the rules (and there are many of these kind)
- Another change is that all actions are kept together to build up a parse tree 
during parsing. If no errors are detected, the parse tree is processed afterwards 
into the desired output.


FILES
-------------------------------------------------------------------------------
yacc2gold.pgt	-- program template, tailored to this application
yacc2gold.grm	-- grammar file for this example
yacc2gold.bat	-- batch file to do the conversion (set path to gold directories first()

yacc2gold.cgt	-- result of converting the grammer into a cgt file
yacc2gold.pas	-- result of converting the cgt+pgt file into a program
yacc2gold.exe	-- result of compiling pascal program
test.y		-- test file, based on grammer of the GNU pascal compiler
test.out	-- result from calling "yacc2gold.exe test.y test.out"
-------------------------------------------------------------------------------




