Option Explicit On 

Imports System.IO
Imports System.Collections.Specialized
Imports GoldParser

Public Class SimpleParser
    Inherits TemplateParser

    Public Class SimpleReduction
        Inherits Reduction
        Protected Shared Variables As New NameValueCollection
        Sub New()
            MyBase.new()
        End Sub
    End Class

    Sub New(ByVal stream As Stream)
        MyBase.New(stream)
    End Sub

    Public Overridable Function Execute() As Object
        If Not CurrentReduction Is Nothing Then
            CType(CurrentReduction, IContextMethod).Execute()
        End If
    End Function

    Private Class SimpleIfStm
        Inherits SimpleReduction
        Implements IContextMethod

        Public IfClause As IContextValue
        Public ThenClause As IContextMethod
        Public ElseClause As IContextMethod

        Public Function Execute() As Object Implements IContextMethod.Execute
            If IfClause.Value = "True" Then
                ThenClause.Execute()
            Else
                If Not ElseClause Is Nothing Then
                    ElseClause.Execute()
                End If
            End If
        End Function
    End Class

    Private Function CreateSimpleIfStm(ByVal IfClause As Object, ByVal ThenClause As Object, Optional ByVal ElseClause As Object = Nothing) As SimpleIfStm
        Dim Obj As New SimpleIfStm

        Obj.IfClause = IfClause
        Obj.ThenClause = ThenClause
        Obj.ElseClause = ElseClause

        CreateSimpleIfStm = Obj
    End Function

    Private Class SimpleWhileStm
        Inherits SimpleReduction
        Implements IContextMethod

        Public WhileClause As IContextValue
        Public DoClause As IContextMethod

        Public Function Execute() As Object Implements IContextMethod.Execute
            Do While WhileClause.Value = "True"
                DoClause.Execute()
            Loop
        End Function
    End Class

    Private Function CreateSimpleWhileStm(ByVal WhileClause As Object, ByVal DoClause As Object) As SimpleWhileStm
        Dim Obj As New SimpleWhileStm

        Obj.WhileClause = WhileClause
        Obj.DoClause = DoClause

        CreateSimpleWhileStm = Obj
    End Function

    Private Class SimpleStmList
        Inherits SimpleReduction
        Implements IContextMethod

        Public CurrentStm As IContextMethod
        Public NextStm As IContextMethod

        Public Function Execute() As Object Implements IContextMethod.Execute
            CurrentStm.Execute()
            If Not (NextStm Is Nothing) Then
                NextStm.Execute()
            End If
        End Function
    End Class

    Private Function CreateSimpleStmList(ByVal CurrentStm As Object, Optional ByVal NextStm As Object = Nothing) As SimpleStmList
        Dim Obj As New SimpleStmList
        Obj.CurrentStm = CurrentStm

        ' currentstm is nothing
        If Not NextStm Is Nothing Then
            Obj.NextStm = NextStm
        End If

        CreateSimpleStmList = Obj
    End Function

    Private Class SimpleID
        Inherits SimpleReduction
        Implements IContextValue

        Private _name As String
        Public Property Name() As String
            Get
                Return _name
            End Get
            Set(ByVal Value As String)
                _name = Value
                Variables.Add(Value, "")
            End Set
        End Property

        Public Property Value() As Object Implements IContextValue.Value
            Get
                Return Variables(Name)
            End Get
            Set(ByVal Value As Object)
                Variables(Name) = Value
            End Set
        End Property
    End Class

    Private Function CreateSimpleID(ByVal Name As String) As SimpleID
        Dim Obj As New SimpleID
        Obj.Name = Name
        Return Obj
    End Function

    Private Class SimpleExpression
        Inherits SimpleReduction
        Implements IContextValue

        Public LeftOperand As Object
        Public Operator As String
        Public RightOperand As Object

        Private Function BoolVal(ByVal Value As Boolean) As String
            If Value Then
                BoolVal = "True"
            Else
                BoolVal = "False"
            End If
        End Function

        Public Property Value() As Object Implements IContextValue.Value
            Get
                Dim LValue As Object, RValue As Object

                LValue = CType(LeftOperand, IContextValue).Value
                RValue = CType(RightOperand, IContextValue).Value

                Select Case Operator
                    Case "+"
                        Value = Val(LValue) + Val(RValue)
                    Case "-"
                        Value = Val(LValue) - Val(RValue)
                    Case "&"
                        Value = CStr(LValue) & CStr(RValue)
                    Case "*"
                        Value = Val(LValue) * Val(RValue)
                    Case "/"
                        Value = Val(LValue) / Val(RValue)
                    Case ">"
                        Value = BoolVal(Val(LValue) > Val(RValue))
                    Case "<"
                        Value = BoolVal(Val(LValue) < Val(RValue))
                    Case "<="
                        Value = BoolVal(Val(LValue) <= Val(RValue))
                    Case ">="
                        Value = BoolVal(Val(LValue) >= Val(RValue))

                    Case "=="
                        If VarType(LValue) = vbString And VarType(RValue) = vbString Then
                            Value = UCase(LValue) = UCase(RValue)         '== Compare strings
                        Else
                            Value = BoolVal(Val(LValue) = Val(RValue))    '== Compare values
                        End If

                    Case "<>"
                        If VarType(LValue) = vbString And VarType(RValue) = vbString Then
                            Value = UCase(LValue) <> UCase(RValue)        '== Compare strings
                        Else
                            Value = BoolVal(Val(LValue) <> Val(RValue))   '== Compare values
                        End If

                End Select
            End Get
            Set(ByVal Value As Object)

            End Set
        End Property
    End Class

    Private Function CreateSimpleExpression(ByVal LeftOperand As Object, ByVal Operator As String, ByVal RightOperand As Object) As SimpleExpression
        Dim Obj As New SimpleExpression

        Obj.LeftOperand = LeftOperand
        Obj.Operator = Operator
        Obj.RightOperand = RightOperand

        CreateSimpleExpression = Obj
    End Function

    Private Class SimpleString
        Inherits SimpleReduction
        Implements IContextValue

        Private _value As String

        Public Property Value() As Object Implements IContextValue.Value
            Get
                Return _value
            End Get
            Set(ByVal Value As Object)
                _value = Value
            End Set
        End Property
    End Class

    Private Function CreateSimpleString(ByVal Text As String) As SimpleString
        Dim Obj As New SimpleString

        Obj.Value = Text

        CreateSimpleString = Obj
    End Function

    Public Class SimpleDisplayStm
        Inherits SimpleReduction
        Implements IContextMethod

        Public DisplayClause As Object
        Public ReadID As String

        Public Function Execute() As Object Implements IContextMethod.Execute
            If ReadID = "" Then   'No variables accepted
                MsgBox(CType(DisplayClause, IContextValue).Value)
            Else
                Variables(ReadID) = InputBox(CType(DisplayClause, IContextValue).Value)
            End If
        End Function
    End Class

    Public Function CreateSimpleDisplayStm(ByVal DisplayClause As Object, Optional ByVal ReadID As String = "") As SimpleDisplayStm
        Dim Obj As New SimpleDisplayStm

        Obj.DisplayClause = DisplayClause
        Obj.ReadID = ReadID

        CreateSimpleDisplayStm = Obj
    End Function

    Private Class SimpleAssignStm
        Inherits SimpleReduction
        Implements IContextMethod

        Public Name As String
        Public AssignValue As Object

        Public Function Execute() As Object Implements IContextMethod.Execute
            Variables(Name) = CType(AssignValue, IContextValue).Value
        End Function
    End Class

    Private Function CreateSimpleAssignStm(ByVal Name As String, ByVal AssignValue As Object) As SimpleAssignStm
        Dim Obj As New SimpleAssignStm

        Obj.Name = Name
        Obj.AssignValue = AssignValue

        CreateSimpleAssignStm = Obj
    End Function

    Private Class SimpleNumber
        Inherits SimpleReduction
        Implements IContextValue

        Private _value As Double

        Public Property Value() As Object Implements IContextValue.Value
            Get
                Return _value
            End Get
            Set(ByVal Value As Object)
                _value = Value
            End Set
        End Property
    End Class

    Private Function CreateSimpleNumber(ByVal Value As Double) As SimpleNumber
        Dim Obj As New SimpleNumber

        Obj.Value = Value

        CreateSimpleNumber = Obj
    End Function


    Protected Overrides Function CreateRule_Addexp(ByVal Tokens As System.Collections.ArrayList) As Reduction
        '=== Since TrimReductions is set to true, none of these reductions will be
        '=== returned. They are performed 'behind the scenes'
    End Function

    Protected Overrides Function CreateRule_Addexp_Amp(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Addexp_Minus(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Addexp_Plus(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Expression(ByVal Tokens As System.Collections.ArrayList) As Reduction
        '=== Since TrimReductions is set to true, none of these reductions will be
        '=== returned. They are performed 'behind the scenes'
    End Function

    Protected Overrides Function CreateRule_Expression_Eqeq(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Expression_Gt(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Expression_Gteq(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Expression_Lt(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Expression_Lteq(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Expression_Ltgt(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Multexp(ByVal Tokens As System.Collections.ArrayList) As Reduction
        '=== Since TrimReductions is set to true, none of these reductions will be
        '=== returned. They are performed 'behind the scenes'
    End Function

    Protected Overrides Function CreateRule_Multexp_Div(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Multexp_Times(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleExpression(Tokens(0).Data, Tokens(1).Data, Tokens(2).Data)
    End Function

    Protected Overrides Function CreateRule_Negateexp(ByVal Tokens As System.Collections.ArrayList) As Reduction
        '=== Since TrimReductions is set to true, none of these reductions will be
        '=== returned. They are performed 'behind the scenes'
    End Function

    Protected Overrides Function CreateRule_Negateexp_Minus(ByVal Tokens As System.Collections.ArrayList) As Reduction
        '=== Since TrimReductions is set to true, none of these reductions will be
        '=== returned. They are performed 'behind the scenes'
    End Function

    Protected Overrides Function CreateRule_Statement_Assign_Id_Eq(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleAssignStm(Tokens(1).Data, Tokens(3).Data)
    End Function

    Protected Overrides Function CreateRule_Statement_Display(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleDisplayStm(Tokens(1).Data)
    End Function

    Protected Overrides Function CreateRule_Statement_Display_Read_Id(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleDisplayStm(Tokens(1).Data, Tokens(3).Data)
    End Function

    Protected Overrides Function CreateRule_Statement_If_Then_Else_End(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleIfStm(Tokens(1).Data, Tokens(3).Data, Tokens(5).Data)
    End Function

    Protected Overrides Function CreateRule_Statement_If_Then_End(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleIfStm(Tokens(1).Data, Tokens(3).Data)
    End Function

    Protected Overrides Function CreateRule_Statement_While_Do_End(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleWhileStm(Tokens(1).Data, Tokens(3).Data)
    End Function

    Protected Overrides Function CreateRule_Statements(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleStmList(Tokens(0).Data, Tokens(1).Data)
    End Function

    Protected Overrides Function CreateRule_Statements2(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleStmList(Tokens(0).Data)
    End Function

    Protected Overrides Function CreateRule_Value_Id(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleID(Tokens(0).Data)
    End Function

    Protected Overrides Function CreateRule_Value_Lparan_Rparan(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return Tokens(1).Data
    End Function

    Protected Overrides Function CreateRule_Value_Numberliteral(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Return CreateSimpleNumber(Val(Tokens(0).Data))
    End Function

    Protected Overrides Function CreateRule_Value_Stringliteral(ByVal Tokens As System.Collections.ArrayList) As Reduction
        Dim text As String = Tokens(0).Data
        If Len(text) >= 2 Then    'Remove single quotes
            text = Mid(text, 2, Len(text) - 2)
        End If
        Return CreateSimpleString(text)
    End Function

End Class

