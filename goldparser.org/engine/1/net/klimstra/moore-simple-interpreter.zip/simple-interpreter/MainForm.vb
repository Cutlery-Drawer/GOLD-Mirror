Option Strict Off
Option Explicit On

Imports System.IO
Imports System.Reflection
Imports GoldParser

Friend Class MainForm
    Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
    Public Sub New()
        MyBase.New()
        If m_vb6FormDefInstance Is Nothing Then
            If m_InitializingDefInstance Then
                m_vb6FormDefInstance = Me
            Else
                Try
                    'For the start-up form, the first instance created is the default instance.
                    If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
                        m_vb6FormDefInstance = Me
                    End If
                Catch
                End Try
            End If
        End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdExecute As System.Windows.Forms.Button
    Public WithEvents lstLog As System.Windows.Forms.ListBox
    Public WithEvents cmdParse As System.Windows.Forms.Button
    Public WithEvents txtProgram As System.Windows.Forms.TextBox
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label1 As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdExecute = New System.Windows.Forms.Button
        Me.lstLog = New System.Windows.Forms.ListBox
        Me.cmdParse = New System.Windows.Forms.Button
        Me.txtProgram = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'cmdExecute
        '
        Me.cmdExecute.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExecute.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExecute.Enabled = False
        Me.cmdExecute.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExecute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExecute.Location = New System.Drawing.Point(480, 420)
        Me.cmdExecute.Name = "cmdExecute"
        Me.cmdExecute.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExecute.Size = New System.Drawing.Size(89, 29)
        Me.cmdExecute.TabIndex = 5
        Me.cmdExecute.Text = "Execute"
        '
        'lstLog
        '
        Me.lstLog.BackColor = System.Drawing.SystemColors.Window
        Me.lstLog.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstLog.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLog.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstLog.IntegralHeight = False
        Me.lstLog.ItemHeight = 14
        Me.lstLog.Location = New System.Drawing.Point(8, 340)
        Me.lstLog.Name = "lstLog"
        Me.lstLog.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstLog.Size = New System.Drawing.Size(565, 71)
        Me.lstLog.TabIndex = 2
        '
        'cmdParse
        '
        Me.cmdParse.BackColor = System.Drawing.SystemColors.Control
        Me.cmdParse.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdParse.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdParse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdParse.Location = New System.Drawing.Point(384, 420)
        Me.cmdParse.Name = "cmdParse"
        Me.cmdParse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdParse.Size = New System.Drawing.Size(89, 29)
        Me.cmdParse.TabIndex = 1
        Me.cmdParse.Text = "Parse"
        '
        'txtProgram
        '
        Me.txtProgram.AcceptsReturn = True
        Me.txtProgram.AutoSize = False
        Me.txtProgram.BackColor = System.Drawing.SystemColors.Window
        Me.txtProgram.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProgram.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProgram.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProgram.Location = New System.Drawing.Point(8, 28)
        Me.txtProgram.MaxLength = 0
        Me.txtProgram.Multiline = True
        Me.txtProgram.Name = "txtProgram"
        Me.txtProgram.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtProgram.Size = New System.Drawing.Size(565, 281)
        Me.txtProgram.TabIndex = 0
        Me.txtProgram.Text = ""
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(117, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = """Simple"" Program"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(8, 320)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(117, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Parse Log"
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(582, 456)
        Me.Controls.Add(Me.cmdExecute)
        Me.Controls.Add(Me.lstLog)
        Me.Controls.Add(Me.cmdParse)
        Me.Controls.Add(Me.txtProgram)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MainForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "Simple Interpreter"
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As MainForm
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As MainForm
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New MainForm
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set(ByVal Value As MainForm)
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    Private Parser As SimpleParser

    Private Sub cmdParse_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdParse.Click
        lstLog.Items.Clear()

        Select Case Parser.DoParse(New StringReader(txtProgram.Text))
            Case ParseMessage.LexicalError
                Log("LEXICAL ERROR. Line " & Parser.CurrentLineNumber & ". Cannot recognize token: " & Parser.CurrentToken.Data)

            Case ParseMessage.SyntaxError
                Dim Text_Renamed As String
                With Parser.GetTokens()
                    Dim n As Integer
                    For n = 0 To .Count - 1
                        Text_Renamed = Text_Renamed & " " & .GetToken(n).Name
                    Next
                End With
                Log("SYNTAX ERROR. Line " & Parser.CurrentLineNumber & ". Expecting: " & LTrim(Text_Renamed))

            Case ParseMessage.Accept
                Log("-- Program Accepted --")
                cmdExecute.Enabled = True

            Case ParseMessage.InternalError
                Log("INTERNAL ERROR! Something is horribly wrong")

            Case ParseMessage.CommentError
                Log("COMMENT ERROR! Unexpected end of file")
        End Select
    End Sub

    Private Sub MainForm_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Try
            ' can use ildasm from .NET SDK to determine resource stream name in target manifest
            Parser = New SimpleParser([Assembly].GetExecutingAssembly.GetManifestResourceStream("simple_interpreter.Simple 2.cgt"))
        Catch ex As Exception
            MsgBox("The CGT file could not be opened!", MsgBoxStyle.Critical)
        End Try
    End Sub

    'UPGRADE_NOTE: Text was upgraded to Text_Renamed. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1061"'
    Private Sub Log(ByVal Text_Renamed As String)
        lstLog.Items.Add(Text_Renamed)
    End Sub


    Private Sub cmdExecute_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExecute.Click
        Parser.Execute()
    End Sub

    'UPGRADE_WARNING: Event txtProgram.TextChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
    Private Sub txtProgram_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtProgram.TextChanged
        cmdExecute.Enabled = False
    End Sub
End Class
