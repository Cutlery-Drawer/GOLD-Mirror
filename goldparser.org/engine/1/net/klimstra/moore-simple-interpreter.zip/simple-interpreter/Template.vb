
Option Explicit

Imports System.IO
Imports System.Text
Imports System.Collections.Specialized
Imports GoldParser

Public MustInherit Class TemplateParser
    Inherits Parser

    Private Enum SymbolConstants
           Symbol_Eof           = 0  ' (EOF)
           Symbol_Error         = 1  ' (Error)
           Symbol_Whitespace    = 2  ' (Whitespace)
           Symbol_Minus         = 3  ' '-'
           Symbol_Amp           = 4  ' '&'
           Symbol_Lparan        = 5  ' '('
           Symbol_Rparan        = 6  ' ')'
           Symbol_Times         = 7  ' '*'
           Symbol_Div           = 8  ' '/'
           Symbol_Plus          = 9  ' '+'
           Symbol_Lt            = 10 ' '<'
           Symbol_Lteq          = 11 ' '<='
           Symbol_Ltgt          = 12 ' '<>'
           Symbol_Eq            = 13 ' '='
           Symbol_Eqeq          = 14 ' '=='
           Symbol_Gt            = 15 ' '>'
           Symbol_Gteq          = 16 ' '>='
           Symbol_Assign        = 17 ' assign
           Symbol_Display       = 18 ' display
           Symbol_Do            = 19 ' do
           Symbol_Else          = 20 ' else
           Symbol_End           = 21 ' end
           Symbol_Id            = 22 ' Id
           Symbol_If            = 23 ' if
           Symbol_Numberliteral = 24 ' NumberLiteral
           Symbol_Read          = 25 ' read
           Symbol_Stringliteral = 26 ' StringLiteral
           Symbol_Then          = 27 ' then
           Symbol_While         = 28 ' while
           Symbol_Addexp        = 29 ' <Add Exp>
           Symbol_Expression    = 30 ' <Expression>
           Symbol_Multexp       = 31 ' <Mult Exp>
           Symbol_Negateexp     = 32 ' <Negate Exp>
           Symbol_Statement     = 33 ' <Statement>
           Symbol_Statements    = 34 ' <Statements>
           Symbol_Value         = 35 ' <Value>
    End Enum

    Private Enum RuleConstants
           Rule_Statements                 = 0  ' <Statements> ::= <Statement> <Statements>
           Rule_Statements2                = 1  ' <Statements> ::= <Statement>
           Rule_Statement_Display          = 2  ' <Statement> ::= display <Expression>
           Rule_Statement_Display_Read_Id  = 3  ' <Statement> ::= display <Expression> read Id
           Rule_Statement_Assign_Id_Eq     = 4  ' <Statement> ::= assign Id '=' <Expression>
           Rule_Statement_While_Do_End     = 5  ' <Statement> ::= while <Expression> do <Statements> end
           Rule_Statement_If_Then_End      = 6  ' <Statement> ::= if <Expression> then <Statements> end
           Rule_Statement_If_Then_Else_End = 7  ' <Statement> ::= if <Expression> then <Statements> else <Statements> end
           Rule_Expression_Gt              = 8  ' <Expression> ::= <Expression> '>' <Add Exp>
           Rule_Expression_Lt              = 9  ' <Expression> ::= <Expression> '<' <Add Exp>
           Rule_Expression_Lteq            = 10 ' <Expression> ::= <Expression> '<=' <Add Exp>
           Rule_Expression_Gteq            = 11 ' <Expression> ::= <Expression> '>=' <Add Exp>
           Rule_Expression_Eqeq            = 12 ' <Expression> ::= <Expression> '==' <Add Exp>
           Rule_Expression_Ltgt            = 13 ' <Expression> ::= <Expression> '<>' <Add Exp>
           Rule_Expression                 = 14 ' <Expression> ::= <Add Exp>
           Rule_Addexp_Plus                = 15 ' <Add Exp> ::= <Add Exp> '+' <Mult Exp>
           Rule_Addexp_Minus               = 16 ' <Add Exp> ::= <Add Exp> '-' <Mult Exp>
           Rule_Addexp_Amp                 = 17 ' <Add Exp> ::= <Add Exp> '&' <Mult Exp>
           Rule_Addexp                     = 18 ' <Add Exp> ::= <Mult Exp>
           Rule_Multexp_Times              = 19 ' <Mult Exp> ::= <Mult Exp> '*' <Negate Exp>
           Rule_Multexp_Div                = 20 ' <Mult Exp> ::= <Mult Exp> '/' <Negate Exp>
           Rule_Multexp                    = 21 ' <Mult Exp> ::= <Negate Exp>
           Rule_Negateexp_Minus            = 22 ' <Negate Exp> ::= '-' <Value>
           Rule_Negateexp                  = 23 ' <Negate Exp> ::= <Value>
           Rule_Value_Id                   = 24 ' <Value> ::= Id
           Rule_Value_Stringliteral        = 25 ' <Value> ::= StringLiteral
           Rule_Value_Numberliteral        = 26 ' <Value> ::= NumberLiteral
           Rule_Value_Lparan_Rparan        = 27 ' <Value> ::= '(' <Expression> ')'
    End Enum

    Sub New(ByVal GrammarFilename As String)
        MyBase.New(GrammarFilename)
    End Sub

    Sub New(ByVal input As Stream)
        MyBase.New(input)
    End Sub

    Public Function DoParse(ByVal Source As TextReader, Optional ByVal GenerateContext As Boolean = True) As ParseMessage
        'This procedure starts the GOLD Parser Engine and handles each of the
        'messages it returns. Each time a reduction is made, a new custom object
        'can be created and used to store the rule. Otherwise, the system will use
        'the Reduction object that was returned.
        '
        'The resulting tree will be a pure representation of the language 
        'and will be ready to implement.

        Dim Response As ParseMessage
        Dim Done As Boolean, Success As Boolean       'Controls when we leave the loop

        Success = False    'Unless the program is accepted by the parser

        OpenStream(Source)
        TrimReductions = True

        Done = False
        Do Until Done
            Response = Parse()

            Select Case Response
                Case ParseMessage.LexicalError
                    'Cannot recognize token
                    Done = True

                Case ParseMessage.SyntaxError
                    'Expecting a different token
                    Done = True ' stop if there are multiple errors on one line

                Case ParseMessage.Reduction
                    'Create a customized object to store the reduction
                    If GenerateContext Then
	                    CurrentReduction = CreateNewObject(CurrentReduction)
		    End If

                Case ParseMessage.Accept
                    'Success!
                    Done = True
                    Success = True

                Case ParseMessage.TokenRead
                    'You don't have to do anything here.

                Case ParseMessage.InternalError
                    'INTERNAL ERROR! Something is horribly wrong.
                    Done = True

                Case ParseMessage.CommentError
                    'COMMENT ERROR! Unexpected end of file
                    Done = True
            End Select
        Loop
		Return Response
    End Function

    Private Function CreateNewObject(ByVal TheReduction As Reduction) As Reduction
        Dim Result As Reduction

        With TheReduction
            Select Case .ParentRule.TableIndex
            Case RuleConstants.Rule_Statements
                '<Statements> ::= <Statement> <Statements>
                Result = CreateRule_Statements(.Tokens)
            Case RuleConstants.Rule_Statements2
                '<Statements> ::= <Statement>
                Result = CreateRule_Statements2(.Tokens)
            Case RuleConstants.Rule_Statement_Display
                '<Statement> ::= display <Expression>
                Result = CreateRule_Statement_Display(.Tokens)
            Case RuleConstants.Rule_Statement_Display_Read_Id
                '<Statement> ::= display <Expression> read Id
                Result = CreateRule_Statement_Display_Read_Id(.Tokens)
            Case RuleConstants.Rule_Statement_Assign_Id_Eq
                '<Statement> ::= assign Id '=' <Expression>
                Result = CreateRule_Statement_Assign_Id_Eq(.Tokens)
            Case RuleConstants.Rule_Statement_While_Do_End
                '<Statement> ::= while <Expression> do <Statements> end
                Result = CreateRule_Statement_While_Do_End(.Tokens)
            Case RuleConstants.Rule_Statement_If_Then_End
                '<Statement> ::= if <Expression> then <Statements> end
                Result = CreateRule_Statement_If_Then_End(.Tokens)
            Case RuleConstants.Rule_Statement_If_Then_Else_End
                '<Statement> ::= if <Expression> then <Statements> else <Statements> end
                Result = CreateRule_Statement_If_Then_Else_End(.Tokens)
            Case RuleConstants.Rule_Expression_Gt
                '<Expression> ::= <Expression> '>' <Add Exp>
                Result = CreateRule_Expression_Gt(.Tokens)
            Case RuleConstants.Rule_Expression_Lt
                '<Expression> ::= <Expression> '<' <Add Exp>
                Result = CreateRule_Expression_Lt(.Tokens)
            Case RuleConstants.Rule_Expression_Lteq
                '<Expression> ::= <Expression> '<=' <Add Exp>
                Result = CreateRule_Expression_Lteq(.Tokens)
            Case RuleConstants.Rule_Expression_Gteq
                '<Expression> ::= <Expression> '>=' <Add Exp>
                Result = CreateRule_Expression_Gteq(.Tokens)
            Case RuleConstants.Rule_Expression_Eqeq
                '<Expression> ::= <Expression> '==' <Add Exp>
                Result = CreateRule_Expression_Eqeq(.Tokens)
            Case RuleConstants.Rule_Expression_Ltgt
                '<Expression> ::= <Expression> '<>' <Add Exp>
                Result = CreateRule_Expression_Ltgt(.Tokens)
            Case RuleConstants.Rule_Expression
                '<Expression> ::= <Add Exp>
                Result = CreateRule_Expression(.Tokens)
            Case RuleConstants.Rule_Addexp_Plus
                '<Add Exp> ::= <Add Exp> '+' <Mult Exp>
                Result = CreateRule_Addexp_Plus(.Tokens)
            Case RuleConstants.Rule_Addexp_Minus
                '<Add Exp> ::= <Add Exp> '-' <Mult Exp>
                Result = CreateRule_Addexp_Minus(.Tokens)
            Case RuleConstants.Rule_Addexp_Amp
                '<Add Exp> ::= <Add Exp> '&' <Mult Exp>
                Result = CreateRule_Addexp_Amp(.Tokens)
            Case RuleConstants.Rule_Addexp
                '<Add Exp> ::= <Mult Exp>
                Result = CreateRule_Addexp(.Tokens)
            Case RuleConstants.Rule_Multexp_Times
                '<Mult Exp> ::= <Mult Exp> '*' <Negate Exp>
                Result = CreateRule_Multexp_Times(.Tokens)
            Case RuleConstants.Rule_Multexp_Div
                '<Mult Exp> ::= <Mult Exp> '/' <Negate Exp>
                Result = CreateRule_Multexp_Div(.Tokens)
            Case RuleConstants.Rule_Multexp
                '<Mult Exp> ::= <Negate Exp>
                Result = CreateRule_Multexp(.Tokens)
            Case RuleConstants.Rule_Negateexp_Minus
                '<Negate Exp> ::= '-' <Value>
                Result = CreateRule_Negateexp_Minus(.Tokens)
            Case RuleConstants.Rule_Negateexp
                '<Negate Exp> ::= <Value>
                Result = CreateRule_Negateexp(.Tokens)
            Case RuleConstants.Rule_Value_Id
                '<Value> ::= Id
                Result = CreateRule_Value_Id(.Tokens)
            Case RuleConstants.Rule_Value_Stringliteral
                '<Value> ::= StringLiteral
                Result = CreateRule_Value_Stringliteral(.Tokens)
            Case RuleConstants.Rule_Value_Numberliteral
                '<Value> ::= NumberLiteral
                Result = CreateRule_Value_Numberliteral(.Tokens)
            Case RuleConstants.Rule_Value_Lparan_Rparan
                '<Value> ::= '(' <Expression> ')'
                Result = CreateRule_Value_Lparan_Rparan(.Tokens)
            End Select
        End With
        If Result Is Nothing Then Result = TheReduction
	Return Result
    End Function

    'Function to handle <Statements> ::= <Statement> <Statements>      
    Protected MustOverride Function CreateRule_Statements(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statements> ::= <Statement>      
    Protected MustOverride Function CreateRule_Statements2(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statement> ::= display <Expression>      
    Protected MustOverride Function CreateRule_Statement_Display(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statement> ::= display <Expression> read Id      
    Protected MustOverride Function CreateRule_Statement_Display_Read_Id(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statement> ::= assign Id '=' <Expression>      
    Protected MustOverride Function CreateRule_Statement_Assign_Id_Eq(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statement> ::= while <Expression> do <Statements> end      
    Protected MustOverride Function CreateRule_Statement_While_Do_End(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statement> ::= if <Expression> then <Statements> end      
    Protected MustOverride Function CreateRule_Statement_If_Then_End(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Statement> ::= if <Expression> then <Statements> else <Statements> end      
    Protected MustOverride Function CreateRule_Statement_If_Then_Else_End(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Expression> '>' <Add Exp>      
    Protected MustOverride Function CreateRule_Expression_Gt(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Expression> '<' <Add Exp>      
    Protected MustOverride Function CreateRule_Expression_Lt(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Expression> '<=' <Add Exp>      
    Protected MustOverride Function CreateRule_Expression_Lteq(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Expression> '>=' <Add Exp>      
    Protected MustOverride Function CreateRule_Expression_Gteq(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Expression> '==' <Add Exp>      
    Protected MustOverride Function CreateRule_Expression_Eqeq(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Expression> '<>' <Add Exp>      
    Protected MustOverride Function CreateRule_Expression_Ltgt(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Expression> ::= <Add Exp>      
    Protected MustOverride Function CreateRule_Expression(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Add Exp> ::= <Add Exp> '+' <Mult Exp>      
    Protected MustOverride Function CreateRule_Addexp_Plus(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Add Exp> ::= <Add Exp> '-' <Mult Exp>      
    Protected MustOverride Function CreateRule_Addexp_Minus(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Add Exp> ::= <Add Exp> '&' <Mult Exp>      
    Protected MustOverride Function CreateRule_Addexp_Amp(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Add Exp> ::= <Mult Exp>      
    Protected MustOverride Function CreateRule_Addexp(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Mult Exp> ::= <Mult Exp> '*' <Negate Exp>      
    Protected MustOverride Function CreateRule_Multexp_Times(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Mult Exp> ::= <Mult Exp> '/' <Negate Exp>      
    Protected MustOverride Function CreateRule_Multexp_Div(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Mult Exp> ::= <Negate Exp>      
    Protected MustOverride Function CreateRule_Multexp(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Negate Exp> ::= '-' <Value>      
    Protected MustOverride Function CreateRule_Negateexp_Minus(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Negate Exp> ::= <Value>      
    Protected MustOverride Function CreateRule_Negateexp(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Value> ::= Id      
    Protected MustOverride Function CreateRule_Value_Id(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Value> ::= StringLiteral      
    Protected MustOverride Function CreateRule_Value_Stringliteral(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Value> ::= NumberLiteral      
    Protected MustOverride Function CreateRule_Value_Numberliteral(ByVal Tokens As ArrayList) As Reduction

    'Function to handle <Value> ::= '(' <Expression> ')'      
    Protected MustOverride Function CreateRule_Value_Lparan_Rparan(ByVal Tokens As ArrayList) As Reduction

End Class

Public Class SampleParser
    Inherits TemplateParser

    Sub New(ByVal GrammarFilename As String)
        MyBase.New(GrammarFilename)
    End Sub

    'Implements <Statements> ::= <Statement> <Statements>      
     Protected Overrides Function CreateRule_Statements(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_StatementsContext
	Debug.WriteLine("CreateRule_Statements")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statements> ::= <Statement>      
     Protected Overrides Function CreateRule_Statements2(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statements2Context
	Debug.WriteLine("CreateRule_Statements2")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statement> ::= display <Expression>      
     Protected Overrides Function CreateRule_Statement_Display(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statement_DisplayContext
	Debug.WriteLine("CreateRule_Statement_Display")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statement> ::= display <Expression> read Id      
     Protected Overrides Function CreateRule_Statement_Display_Read_Id(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statement_Display_Read_IdContext
	Debug.WriteLine("CreateRule_Statement_Display_Read_Id")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statement> ::= assign Id '=' <Expression>      
     Protected Overrides Function CreateRule_Statement_Assign_Id_Eq(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statement_Assign_Id_EqContext
	Debug.WriteLine("CreateRule_Statement_Assign_Id_Eq")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statement> ::= while <Expression> do <Statements> end      
     Protected Overrides Function CreateRule_Statement_While_Do_End(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statement_While_Do_EndContext
	Debug.WriteLine("CreateRule_Statement_While_Do_End")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statement> ::= if <Expression> then <Statements> end      
     Protected Overrides Function CreateRule_Statement_If_Then_End(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statement_If_Then_EndContext
	Debug.WriteLine("CreateRule_Statement_If_Then_End")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Statement> ::= if <Expression> then <Statements> else <Statements> end      
     Protected Overrides Function CreateRule_Statement_If_Then_Else_End(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Statement_If_Then_Else_EndContext
	Debug.WriteLine("CreateRule_Statement_If_Then_Else_End")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Expression> '>' <Add Exp>      
     Protected Overrides Function CreateRule_Expression_Gt(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Expression_GtContext
	Debug.WriteLine("CreateRule_Expression_Gt")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Expression> '<' <Add Exp>      
     Protected Overrides Function CreateRule_Expression_Lt(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Expression_LtContext
	Debug.WriteLine("CreateRule_Expression_Lt")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Expression> '<=' <Add Exp>      
     Protected Overrides Function CreateRule_Expression_Lteq(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Expression_LteqContext
	Debug.WriteLine("CreateRule_Expression_Lteq")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Expression> '>=' <Add Exp>      
     Protected Overrides Function CreateRule_Expression_Gteq(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Expression_GteqContext
	Debug.WriteLine("CreateRule_Expression_Gteq")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Expression> '==' <Add Exp>      
     Protected Overrides Function CreateRule_Expression_Eqeq(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Expression_EqeqContext
	Debug.WriteLine("CreateRule_Expression_Eqeq")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Expression> '<>' <Add Exp>      
     Protected Overrides Function CreateRule_Expression_Ltgt(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Expression_LtgtContext
	Debug.WriteLine("CreateRule_Expression_Ltgt")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Expression> ::= <Add Exp>      
     Protected Overrides Function CreateRule_Expression(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_ExpressionContext
	Debug.WriteLine("CreateRule_Expression")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Add Exp> ::= <Add Exp> '+' <Mult Exp>      
     Protected Overrides Function CreateRule_Addexp_Plus(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Addexp_PlusContext
	Debug.WriteLine("CreateRule_Addexp_Plus")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Add Exp> ::= <Add Exp> '-' <Mult Exp>      
     Protected Overrides Function CreateRule_Addexp_Minus(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Addexp_MinusContext
	Debug.WriteLine("CreateRule_Addexp_Minus")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Add Exp> ::= <Add Exp> '&' <Mult Exp>      
     Protected Overrides Function CreateRule_Addexp_Amp(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Addexp_AmpContext
	Debug.WriteLine("CreateRule_Addexp_Amp")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Add Exp> ::= <Mult Exp>      
     Protected Overrides Function CreateRule_Addexp(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_AddexpContext
	Debug.WriteLine("CreateRule_Addexp")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Mult Exp> ::= <Mult Exp> '*' <Negate Exp>      
     Protected Overrides Function CreateRule_Multexp_Times(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Multexp_TimesContext
	Debug.WriteLine("CreateRule_Multexp_Times")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Mult Exp> ::= <Mult Exp> '/' <Negate Exp>      
     Protected Overrides Function CreateRule_Multexp_Div(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Multexp_DivContext
	Debug.WriteLine("CreateRule_Multexp_Div")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Mult Exp> ::= <Negate Exp>      
     Protected Overrides Function CreateRule_Multexp(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_MultexpContext
	Debug.WriteLine("CreateRule_Multexp")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Negate Exp> ::= '-' <Value>      
     Protected Overrides Function CreateRule_Negateexp_Minus(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Negateexp_MinusContext
	Debug.WriteLine("CreateRule_Negateexp_Minus")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Negate Exp> ::= <Value>      
     Protected Overrides Function CreateRule_Negateexp(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_NegateexpContext
	Debug.WriteLine("CreateRule_Negateexp")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Value> ::= Id      
     Protected Overrides Function CreateRule_Value_Id(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Value_IdContext
	Debug.WriteLine("CreateRule_Value_Id")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Value> ::= StringLiteral      
     Protected Overrides Function CreateRule_Value_Stringliteral(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Value_StringliteralContext
	Debug.WriteLine("CreateRule_Value_Stringliteral")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Value> ::= NumberLiteral      
     Protected Overrides Function CreateRule_Value_Numberliteral(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Value_NumberliteralContext
	Debug.WriteLine("CreateRule_Value_Numberliteral")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function

    'Implements <Value> ::= '(' <Expression> ')'      
     Protected Overrides Function CreateRule_Value_Lparan_Rparan(ByVal Tokens As ArrayList) As Reduction
	Dim result As New Rule_Value_Lparan_RparanContext
	Debug.WriteLine("CreateRule_Value_Lparan_Rparan")
	'TODO: set properties using Tokens(?).Data
	return result
     End Function


     Public Overridable Function Execute() As Object
        If Not CurrentReduction Is Nothing Then
            CType(CurrentReduction, IContextMethod).Execute()
        End If
     End Function
End Class

Friend Class BaseContext
    Inherits Reduction

    Protected Shared Variables As New NameValueCollection
    'TODO: add any other properties common to all derived classes

    Sub New()
        MyBase.new()
    End Sub
End Class

Friend Interface IContextMethod
    Function Execute() As Object
End Interface

Friend Interface IContextValue
    Property Value() As Object
End Interface


Friend Class Rule_StatementsContext
    Inherits BaseContext
    'TODO: Rule_StatementsContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_StatementsContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_StatementsContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_StatementsContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statements2Context
    Inherits BaseContext
    'TODO: Rule_Statements2Context should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statements2Context.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statements2Context.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statements2Context.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statement_DisplayContext
    Inherits BaseContext
    'TODO: Rule_Statement_DisplayContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statement_DisplayContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statement_DisplayContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statement_DisplayContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statement_Display_Read_IdContext
    Inherits BaseContext
    'TODO: Rule_Statement_Display_Read_IdContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statement_Display_Read_IdContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statement_Display_Read_IdContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statement_Display_Read_IdContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statement_Assign_Id_EqContext
    Inherits BaseContext
    'TODO: Rule_Statement_Assign_Id_EqContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statement_Assign_Id_EqContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statement_Assign_Id_EqContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statement_Assign_Id_EqContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statement_While_Do_EndContext
    Inherits BaseContext
    'TODO: Rule_Statement_While_Do_EndContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statement_While_Do_EndContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statement_While_Do_EndContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statement_While_Do_EndContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statement_If_Then_EndContext
    Inherits BaseContext
    'TODO: Rule_Statement_If_Then_EndContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statement_If_Then_EndContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statement_If_Then_EndContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statement_If_Then_EndContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Statement_If_Then_Else_EndContext
    Inherits BaseContext
    'TODO: Rule_Statement_If_Then_Else_EndContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Statement_If_Then_Else_EndContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Statement_If_Then_Else_EndContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Statement_If_Then_Else_EndContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Expression_GtContext
    Inherits BaseContext
    'TODO: Rule_Expression_GtContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Expression_GtContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Expression_GtContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Expression_GtContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Expression_LtContext
    Inherits BaseContext
    'TODO: Rule_Expression_LtContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Expression_LtContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Expression_LtContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Expression_LtContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Expression_LteqContext
    Inherits BaseContext
    'TODO: Rule_Expression_LteqContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Expression_LteqContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Expression_LteqContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Expression_LteqContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Expression_GteqContext
    Inherits BaseContext
    'TODO: Rule_Expression_GteqContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Expression_GteqContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Expression_GteqContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Expression_GteqContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Expression_EqeqContext
    Inherits BaseContext
    'TODO: Rule_Expression_EqeqContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Expression_EqeqContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Expression_EqeqContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Expression_EqeqContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Expression_LtgtContext
    Inherits BaseContext
    'TODO: Rule_Expression_LtgtContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Expression_LtgtContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Expression_LtgtContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Expression_LtgtContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_ExpressionContext
    Inherits BaseContext
    'TODO: Rule_ExpressionContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_ExpressionContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_ExpressionContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_ExpressionContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Addexp_PlusContext
    Inherits BaseContext
    'TODO: Rule_Addexp_PlusContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Addexp_PlusContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Addexp_PlusContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Addexp_PlusContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Addexp_MinusContext
    Inherits BaseContext
    'TODO: Rule_Addexp_MinusContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Addexp_MinusContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Addexp_MinusContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Addexp_MinusContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Addexp_AmpContext
    Inherits BaseContext
    'TODO: Rule_Addexp_AmpContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Addexp_AmpContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Addexp_AmpContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Addexp_AmpContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_AddexpContext
    Inherits BaseContext
    'TODO: Rule_AddexpContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_AddexpContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_AddexpContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_AddexpContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Multexp_TimesContext
    Inherits BaseContext
    'TODO: Rule_Multexp_TimesContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Multexp_TimesContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Multexp_TimesContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Multexp_TimesContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Multexp_DivContext
    Inherits BaseContext
    'TODO: Rule_Multexp_DivContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Multexp_DivContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Multexp_DivContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Multexp_DivContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_MultexpContext
    Inherits BaseContext
    'TODO: Rule_MultexpContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_MultexpContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_MultexpContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_MultexpContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Negateexp_MinusContext
    Inherits BaseContext
    'TODO: Rule_Negateexp_MinusContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Negateexp_MinusContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Negateexp_MinusContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Negateexp_MinusContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_NegateexpContext
    Inherits BaseContext
    'TODO: Rule_NegateexpContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_NegateexpContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_NegateexpContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_NegateexpContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Value_IdContext
    Inherits BaseContext
    'TODO: Rule_Value_IdContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Value_IdContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Value_IdContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Value_IdContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Value_StringliteralContext
    Inherits BaseContext
    'TODO: Rule_Value_StringliteralContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Value_StringliteralContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Value_StringliteralContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Value_StringliteralContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Value_NumberliteralContext
    Inherits BaseContext
    'TODO: Rule_Value_NumberliteralContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Value_NumberliteralContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Value_NumberliteralContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Value_NumberliteralContext.Value
	    _value = value
        End Set
    End Property
End Class
    

Friend Class Rule_Value_Lparan_RparanContext
    Inherits BaseContext
    'TODO: Rule_Value_Lparan_RparanContext should implement either Method or Value - not both
    Implements IContextMethod
    Implements IContextValue

    Sub New()
        MyBase.new()
    End Sub

    Public Function Execute() As Object Implements IContextMethod.Execute
        'TODO: implement Rule_Value_Lparan_RparanContext.Execute
    End Function

    Private _value As Object
    Public Property Value() As Object Implements IContextValue.Value
        Get
            'TODO: implement Get Rule_Value_Lparan_RparanContext.Value
	    return _value
        End Get
        Set(ByVal Value As Object)
            'TODO: implement Set Rule_Value_Lparan_RparanContext.Value
	    _value = value
        End Set
    End Property
End Class
    
