using System;
using System.Text;
using Console = System.Console;

using GoldParser;

// This is an example for using GoldParser in C#.

public class GoldTest
{
	private Parser m_parser;
	
	public GoldTest(Parser p_parser)
	{
		m_parser = p_parser;
	}
	
	public void Execute()
	{
		bool done = false, fatal = false;
		int errors = 0, errorLine = -1;
		
		m_parser.OpenFile("test.txt");
		m_parser.TrimReductions = true;
		
		while (!done && !fatal)
		{								
			ParseMessage result = m_parser.Parse();
							
			switch (result)
			{
			case ParseMessage.TokenRead:
				// do nothing
				break;
			case ParseMessage.Reduction:
				// do nothing
				break;
			case ParseMessage.Accept:
				// program accepted
				done = true;
				break;
			case ParseMessage.LexicalError:
				Console.WriteLine("LexicalError");
				fatal = true;
				break;
			case ParseMessage.SyntaxError:
				if (errorLine == (errorLine = m_parser.CurrentLineNumber))
					fatal = true;	// stop if there are multiple errors on one line
				else
				{
					errors++;
					HandleSyntaxError();					
				}
				break;
			case ParseMessage.CommentError:
				Console.WriteLine("CommentError");
				fatal = true;
				break;
			case ParseMessage.InternalError:
				Console.WriteLine("Internal error - this is really bad");
				fatal = true;
				break;
			}
			
			errors = (fatal ? errors + 1 : errors);
			fatal = fatal || (errors > 7);
		}
		
		if (fatal || errors > 0)
			Console.WriteLine(errors + " error(s)");
		else
		{
			DumpVisitor visitor = new DumpVisitor();
			m_parser.CurrentReduction.Accept(visitor);
			Console.WriteLine(visitor.GetResult());
		}
	}
	
	private void HandleSyntaxError()
	{
		int line = m_parser.CurrentLineNumber;
		TokenStack expected = m_parser.GetTokens();

		Console.WriteLine("test.txt(" + line + "): Syntax error.");
		Console.WriteLine("  found:    " + m_parser.CurrentToken.Data);
		Console.Write("  expected: ");
		
		foreach (Token token in expected)
			Console.Write(token + " ");
			
		Console.Write("\n\n");
		m_parser.PushInputToken(expected[0]);
	}	

	public static void Main()
	{		
		try
		{
			Parser parser = new Parser("Simple.cgt");
			new GoldTest(parser).Execute();
		}
		catch (Exception e)
		{
			Console.WriteLine(e.ToString());
		}	
	}
}

public class DumpVisitor : IGoldVisitor
{
	private StringBuilder	m_buffer;		
	private int				m_level;
	
	public DumpVisitor()
	{
		m_buffer = new StringBuilder();
	}
	
	public String GetResult()
	{
		return m_buffer.ToString();
	}
	
	public void Visit(Reduction p_reduction)
	{
		Print(p_reduction.ToString());
		m_level++;
		p_reduction.ChildrenAccept(this);
		m_level--;
	}
	
	private void Print(String p_string)
	{
		m_buffer.Append(new String(' ', m_level));
		m_buffer.Append(p_string).Append("\n");
	}
	
}
	
