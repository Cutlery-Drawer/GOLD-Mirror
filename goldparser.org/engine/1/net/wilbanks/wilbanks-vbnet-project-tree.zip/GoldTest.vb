Imports System
Imports System.Text
Imports Console = System.Console
Imports GoldParser

' This is an example for using GoldParser in VB.NET, by Reggie Wilbanks <AppDeveloper@starband.net> converted (by hand) from,
' C# version by Marcus Klimstra <klimstra@home.nl>.

Public Class GoldTest

  Private m_parser As Parser

  Public Sub New(ByVal p_parser As Parser)

    m_parser = p_parser
  End Sub

  Public Sub Execute()

    Dim done As Boolean = False, fatal As Boolean = False
    Dim errors As Integer = 0, errorLine As Integer = -1

    m_parser.OpenFile("test.txt")
    m_parser.TrimReductions = True

    Do While (Not done And Not fatal)
      Dim result As ParseMessage = m_parser.Parse()

      Select Case (result)

      Case ParseMessage.TokenRead
        ' do nothing
      Case ParseMessage.Reduction
        ' do nothing
      Case ParseMessage.Accept
        ' program accepted
        done = True
      Case ParseMessage.LexicalError
        Console.WriteLine("LexicalError")
        fatal = True
      Case ParseMessage.SyntaxError
        If (errorLine = (errorLine = m_parser.CurrentLineNumber)) Then
          fatal = True ' stop if there are multiple errors on one line
        Else

          errors = errors + 1
          HandleSyntaxError()
        End If
      Case ParseMessage.CommentError
        Console.WriteLine("CommentError")
        fatal = True
      Case ParseMessage.InternalError
        Console.WriteLine("Internal error - this is really bad")
        fatal = True
      End Select

      errors = Microsoft.VisualBasic.IIf(fatal, errors + 1, errors)
      fatal = fatal Or (errors > 7)
    Loop

    If (fatal Or errors > 0) Then
      Console.WriteLine(errors + " error(s)")
    Else
      Dim visitor As New DumpVisitor()
      m_parser.CurrentReduction.Accept(visitor)
      Console.WriteLine(visitor.GetResult())
    End If
  End Sub

  Private Sub HandleSyntaxError()

    Dim line As Integer = m_parser.CurrentLineNumber
    Dim expected As TokenStack = m_parser.GetTokens()

    Console.WriteLine("test.txt(" + line + "): Syntax error.")
    Console.WriteLine("  found:    " + m_parser.CurrentToken.Data)
    Console.Write("  expected: ")
    Dim token As token
    For Each token In expected
      Console.Write(token)
      Console.Write(" ")
    Next
    Console.Write(microsoft.VisualBasic.vbcrlf & microsoft.VisualBasic.vbcrlf)
    m_parser.PushInputToken(expected.GetToken(0))
  End Sub

  Public Shared Sub Main()

    Try
      Dim Parser As New Parser("Simple.cgt")
      Dim result As New GoldTest(Parser)
      result.Execute()

    Catch e As Exception

      Console.WriteLine(e.ToString())
    End Try
  End Sub
End Class

Public Class DumpVisitor
  Implements IGoldVisitor

  Private m_buffer As StringBuilder
  Private m_level As Integer

  Public Sub New()

    m_buffer = New StringBuilder()
  End Sub

  Public Function GetResult() As String

    GetResult = m_buffer.ToString()
  End Function

  Public Sub Visit(ByVal r As Reduction) Implements IGoldVisitor.Visit
    Print(r.ToString())
    m_level = m_level + 1
    r.ChildrenAccept(Me)
    m_level = m_level - 1
  End Sub

  Private Sub Print(ByVal p_string As String)

    m_buffer.Append(New String(" ", m_level))
    m_buffer.Append(p_string).Append(microsoft.VisualBasic.vbcrlf)
  End Sub

End Class
