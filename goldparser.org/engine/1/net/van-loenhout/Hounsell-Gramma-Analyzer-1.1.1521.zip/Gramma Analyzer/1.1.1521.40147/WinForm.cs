using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace GrammaAnalyzer
{

	/// <summary>
	/// An IParserWrapperLogger is a dumb stateless interface that recieves one
	/// of a the simple log requests. It was created to wrap the details list view.  
	/// </summary>
	interface IParserWrapperLogger {
		void onLogWorkLoc( string act, int line, int col, string desc, string val ) ;
		void onLogWork( string act, string desc, string val ) ;
		void onLog( string act ) ;
	}

	interface IHighlighter {
		void onHighlightToken( string sym, string val, int col );
	}

	interface ITreeBuilder {
		object onBuildNode( string text, string sym, object lst );
	}

	interface IAnalyzer {
		void onAnalyzeDirective( string name, string value, string sym );
		void onAnalyzeCharacters( string name, string value, string sym, bool addit );
	}

	//==========================================================================
	/// <summary>
	/// Encapsulates a parser.
	/// </summary>
	class ParserWrapper
	{
		//----------------------------------------------------------------------
		private const string NICENL = "NL = {CR}{LF}|{CR}|{LF}" ;

		private string cgt_fname = null;
		private GoldParserEngine.CGTReader reader = null;

		private IParserWrapperLogger logger = null;
		private IHighlighter lighter = null;
		private ITreeBuilder builder = null;
		private IAnalyzer analyzer = null;

		private GoldParserEngine.Parser.LALRParser parser = null;
		private GoldParserEngine.Parser.Reduction first = null;

		private bool textok = false;

		//----------------------------------------------------------------------
		public ParserWrapper( string nfname, IParserWrapperLogger nlogger, IHighlighter nlighter, ITreeBuilder nbuilder, IAnalyzer nanalyzer ) {

			cgt_fname = nfname ;
			reader = new GoldParserEngine.CGTReader();
			reader.ReadFile( cgt_fname );

			parser = reader.Parser;

			parser.OnTokenRead += new GoldParserEngine.Parser.LALRParser.TokenReadHandler( onParserWorkToken );
			parser.OnShift += new GoldParserEngine.Parser.LALRParser.ShiftHandler( onParserWorkShift );
			parser.OnReduce += new GoldParserEngine.Parser.LALRParser.ReduceHandler( onParserWorkReduce );
			parser.OnGoto += new GoldParserEngine.Parser.LALRParser.GotoHandler( onParserWorkGoto );

			parser.OnAccept += new GoldParserEngine.Parser.LALRParser.AcceptHandler( onParserAccept  );

			parser.OnTokenError += new GoldParserEngine.Parser.LALRParser.TokenErrorHandler( onParserErrorToken );
			parser.OnParseError += new GoldParserEngine.Parser.LALRParser.ParseErrorHandler( onParserErrorSyntax );
			parser.OnUnexpectedEOF += new GoldParserEngine.Parser.LALRParser.UnexpectedEOFHandler( onParserErrorEOF );

			logger = nlogger ;
			lighter = nlighter ;
			builder = nbuilder ;
			analyzer = nanalyzer ;
		}

		//----------------------------------------------------------------------
		public bool Parse( string ntext ) {
			textok = false;

			first = parser.Parse( ntext );
			// textok is changed to true on receiving an accept event.

			if( ! textok ) {
				logger.onLog( "Regect" );
			}

			return( textok );
		}

		//----------------------------------------------------------------------
		private void analyzeTreeDirective( GoldParserEngine.Parser.Reduction red )
		{
			GoldParserEngine.Parser.Token nametok = red.Tokens[0] as GoldParserEngine.Parser.Token ;
			if( null != nametok && "DirectiveId" == nametok.Symbol.Name ) {
				analyzeTreeDirectiveBody( red.Tokens[2] as GoldParserEngine.Parser.Reduction, nametok.Text );
			}
		}

		private void analyzeTreeDirectiveBody( GoldParserEngine.Parser.Reduction red, string name )
		{
			if( null != red ) { // if not troken
				if( "Directive Symbol" == red.Symbol.Name ) {
					analyzeTreeDirectiveSymbol( red, name );
				} else if( "Directive Body" == red.Symbol.Name ) {
					foreach( GoldParserEngine.Parser.TokenOrReduction kidtokred in red.Tokens ) {
						 analyzeTreeDirectiveBody( kidtokred as GoldParserEngine.Parser.Reduction, name );
					}
				}
			}
		}

		private void analyzeTreeDirectiveSymbol( GoldParserEngine.Parser.Reduction red, string name )
		{
			GoldParserEngine.Parser.Token valtok ;

			GoldParserEngine.Parser.Reduction valred = red.Tokens[0] as GoldParserEngine.Parser.Reduction ;
			if( null != valred ) { // Literal Symbol
				valtok = valred.Tokens[0] as GoldParserEngine.Parser.Token ;
			} else { // ID or Character Set
				valtok = red.Tokens[0] as GoldParserEngine.Parser.Token ;
			}

			if( null != valtok ) {
				analyzer.onAnalyzeDirective( name, valtok.Text, valtok.Symbol.ToString() );
			}
		}

		//----------------------------------------------------------------------
		private void analyzeTreeCharacter( GoldParserEngine.Parser.Reduction red )
		{
			GoldParserEngine.Parser.Token nametok = red.Tokens[0] as GoldParserEngine.Parser.Token ;
			if( null != nametok && "CharacterSetId" == nametok.Symbol.Name ) {
				analyzeTreeCharacterBody( red.Tokens[2] as GoldParserEngine.Parser.Reduction, nametok.Text, true );
			}
		}

		private void analyzeTreeCharacterBody( GoldParserEngine.Parser.Reduction red, string name, bool addit )
		{
			if( null != red ) { // if not troken
				if( "Character Symbol" == red.Symbol.Name ) {
					analyzeTreeCharacterSymbol( red, name, addit );
				} else if( "Character Body" == red.Symbol.Name ) {
					foreach( GoldParserEngine.Parser.TokenOrReduction kidtokred in red.Tokens ) {
						GoldParserEngine.Parser.Reduction kidred = kidtokred as GoldParserEngine.Parser.Reduction ;
						if( null != kidred ) {
							if( "Character Op" == kidred.Symbol.Name ) {
								if( "-" == (kidred.Tokens[0] as GoldParserEngine.Parser.Token).Text ) {
									addit = false;
								}
							} else {
								analyzeTreeCharacterBody( kidred, name, addit );
							}
						}
					}
				}
			}
		}

		private void analyzeTreeCharacterSymbol( GoldParserEngine.Parser.Reduction red, string name, bool addit )
		{
			GoldParserEngine.Parser.Token valtok = red.Tokens[0] as GoldParserEngine.Parser.Token ;

			if( null != valtok ) {
				analyzer.onAnalyzeCharacters( name, valtok.Text, valtok.Symbol.ToString(), addit );
			}
		}

		//----------------------------------------------------------------------
		public void BuildTree( object lst ) {
			buildTreeRecurse( first, lst );
		}

		private void buildTreeRecurse( GoldParserEngine.Parser.TokenOrReduction tokred, object lst )
		{
			GoldParserEngine.Parser.Token tok = tokred as GoldParserEngine.Parser.Token ;
			GoldParserEngine.Parser.Reduction red = tokred as GoldParserEngine.Parser.Reduction ;

			if( null != tok ) {
				string sym = tok.Symbol.ToString(), val = tok.Text;
				if( "EOL" == sym ) {
					val = NICENL;
				}
				builder.onBuildNode( val, sym, lst );
			}
			if( null != red  ) {
				object kidlst = builder.onBuildNode( red.Rule.ToString(), null, lst );
				foreach( GoldParserEngine.Parser.TokenOrReduction kidtokred in red.Tokens ) {
					buildTreeRecurse( kidtokred, kidlst );
				}
			}
		}

		//----------------------------------------------------------------------
		private void onParserWorkToken( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.TokenReadEventArgs args)
		{
			string sym = args.Token.Symbol.ToString(), val = args.Token.Text;
			if( "EOL" == sym ) {
				val = NICENL;
			}
			logger.onLogWorkLoc(
				"Token Read",
				args.Token.Location.LineNr, args.Token.Location.ColumnNr,
				sym, val
			);

			lighter.onHighlightToken( args.Token.Symbol.ToString(), args.Token.Text, args.Token.Location.ColumnNr );
		}

		private void onParserWorkShift( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.ShiftEventArgs args )
		{
			logger.onLogWork(
				"Shift",
				args.Token.Symbol.ToString(), args.NewState.Id.ToString()
			);
		}

		private void onParserWorkReduce( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.ReduceEventArgs args )
		{
			logger.onLogWork(
				"Reduce",
				args.Reduction.Rule.ToString(), args.NewState.Id.ToString()
			);

			if( args.Rule.Lhs.Name == "Directive" ) {
				analyzeTreeDirective( args.Reduction );
			} else if( args.Rule.Lhs.Name == "Character Set" ) {
				analyzeTreeCharacter( args.Reduction );
			}
		}

		public void onParserWorkGoto( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.GotoEventArgs args )
		{
			logger.onLogWork(
				"Goto",
				args.Symbol.ToString(), args.NewState.Id.ToString()
			);
		}

		//----------------------------------------------------------------------
		private void onParserAccept( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.AcceptEventArgs args )
		{
			logger.onLog( "Accept" );
			textok = true;
		}

		//----------------------------------------------------------------------
		private void onParserErrorToken( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.TokenErrorEventArgs args )
		{
			logger.onLogWorkLoc(
				"Error",
				args.Token.Location.LineNr, args.Token.Location.ColumnNr,
				"Text is not a Token.", args.Token.Text
			);
		}

		private void onParserErrorSyntax( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.ParseErrorEventArgs args )
		{
			logger.onLogWork(
				"Error",
				"Unexpected Token. Expecting :", args.ExpectedTokens.ToString()
			);
		}

		private void onParserErrorEOF( GoldParserEngine.Parser.LALRParser parser, GoldParserEngine.Parser.UnexpectedEOFEventArgs args )
		{
			logger.onLogWork(
				"Error",
				"Unexpected End of File.", null
			);
		}
	}

	//==========================================================================
	/// <summary>
	/// Summary description for WinForm.
	/// </summary>
	public class gramForm : System.Windows.Forms.Form, IParserWrapperLogger, IHighlighter, ITreeBuilder, IAnalyzer
	{
		private const string CGT_FILE_NAME = "MFH GOLD Gramma.CGT" ;

		private ParserWrapper parserwrap ;
		private bool textok ;

		//----------------------------------------------------------------------
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TabControl gramTabControl;
		private System.Windows.Forms.TabPage gramParsedTextTabPage;
		private System.Windows.Forms.TabPage gramTreeTabPage;
		private System.Windows.Forms.RichTextBox gramTextParsed;
		private System.Windows.Forms.StatusBar gramStatus;
		private System.Windows.Forms.StatusBarPanel gramStatusFileName;
		private System.Windows.Forms.Button gramButtonOpen;
		private System.Windows.Forms.Button gramButtonParse;
		private System.Windows.Forms.OpenFileDialog gramDialogOpen;
		private System.Windows.Forms.TabPage gramTextTabPage;
		private System.Windows.Forms.TextBox gramTextOriginal;
		private System.Windows.Forms.TabPage gramLogTabPage;
		private System.Windows.Forms.ListView gramListLog;
		private System.Windows.Forms.ColumnHeader gramLogColAction;
		private System.Windows.Forms.ColumnHeader gramLogColLine;
		private System.Windows.Forms.ColumnHeader gramLogColCol;
		private System.Windows.Forms.ColumnHeader gramLogColDescription;
		private System.Windows.Forms.ColumnHeader gramLogColValue;
		private System.Windows.Forms.TreeView gramTreeParsed;
		private System.Windows.Forms.StatusBarPanel gramStatusAccept;
		private System.Windows.Forms.Button gramButtonTree;
		private System.Windows.Forms.TabPage gramDirectTabPage;
		private System.Windows.Forms.ListView gramListDirect;
		private System.Windows.Forms.ColumnHeader gramListColDirectName;
		private System.Windows.Forms.ColumnHeader gramListColDirectValue;
		private System.Windows.Forms.TabPage gramTabPageChars;
		private System.Windows.Forms.TreeView gramTreeChars;
		private System.Windows.Forms.StatusBarPanel gramStatusPanelLine;

		//----------------------------------------------------------------------
		public gramForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			gramDialogOpen.Filter = "GOLD Gramma Files (*.grm)|*.grm|All files (*.*)|*.*";

			parserwrap = new ParserWrapper( CGT_FILE_NAME, this, this, this, this );
		}

		//----------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose (bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gramTabControl = new System.Windows.Forms.TabControl();
			this.gramTextTabPage = new System.Windows.Forms.TabPage();
			this.gramTextOriginal = new System.Windows.Forms.TextBox();
			this.gramLogTabPage = new System.Windows.Forms.TabPage();
			this.gramListLog = new System.Windows.Forms.ListView();
			this.gramLogColAction = new System.Windows.Forms.ColumnHeader();
			this.gramLogColLine = new System.Windows.Forms.ColumnHeader();
			this.gramLogColCol = new System.Windows.Forms.ColumnHeader();
			this.gramLogColDescription = new System.Windows.Forms.ColumnHeader();
			this.gramLogColValue = new System.Windows.Forms.ColumnHeader();
			this.gramParsedTextTabPage = new System.Windows.Forms.TabPage();
			this.gramTextParsed = new System.Windows.Forms.RichTextBox();
			this.gramDirectTabPage = new System.Windows.Forms.TabPage();
			this.gramListDirect = new System.Windows.Forms.ListView();
			this.gramListColDirectName = new System.Windows.Forms.ColumnHeader();
			this.gramListColDirectValue = new System.Windows.Forms.ColumnHeader();
			this.gramTabPageChars = new System.Windows.Forms.TabPage();
			this.gramTreeChars = new System.Windows.Forms.TreeView();
			this.gramTreeTabPage = new System.Windows.Forms.TabPage();
			this.gramTreeParsed = new System.Windows.Forms.TreeView();
			this.gramStatus = new System.Windows.Forms.StatusBar();
			this.gramStatusFileName = new System.Windows.Forms.StatusBarPanel();
			this.gramStatusPanelLine = new System.Windows.Forms.StatusBarPanel();
			this.gramStatusAccept = new System.Windows.Forms.StatusBarPanel();
			this.gramButtonOpen = new System.Windows.Forms.Button();
			this.gramButtonParse = new System.Windows.Forms.Button();
			this.gramDialogOpen = new System.Windows.Forms.OpenFileDialog();
			this.gramButtonTree = new System.Windows.Forms.Button();
			this.gramTabControl.SuspendLayout();
			this.gramTextTabPage.SuspendLayout();
			this.gramLogTabPage.SuspendLayout();
			this.gramParsedTextTabPage.SuspendLayout();
			this.gramDirectTabPage.SuspendLayout();
			this.gramTabPageChars.SuspendLayout();
			this.gramTreeTabPage.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gramStatusFileName)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gramStatusPanelLine)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gramStatusAccept)).BeginInit();
			this.SuspendLayout();
			// 
			// gramTabControl
			// 
			this.gramTabControl.Controls.Add(this.gramTextTabPage);
			this.gramTabControl.Controls.Add(this.gramLogTabPage);
			this.gramTabControl.Controls.Add(this.gramParsedTextTabPage);
			this.gramTabControl.Controls.Add(this.gramDirectTabPage);
			this.gramTabControl.Controls.Add(this.gramTabPageChars);
			this.gramTabControl.Controls.Add(this.gramTreeTabPage);
			this.gramTabControl.Location = new System.Drawing.Point(0, 0);
			this.gramTabControl.Name = "gramTabControl";
			this.gramTabControl.SelectedIndex = 0;
			this.gramTabControl.Size = new System.Drawing.Size(608, 320);
			this.gramTabControl.TabIndex = 0;
			// 
			// gramTextTabPage
			// 
			this.gramTextTabPage.Controls.Add(this.gramTextOriginal);
			this.gramTextTabPage.Location = new System.Drawing.Point(4, 22);
			this.gramTextTabPage.Name = "gramTextTabPage";
			this.gramTextTabPage.Size = new System.Drawing.Size(600, 294);
			this.gramTextTabPage.TabIndex = 2;
			this.gramTextTabPage.Text = "Textual";
			// 
			// gramTextOriginal
			// 
			this.gramTextOriginal.AutoSize = false;
			this.gramTextOriginal.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gramTextOriginal.Location = new System.Drawing.Point(0, 0);
			this.gramTextOriginal.Multiline = true;
			this.gramTextOriginal.Name = "gramTextOriginal";
			this.gramTextOriginal.ReadOnly = true;
			this.gramTextOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.gramTextOriginal.Size = new System.Drawing.Size(600, 294);
			this.gramTextOriginal.TabIndex = 0;
			this.gramTextOriginal.Text = "";
			this.gramTextOriginal.WordWrap = false;
			// 
			// gramLogTabPage
			// 
			this.gramLogTabPage.Controls.Add(this.gramListLog);
			this.gramLogTabPage.Location = new System.Drawing.Point(4, 22);
			this.gramLogTabPage.Name = "gramLogTabPage";
			this.gramLogTabPage.Size = new System.Drawing.Size(600, 294);
			this.gramLogTabPage.TabIndex = 3;
			this.gramLogTabPage.Text = "Log";
			// 
			// gramListLog
			// 
			this.gramListLog.BackColor = System.Drawing.SystemColors.ControlLight;
			this.gramListLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
						this.gramLogColAction,
						this.gramLogColLine,
						this.gramLogColCol,
						this.gramLogColDescription,
						this.gramLogColValue});
			this.gramListLog.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gramListLog.FullRowSelect = true;
			this.gramListLog.GridLines = true;
			this.gramListLog.Location = new System.Drawing.Point(0, 0);
			this.gramListLog.Name = "gramListLog";
			this.gramListLog.Size = new System.Drawing.Size(600, 294);
			this.gramListLog.TabIndex = 0;
			this.gramListLog.View = System.Windows.Forms.View.Details;
			// 
			// gramLogColAction
			// 
			this.gramLogColAction.Text = "Action";
			this.gramLogColAction.Width = 87;
			// 
			// gramLogColLine
			// 
			this.gramLogColLine.Text = "Line";
			this.gramLogColLine.Width = 50;
			// 
			// gramLogColCol
			// 
			this.gramLogColCol.Text = "Column";
			this.gramLogColCol.Width = 50;
			// 
			// gramLogColDescription
			// 
			this.gramLogColDescription.Text = "Description";
			this.gramLogColDescription.Width = 217;
			// 
			// gramLogColValue
			// 
			this.gramLogColValue.Text = "Value";
			this.gramLogColValue.Width = 171;
			// 
			// gramParsedTextTabPage
			// 
			this.gramParsedTextTabPage.Controls.Add(this.gramTextParsed);
			this.gramParsedTextTabPage.Location = new System.Drawing.Point(4, 22);
			this.gramParsedTextTabPage.Name = "gramParsedTextTabPage";
			this.gramParsedTextTabPage.Size = new System.Drawing.Size(600, 294);
			this.gramParsedTextTabPage.TabIndex = 0;
			this.gramParsedTextTabPage.Text = "Parsed Textual";
			// 
			// gramTextParsed
			// 
			this.gramTextParsed.BackColor = System.Drawing.SystemColors.ControlLight;
			this.gramTextParsed.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gramTextParsed.Location = new System.Drawing.Point(0, 0);
			this.gramTextParsed.Name = "gramTextParsed";
			this.gramTextParsed.ReadOnly = true;
			this.gramTextParsed.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.gramTextParsed.Size = new System.Drawing.Size(600, 294);
			this.gramTextParsed.TabIndex = 0;
			this.gramTextParsed.Text = "";
			this.gramTextParsed.WordWrap = false;
			// 
			// gramDirectTabPage
			// 
			this.gramDirectTabPage.Controls.Add(this.gramListDirect);
			this.gramDirectTabPage.Location = new System.Drawing.Point(4, 22);
			this.gramDirectTabPage.Name = "gramDirectTabPage";
			this.gramDirectTabPage.Size = new System.Drawing.Size(600, 294);
			this.gramDirectTabPage.TabIndex = 5;
			this.gramDirectTabPage.Text = "Directives";
			// 
			// gramListDirect
			// 
			this.gramListDirect.BackColor = System.Drawing.SystemColors.ControlLight;
			this.gramListDirect.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
						this.gramListColDirectName,
						this.gramListColDirectValue});
			this.gramListDirect.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gramListDirect.FullRowSelect = true;
			this.gramListDirect.GridLines = true;
			this.gramListDirect.Location = new System.Drawing.Point(0, 0);
			this.gramListDirect.Name = "gramListDirect";
			this.gramListDirect.Size = new System.Drawing.Size(600, 294);
			this.gramListDirect.TabIndex = 0;
			this.gramListDirect.View = System.Windows.Forms.View.Details;
			// 
			// gramListColDirectName
			// 
			this.gramListColDirectName.Text = "Name";
			this.gramListColDirectName.Width = 120;
			// 
			// gramListColDirectValue
			// 
			this.gramListColDirectValue.Text = "Value";
			this.gramListColDirectValue.Width = 472;
			// 
			// gramTabPageChars
			// 
			this.gramTabPageChars.Controls.Add(this.gramTreeChars);
			this.gramTabPageChars.Location = new System.Drawing.Point(4, 22);
			this.gramTabPageChars.Name = "gramTabPageChars";
			this.gramTabPageChars.Size = new System.Drawing.Size(600, 294);
			this.gramTabPageChars.TabIndex = 6;
			this.gramTabPageChars.Text = "Character Sets";
			// 
			// gramTreeChars
			// 
			this.gramTreeChars.BackColor = System.Drawing.SystemColors.ControlLight;
			this.gramTreeChars.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gramTreeChars.ImageIndex = -1;
			this.gramTreeChars.Location = new System.Drawing.Point(0, 0);
			this.gramTreeChars.Name = "gramTreeChars";
			this.gramTreeChars.SelectedImageIndex = -1;
			this.gramTreeChars.Size = new System.Drawing.Size(600, 294);
			this.gramTreeChars.TabIndex = 0;
			// 
			// gramTreeTabPage
			// 
			this.gramTreeTabPage.Controls.Add(this.gramTreeParsed);
			this.gramTreeTabPage.Location = new System.Drawing.Point(4, 22);
			this.gramTreeTabPage.Name = "gramTreeTabPage";
			this.gramTreeTabPage.Size = new System.Drawing.Size(600, 294);
			this.gramTreeTabPage.TabIndex = 1;
			this.gramTreeTabPage.Text = "Parsed Tree";
			// 
			// gramTreeParsed
			// 
			this.gramTreeParsed.BackColor = System.Drawing.SystemColors.ControlLight;
			this.gramTreeParsed.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gramTreeParsed.ImageIndex = -1;
			this.gramTreeParsed.Location = new System.Drawing.Point(0, 0);
			this.gramTreeParsed.Name = "gramTreeParsed";
			this.gramTreeParsed.SelectedImageIndex = -1;
			this.gramTreeParsed.Size = new System.Drawing.Size(600, 294);
			this.gramTreeParsed.TabIndex = 0;
			// 
			// gramStatus
			// 
			this.gramStatus.Location = new System.Drawing.Point(0, 357);
			this.gramStatus.Name = "gramStatus";
			this.gramStatus.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
						this.gramStatusFileName,
						this.gramStatusPanelLine,
						this.gramStatusAccept});
			this.gramStatus.ShowPanels = true;
			this.gramStatus.Size = new System.Drawing.Size(608, 22);
			this.gramStatus.SizingGrip = false;
			this.gramStatus.TabIndex = 1;
			// 
			// gramStatusFileName
			// 
			this.gramStatusFileName.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.gramStatusFileName.Text = "Gramma File Name";
			this.gramStatusFileName.Width = 478;
			// 
			// gramStatusPanelLine
			// 
			this.gramStatusPanelLine.Width = 50;
			// 
			// gramStatusAccept
			// 
			this.gramStatusAccept.Text = "No File";
			this.gramStatusAccept.Width = 80;
			// 
			// gramButtonOpen
			// 
			this.gramButtonOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.gramButtonOpen.Location = new System.Drawing.Point(8, 328);
			this.gramButtonOpen.Name = "gramButtonOpen";
			this.gramButtonOpen.Size = new System.Drawing.Size(88, 24);
			this.gramButtonOpen.TabIndex = 2;
			this.gramButtonOpen.Text = "Open";
			this.gramButtonOpen.Click += new System.EventHandler(this.onPressedOpen);
			// 
			// gramButtonParse
			// 
			this.gramButtonParse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.gramButtonParse.Enabled = false;
			this.gramButtonParse.Location = new System.Drawing.Point(104, 328);
			this.gramButtonParse.Name = "gramButtonParse";
			this.gramButtonParse.Size = new System.Drawing.Size(88, 24);
			this.gramButtonParse.TabIndex = 3;
			this.gramButtonParse.Text = "Parse";
			this.gramButtonParse.Click += new System.EventHandler(this.onPressedParse);
			// 
			// gramButtonTree
			// 
			this.gramButtonTree.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.gramButtonTree.Enabled = false;
			this.gramButtonTree.Location = new System.Drawing.Point(200, 328);
			this.gramButtonTree.Name = "gramButtonTree";
			this.gramButtonTree.Size = new System.Drawing.Size(88, 24);
			this.gramButtonTree.TabIndex = 4;
			this.gramButtonTree.Text = "Tree";
			this.gramButtonTree.Click += new System.EventHandler(this.onPressedTree);
			// 
			// gramForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(608, 379);
			this.Controls.Add(this.gramButtonTree);
			this.Controls.Add(this.gramButtonParse);
			this.Controls.Add(this.gramButtonOpen);
			this.Controls.Add(this.gramStatus);
			this.Controls.Add(this.gramTabControl);
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "gramForm";
			this.Text = "Gramma Analyzer";
			this.gramTabControl.ResumeLayout(false);
			this.gramTextTabPage.ResumeLayout(false);
			this.gramLogTabPage.ResumeLayout(false);
			this.gramParsedTextTabPage.ResumeLayout(false);
			this.gramDirectTabPage.ResumeLayout(false);
			this.gramTabPageChars.ResumeLayout(false);
			this.gramTreeTabPage.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gramStatusFileName)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gramStatusPanelLine)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gramStatusAccept)).EndInit();
			this.ResumeLayout(false);
		}
		#endregion

		//----------------------------------------------------------------------
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			System.IO.FileInfo finfo = new System.IO.FileInfo( CGT_FILE_NAME );
			if( ! finfo.Exists ) {
				System.Windows.Forms.MessageBox.Show(
					"'.\\" + CGT_FILE_NAME + "' does not appear to exist.",
					"Gramma Not Found",
					System.Windows.Forms.MessageBoxButtons.OK,
					System.Windows.Forms.MessageBoxIcon.Hand
				);
			} else {
				Application.Run( new gramForm() );
			}
		}

		//----------------------------------------------------------------------
		private System.Drawing.Color symbolToColor( string sym, bool colorops ) {

			if( sym == "EOL" ) {
				return( System.Drawing.Color.DarkCyan );
			} else if( sym == "ProductionId" ) {
				return( System.Drawing.Color.DarkBlue );
			} else if( sym == "TerminalId" ) {
				return( System.Drawing.Color.DarkRed );
			} else if( sym == "LiteralQuoted" ) {
				return( System.Drawing.Color.DarkGreen );
			} else if ( sym == "CharacterSetId" || sym == "CharacterCode" || sym == "CharacterSelect" ) {
				return( System.Drawing.Color.DarkMagenta );
			} else if ( sym == "DirectiveId" ) {
				return( System.Drawing.Color.DarkOrange );
			} else if ( colorops && sym != "::=" && sym != "=" ) {
				return( System.Drawing.Color.Blue );
			}
			return( System.Drawing.Color.Black );
		}

		//----------------------------------------------------------------------
		public void onHighlightToken( string sym, string val, int abspos )
		{
			int lcnt = gramTextParsed.Lines.Length;
			if( "EOL" == sym ) {
				if( lcnt <= 0 ) { // ignore empty at top
					val = null;
				}
			} else {
				// if nothing has been added then there is no data and so you can't do arr[len-1]
				int ccnt = ( lcnt <= 0 ? 0 : ccnt = gramTextParsed.Lines[lcnt-1].Length );
				for( int i = ccnt ; i < abspos; ++i ) {
					gramTextParsed.AppendText( " " );
				}
			}

			if( null != val ) {
				gramTextParsed.SelectionColor = symbolToColor( sym, true );
				gramTextParsed.AppendText( val );
				gramTextParsed.SelectionColor = System.Drawing.Color.Black ;
			}
		}

		//----------------------------------------------------------------------
		public object onBuildNode( string text, string sym, object lst ) {

			System.Windows.Forms.TreeNode node = ((System.Windows.Forms.TreeNodeCollection) lst).Add(text);
			if( sym != null ) {
				node.ForeColor = symbolToColor( sym, false );
			}
			return( node.Nodes );
		}

		//----------------------------------------------------------------------
		public void onAnalyzeDirective( string name, string value, string sym ) {
			onAnalyzeDualText( gramListDirect, name, value, sym );
		}

		public void onAnalyzeDualText( System.Windows.Forms.ListView list, string name, string value, string sym ) {

			string[] itemfields = new string[2];

			itemfields[0] = name;
			itemfields[1] = value;

			System.Windows.Forms.ListViewItem item = new System.Windows.Forms.ListViewItem( itemfields );

			System.Drawing.Color clr = symbolToColor( sym, false );
			if( clr != System.Drawing.Color.Black ) {
				item.UseItemStyleForSubItems = false;
				item.SubItems[1].ForeColor = clr;
			}

			list.Items.Add( item );
		}

		//----------------------------------------------------------------------
		public void onAnalyzeCharacters( string name, string value, string sym, bool addit ) {

			System.Windows.Forms.TreeNode target = null;
			int len = gramTreeChars.Nodes.Count;
			if( len > 0 ) {
				target = gramTreeChars.Nodes[len - 1];
				if( name != target.Text ) {
					target = null;
				}
			}
			if( null == target ) {
				target = gramTreeChars.Nodes.Add( name );
			}

			if( addit ) {
				target.Nodes.Add( value ).ForeColor = symbolToColor( sym, false );
			} else {
				System.Windows.Forms.TreeNode nottarget = null;
				if( target.Nodes.Count == 0 ) {
					nottarget = target.Nodes.Add( "NOT" );
				} else {
					nottarget =  target.Nodes[0];
					if( "NOT" != nottarget.Text ) {
						target.Nodes.Insert( 0, nottarget = new System.Windows.Forms.TreeNode( "NOT" ) );
					}
				}
				nottarget.Nodes.Add( value ).ForeColor = symbolToColor( sym, false );
				nottarget.ForeColor = System.Drawing.Color.Red;
			}
		}

		//----------------------------------------------------------------------
		public void onLogWorkLoc( string act, int line, int col, string desc, string val ) {
			onLogActual( act, true, line, col, true, desc, val );
			gramStatusPanelLine.Text = line.ToString();
		}
		public void onLogWork( string act, string desc, string val ) {
			onLogActual( act, false, 0, 0, true, desc, val );
		}
		public void onLog( string act ) {
			onLogActual( act, false, 0, 0, false, null, null );
		}

		public void onLogClear() {
				gramListLog.Items.Clear();
		}

		private void onLogActual( string act, bool usepos, int line, int col, bool usedesc, string desc, string val ) {
			string[] itemfields = new string[5];

			itemfields[0] = act;
			if( usepos ) {
				itemfields[1] = (line+1).ToString();
				itemfields[2] = (col+1).ToString();
			}
			if( usedesc ) {
				itemfields[3] = desc;
				itemfields[4] = val;
			}

			System.Windows.Forms.ListViewItem item = new System.Windows.Forms.ListViewItem( itemfields );

			if( usedesc ) {
				System.Drawing.Color clr = symbolToColor( desc, false );
				if( clr != System.Drawing.Color.Black ) {
					item.UseItemStyleForSubItems = false;
					item.SubItems[4].ForeColor = clr;
				}
			}

			gramListLog.Items.Add( item );

			if( ! usedesc ) {
				gramStatusAccept.Text = act ;
			}
		}

		//----------------------------------------------------------------------
		private void onPressedOpen(object sender, System.EventArgs e)
		{
			if( gramDialogOpen.ShowDialog() == System.Windows.Forms.DialogResult.OK ) {
				gramStatusFileName.Text = gramDialogOpen.FileName;

				this.Cursor = System.Windows.Forms.Cursors.WaitCursor ;
					gramTextOriginal.Text = System.IO.File.OpenText( gramStatusFileName.Text ).ReadToEnd();
				this.Cursor = System.Windows.Forms.Cursors.Default ;

				onLogClear();
				onLog( "Open" );
				onLogWork( "Read", "File", gramStatusFileName.Text );
				gramTextParsed.Clear();
				gramTreeParsed.Nodes.Clear();
				gramListDirect.Items.Clear();
				gramTreeChars.Nodes.Clear();
			}

			if( gramTextOriginal.TextLength > 0 ) {
				gramButtonParse.Enabled = true;
			}
		}

		private void onPressedParse(object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor ;
				gramListLog.BeginUpdate();
				//gramTextParsed.BeginUpdate();

					textok = parserwrap.Parse( gramTextOriginal.Text );

				//gramTextParsed.EndUpdate();
				gramListLog.EndUpdate();
			this.Cursor = System.Windows.Forms.Cursors.Default ;

			if( textok ) {
				gramButtonTree.Enabled = true;
			}

			gramButtonParse.Enabled = false;
			gramStatusPanelLine.Text = null;
		}

		private void onPressedTree(object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor ;
				parserwrap.BuildTree( gramTreeParsed.Nodes );
			this.Cursor = System.Windows.Forms.Cursors.Default ;
			gramButtonTree.Enabled = false;
		}

	} // end class
} // end namespace
