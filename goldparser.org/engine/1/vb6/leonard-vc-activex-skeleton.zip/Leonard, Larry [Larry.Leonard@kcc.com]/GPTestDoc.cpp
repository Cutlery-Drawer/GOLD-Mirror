// GPTestDoc.cpp : implementation of the CGPTestDoc class
//

#include "stdafx.h"
#include "GPTest.h"

#include "GPTestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGPTestDoc

IMPLEMENT_DYNCREATE(CGPTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CGPTestDoc, CDocument)
	//{{AFX_MSG_MAP(CGPTestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGPTestDoc construction/destruction

CGPTestDoc::CGPTestDoc()
{
	// TODO: add one-time construction code here

}

CGPTestDoc::~CGPTestDoc()
{
}

BOOL CGPTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGPTestDoc serialization

void CGPTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGPTestDoc diagnostics

#ifdef _DEBUG
void CGPTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGPTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGPTestDoc commands
