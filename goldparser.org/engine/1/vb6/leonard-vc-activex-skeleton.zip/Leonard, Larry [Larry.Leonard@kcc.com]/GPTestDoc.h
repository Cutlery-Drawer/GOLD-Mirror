// GPTestDoc.h : interface of the CGPTestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GPTESTDOC_H__884D7F3C_7656_4001_A1B1_E4C7B4346CA5__INCLUDED_)
#define AFX_GPTESTDOC_H__884D7F3C_7656_4001_A1B1_E4C7B4346CA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGPTestDoc : public CDocument
{
protected: // create from serialization only
	CGPTestDoc();
	DECLARE_DYNCREATE(CGPTestDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGPTestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGPTestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGPTestDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GPTESTDOC_H__884D7F3C_7656_4001_A1B1_E4C7B4346CA5__INCLUDED_)
