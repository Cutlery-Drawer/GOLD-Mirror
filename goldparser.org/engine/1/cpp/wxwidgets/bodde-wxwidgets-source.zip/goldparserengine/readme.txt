This is the engine source for the wxGoldParser. This engine is a port from the Delphi GoldParser 
engine from Alexandre Rai. 

To check out how this engine works, go to the directory "samples" in which the following samples are present:

    - gptest : Almost exact port of the Delphi implementation of present grammar tester program
    - engine : This is an implementation example of the skeleton code for the wxGoldParser engine.
               It is also a very clear example how to pass objects to the higher reduction in the 
               parser tree, similar to how it could be done in Lex/Yacc. The example is a simple formula
               parser, with variable lookup and expression checking.
        
The src directory contains the cpp files for the heart of the wxGoldParser engine library. To add it to your project
just include the include dir, and use the library to link to your application. 

To compile under linux;
- Make sure you download and install wxWidgets (2.4.2 or higher)
- Run the makefiles and check them how it's done

To compile under windows;
- Use the .dsp files for Visual Studio 6
- Use the .sln files for Visual Studio 7
- For other IDE's you are unfortunately on your own (I can try to help though), but it is quite easy, simply
  make a library from the goldparser source, or add all sources to your main executable.

To compile under MacOS, Solaris, OS/2 etc;
- I don't know. If you have (altered) makefiles that do work contact me. It seems CodeWarrior 9.2 can handle
  the makefiles shipped, maybe it needs a bit tweaking.
                      
This version is released on May 21, 2004

Things to be done:
    - Since this is a direct port, things can be optimized. This will be done as soon as I have time for it
    - Documentation can be added in the form of Doxygen generated html help. Check the samples to see how
      it works.
    - Make a comparison how a Lexx/Yacc prg is used, and how this engine can be used (almost similar)
      
If you have problems, suggestions or bugs I will be happy to help out. Just mail: jorgb@xs4all.nl
      
Check out the webpage for more information: http://www.xs4all.nl/~jorgb/goldparser