//---------------------------------------------------------------------------
//
// Name:        Token.cpp
// Author:      Jorgen Bodde
// Created:     04/05/2004 11:45
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "token.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "token.h"

/* GpToken */

//-- constructor TToken.Create;
GpToken::GpToken()
	: FDataVar("0")
	, FState(0)
	, FReduction(0)
	, FParentSymbol(0)
	, FOwnerStack(0)
{
	//-- inherited Create;
	//-- FDataVar := '0';
}

//-- destructor TToken.Destroy;
GpToken::~GpToken()
{
	//-- FreeAndNil(FReduction);
	//-- if Assigned(FOwnerStack) then FOwnerStack.OwnedTokens.Remove(Self);
	//-- inherited Destroy;

	if(FReduction)
		delete FReduction;
	if(FOwnerStack)
		FOwnerStack->GetOwnedTokens().Remove(this);
}

/** GpReduction **/

//-- constructor TReduction.Create(const aParentRule : TRule);
GpReduction::GpReduction(GpRule *aParentRule)
	: FParentRule(aParentRule)
	, FTag(0)
{
	//-- inherited Create;
	//-- FTokens := TObjectList.Create(False);
	//-- FParentRule := aParentRule;

	// clear variant
	RetVal.MakeNull();
}

//--destructor TReduction.Destroy;
GpReduction::~GpReduction()
{
	//-- FTokens.Free;
	//-- inherited Destroy;

	FTokens.Clear();
}

/* GpTokenStack */

//-- constructor TTokenStack.Create;
GpTokenStack::GpTokenStack()
{
	//-- inherited Create;
	//-- MemberList := TObjectList.Create(False);
	//-- OwnedTokens := TObjectList.Create(False);
}

//-- destructor TTokenStack.Destroy;
GpTokenStack::~GpTokenStack()
{
	//-- MemberList.Free;
	//-- FreeOwnedTokens;
	//-- OwnedTokens.Free;
	//-- inherited Destroy;

	FreeOwnedTokens();
}

//-- procedure TTokenStack.Clear;
void GpTokenStack::Clear()
{
	//MemberList.Clear;
	//FreeOwnedTokens;

	MemberList.Clear();
	FreeOwnedTokens();
}

//-- function TTokenStack.GetItem(Index: Integer): TToken;
GpToken *GpTokenStack::GetItem(size_t Index) const
{
	//-- if (Index >= 0) and (Index < MemberList.Count)
	//-- then Result := MemberList.Items[Index] as TToken
	//-- else Result := nil;

	wxCHECK(Index >= 0 && Index < MemberList.GetCount(), 0);
	return MemberList[Index];
}


//-- procedure TTokenStack.Push(TheToken: TToken);
void GpTokenStack::Push(GpToken *TheToken)
{
	//-- MemberList.Add(TheToken);
	//-- if not Assigned(TheToken.FOwnerStack) then begin
	//--   TheToken.FOwnerStack := Self;
	//--   OwnedTokens.Add(TheToken);
	//-- end;

	MemberList.Add(TheToken);
	if(!TheToken->GetOwnerStack())
	{
		TheToken->SetOwnerStack(this);
		OwnedTokens.Add(TheToken);
	}
}

//-- function TTokenStack.Pop: TToken;
GpToken *GpTokenStack::Pop()
{
	//-- Result := Top;
	//-- if Assigned(Result) then MemberList.Delete(Count - 1);

	GpToken *value = 0;
	if(MemberList.GetCount() > 0)
	{
		value = MemberList.Last();
		MemberList.RemoveAt(MemberList.GetCount()-1);
	}

	return value;
}

//-- function TTokenStack.Top: TToken;
GpToken *GpTokenStack::Top()
{
	//-- Result := Items[Count - 1];

	GpToken *value = 0;
	if(MemberList.GetCount() > 0)
		value = MemberList.Last();

	return value;
}


//-- procedure TTokenStack.FreeOwnedTokens;
void GpTokenStack::FreeOwnedTokens()
{
	//-- while OwnedTokens.Count > 0 do OwnedTokens[0].Free;
	//-- OwnedTokens.Clear;

	// TODO: Make sure this works properly. According to the construction
	// the d'tor of GpToken should unregister itself from the list once
	// deleted. I am not sure if GpToken::FOwnerStack is the same as
	// GpTokenStack::OwnedTokens on this level
	while(OwnedTokens.GetCount() > 0)
	{
		// make sure no 0 objects get deleted
		if(OwnedTokens[0])
			delete OwnedTokens[0];
		else
			OwnedTokens.RemoveAt(0);
	}

	OwnedTokens.Clear();
}
