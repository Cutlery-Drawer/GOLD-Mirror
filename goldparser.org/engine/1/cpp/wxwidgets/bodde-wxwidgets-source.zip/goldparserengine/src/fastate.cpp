//---------------------------------------------------------------------------
//
// Name:        fastate.cpp
// Author:      Jorgen Bodde
// Created:     5/4/2004 6:41PM
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "fastate.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "fastate.h"


GpFaEdge::GpFaEdge(int Characters, int TargetIndex)
	: FCharacters(Characters)
	, FTargetIndex(TargetIndex)
{
}

GpFaEdge::~GpFaEdge()
{

}

//-- constructor TFAState.Create;
GpFaState::GpFaState()
{
	//-- inherited Create;
	//-- FEdges := TObjectList.Create(True);
}

//-- destructor TFAState.Destroy;
GpFaState::~GpFaState()
{
	//-- FEdges.Free;
	//-- inherited Destroy;

	// owned, delete all present obects
  	GpFaEdge *item;
  	for(size_t i = 0; i < FEdges.GetCount(); i++)
  	{
  		item = FEdges[i];
  		if(item)
  			delete item;
  	}
  	
  	FEdges.Clear();
}

//-- procedure TFAState.AddEdge(Characters: string; Target: Integer);
void GpFaState::AddEdge(const wxString &Characters, int Target)
{
	//-- var n: Integer;
	//-- begin
	//--   if Characters = '' then Add(0, Target)
	//--   else begin
	//--     for n := 0 to EdgeCount - 1 do
	//--       if Edges[n].TargetIndex = Target then begin
	//--         Edges[n].Characters := Edges[n].Characters + StrToIntDef(Characters, 0);
	//--         Exit;
	//--       end;
	//--     Add(StrToIntDef(Characters, 0), Target);
	//--   end;

	if(Characters.IsEmpty())
		Add(0, Target);
	else
	{
		long value; 
		if(!Characters.ToLong(&value, 10))
			value = 0;
		
		for(size_t n = 0; n < FEdges.GetCount(); n++)
		{
			if(GetEdge(n)->GetTargetIndex() == Target)
			{	
				GetEdge(n)->SetCharacters(GetEdge(n)->GetCharacters() + value);
				return;
			}
		}

		Add(value, Target);
	}
}

//-- procedure TFAState.Add(Characters, Target: integer);
void GpFaState::Add(int Characters, int Target)
{
	//-- FEdges.Add(TFAEdge.Create);
	//-- Edges[EdgeCount - 1].Characters := Characters;
	//-- Edges[EdgeCount - 1].TargetIndex := Target;

	FEdges.Add(new GpFaEdge(Characters, Target));
}

/* TFStateTable */

//-- procedure TFStateTable.Add(Value: TObject);
void GpFStateTable::Add(GpFaState *Value)
{
	//-- FList.Add(Value);
	FList.Add(Value);
}

//-- constructor TFStateTable.Create;
GpFStateTable::GpFStateTable()
{
	//-- inherited;
	//-- FList := TObjectList.Create(True);
}

//-- destructor TFStateTable.Destroy;
GpFStateTable::~GpFStateTable()
{
	//-- FList.Free;
	//-- inherited;

  	GpFaState *item;
  	for(size_t i = 0; i < FList.GetCount(); i++)
  	{
  		item = FList[i];
  		if(item)
  			delete item;
  	}
  	
  	FList.Clear();
}

//-- procedure TFStateTable.SetItem(Index: integer; const Value: TFAState);
void GpFStateTable::SetItem(GpFaState *Value, int Index)
{
	//-- if Index >= Count then FList.Count := Index + 1;
	//-- if Assigned(Items[Index]) then Items[Index].Free;
	//-- FList[Index] := Value;

	// make list bigger
	wxCHECK2(Index >=0, return);

	while((size_t)Index >= GetCount() && Index != -1) 
		FList.Add(0);

  	// delete old item when present
  	GpFaState *item = FList[Index];
  	if(item) 
  		delete item;
  		
  	FList[Index] = Value;
}
