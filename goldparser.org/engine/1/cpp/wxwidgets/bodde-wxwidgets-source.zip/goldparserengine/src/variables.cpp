//---------------------------------------------------------------------------
//
// Name:        variables.cpp
// Author:      Jorgen Bodde
// Created:     04/05/2004 13:50
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "variables.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "variables.h"

//-- constructor TVariableList.Create;
GpVariableList::GpVariableList()
{
	//-- inherited Create;
	//-- MemberList := TStringList.Create;
}

//-- destructor TVariableList.Destroy;
GpVariableList::~GpVariableList()
{
	//-- MemberList.Free;
	//-- inherited Destroy;
	Clear();
}

//-- procedure TVariableList.Add(Name: string; Value: string);
void GpVariableList::Add(const wxString &Name, const wxString &Value)
{
    //-- MemberList.Values[Name] := Value;

	int index = MemberListName.Index(Name);
	if(index == wxNOT_FOUND)
	{
		MemberListName.Add(Name);
		MemberListValue.Add(Value);
	}
	else
		MemberListValue[index] = Value;
}


//-- procedure TVariableList.Clear;
void GpVariableList::Clear()
{
	//--MemberList.Clear;

	MemberListName.Clear();
	MemberListValue.Clear();
}

//-- function TVariableList.GetName(Index: Integer): string;
wxString GpVariableList::GetNames(size_t Index) const
{
	//-- Result := MemberList.Names[Index];

	wxCHECK(Index < MemberListName.GetCount(), wxEmptyString);
	return MemberListName[Index];
}

//-- function TVariableList.GetValue(Name: string): string;
wxString GpVariableList::GetValue(const wxString &Name) const
{
	//-- Result := MemberList.Values[Name];

	int index = MemberListName.Index(Name);
	if(index == wxNOT_FOUND)
		return wxEmptyString;

	return MemberListValue[index];
}

//-- procedure TVariableList.SetValue(Name: string; Value: string);
void GpVariableList::SetValue(const wxString &Name, const wxString &Value)
{
	//-- MemberList.Values[Name] := Value;
	Add(Name, Value);
}

bool GpVariableList::VarExists(const wxString &Name)
{
	// return true when exists
	return MemberListName.Index(Name) != wxNOT_FOUND;
}