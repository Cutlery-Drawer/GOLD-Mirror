//---------------------------------------------------------------------------
//
// Name:        strstream.cpp
// Author:      Jorgen Bodde
// Created:     04/05/2004 12:01
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "strstream.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "strstream.h"

//----------------------------------------------------------------------------
// strstream.cpp
//----------------------------------------------------------------------------

GpStringStream::GpStringStream()
	: FPosition(0)
	, FDataString("")
{

}

GpStringStream::~GpStringStream()
{

}


int GpStringStream::Read(void *Buffer, int Count)
{
	// truncate to make sure not more then possible is read
	int Max = FDataString.Length() - FPosition;
	if(Count > Max)
		Count = Max;

	if(Count > 0)
	{
		memcpy(Buffer, FDataString.GetData() + FPosition, Count);
		FPosition += Count;	// advance to next
	}
	else
		Count = 0;	// none read

	return Count;
}

wxString GpStringStream::ReadString(int Count)
{
	// truncate
	int Max = FDataString.Length() - FPosition;
	if(Count > Max)
		Count = Max;

	if(Count > 0)
	{
		wxString Value = FDataString.Mid(FPosition, Count);
		FPosition += Count;
		return Value;
	}

	return wxEmptyString;
}

int GpStringStream::Seek(int Offset, int Origin)
{
	size_t Diff = 0;

	switch(Origin)
	{
	case soFromBeginning:
		Diff = Offset;
		break;

	case soFromCurrent:
		Diff = FPosition + Offset;
		break;

	case soFromEnd:
		Diff = FDataString.Length() - Offset;
		break;

	default:
		Diff = FPosition;
		break;
	}

	// no out of bounds
	if(Diff > FDataString.Length())
		FPosition = FDataString.Length();
	// also for lower, set to begin
	else if(Diff < 0)
		FPosition = 0;
	// absolute, just set
	else
		FPosition = Diff;

	return FPosition;
}

int GpStringStream::Write(const void *Buffer, int Count)
{
	// truncate existing string, so it's not appended to whole string
	if(FPosition > 0 && FPosition < FDataString.Length())
		FDataString.Truncate(FPosition);
	// else empty it
	else if(FPosition == 0)
		FDataString.Empty();

	if(Count > 0)
	{
		wxString Temp;
		char *p = Temp.GetWriteBuf(Count);
		memcpy(p, Buffer, Count);
		Temp.UngetWriteBuf(Count);

		FDataString.Append(Temp);
		FPosition = FDataString.Length();  // set to end
	}

	return FPosition;
}

void GpStringStream::WriteString(const wxString &String)
{
	// write this to end of current pos
	Write(String.c_str(), String.Length());
}

void GpStringStream::SetPosition(size_t Position)
{
	if(Position > FDataString.Length())
		FPosition = FDataString.Length();
	else if(Position < 0)
		FPosition = 0;
	else
		FPosition = Position;
}

wxChar GpStringStream::GetCh()
{
	// if eof, or past eof, set position to end
	// and return empty char
	if(FPosition >= FDataString.Length())
	{
		FPosition = FDataString.Length();
		return '\0';
	}

	// advance and return char at prev pos
	FPosition++;
	return FDataString.GetChar(FPosition-1);
}


wxChar GpStringStream::Peek() const
{
	// past eof, there is nothing but 0's
	if(FPosition >= FDataString.Length())
		return '\0';

	// current pos
	return FDataString.GetChar(FPosition);
}

void GpStringStream::Empty()
{
	FPosition = 0;
	FDataString.Clear();
}

void GpStringStream::SetDataString(const wxString &Value)
{
	FPosition = 0;
	FDataString = Value;
}
