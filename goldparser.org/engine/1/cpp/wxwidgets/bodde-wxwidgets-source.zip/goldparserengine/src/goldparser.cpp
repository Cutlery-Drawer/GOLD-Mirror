//---------------------------------------------------------------------------
//
// Name:        goldparser.cpp
// Author:      Jorgen Bodde
// Created:     5/4/2004 8:23PM
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "goldparser.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "goldparser.h"

//-- constructor TGOLDParser.Create;
wxGoldParser::wxGoldParser()
	: FTablesLoaded(false)
	, FTrimReductions(false)
{
	//-- inherited Create;
	//-- FStack := TTokenStack.Create;
	//-- FTokens := TTokenStack.Create;
	//-- FInputTokens := TTokenStack.Create;
	//-- FGrammarReader := TGrammarReader.Create(Self);
	//-- FSource := TSourceFeeder.Create;
	//-- FVariableList := TVariableList.Create;
	//-- FSymbolTable := TSymbolTable.Create;
	//-- FCharacterSetTable := TStringList.Create;
	//-- FRuleTable := TRuleTable.Create;
	//-- FDFA := TFStateTable.Create;
	//-- FActionTables := TLRActionTables.Create;;
	//-- FTablesLoaded := False;
	//-- FTrimReductions := False;

	FStack = new GpTokenStack();
	FTokens = new GpTokenStack();
	FInputTokens = new GpTokenStack();
	FGrammarReader = new GpGrammarReader(this);
	FSource = new GpSourceFeeder();
	FVariableList = new GpVariableList();
	FSymbolTable = new GpSymbolTable();
	FRuleTable = new GpRuleTable();
	FDFA = new GpFStateTable();
	FActionTables = new GpLRActionTables();
}

//-- destructor TGOLDParser.Destroy;
wxGoldParser::~wxGoldParser()
{
	//-- FActionTables.Free;
	//-- FDFA.Free;
	//-- FRuleTable.Free;
	//-- FCharacterSetTable.Free;
	//-- FSymbolTable.Free;
	//-- FVariableList.Free;
	//-- FSource.Free;
	//-- FGrammarReader.Free;
	//-- FInputTokens.Free;
	//-- FTokens.Free;
	//-- FStack.Free;
	//-- inherited Destroy;

	delete FActionTables;
	delete FDFA;
	delete FRuleTable;
	delete FSymbolTable;
	delete FVariableList;
	delete FSource;
	delete FGrammarReader;
	delete FInputTokens;
	delete FTokens;
	delete FStack;
}

//-- procedure TGOLDParser.Reset;
void wxGoldParser::Reset()
{
	//-- var i : integer;
	//-- begin
	//--   for i := 0 to SymbolTable.Count - 1 do
	//--     case SymbolTable[i].Kind of
	//--       SymbolTypeError : FErrorSymbol := SymbolTable[i];
	//--       SymbolTypeEnd   : FEndSymbol := SymbolTable[i];
	//--     end;
	//-- 

	FErrorSymbol = 0;
	FEndSymbol = 0;

	for(size_t i = 0; i < FSymbolTable->GetCount(); i++)
	{
		switch(FSymbolTable->GetItem(i)->GetKind())
		{
		case GpSymbolTypeError:
			FErrorSymbol = FSymbolTable->GetItem(i);
			break;
		case GpSymbolTypeEnd:
			FEndSymbol = FSymbolTable->GetItem(i);
			break;
		default:
			break;
		}
	}

	//--   if (VariableList.Value['Case Sensitive'] = 'True')
	//--   then FCompareMode := vbBinaryCompare
	//--   else FCompareMode := vbTextCompare;

	if(FVariableList->GetValue("Case Sensitive").IsSameAs("True"))
		FCompareMode = vbBinaryCompare;
	else
		FCompareMode = vbTextCompare;

	//--   FCurrentLALR := FInitialLALRState;
	//--   FLineNumber := 1;
	//--   FCommentLevel := 0;
	//--   FHaveReduction := False;
	//-- 
	//--   FTokens.Clear;
	//--   FInputTokens.Clear;
	//--   FStack.Clear;

	FCurrentLALR = FInitialLALRState;
	FLineNumber = 1;
	FCommentLevel = 0;
	FHaveReduction = false;
	
	FTokens->Clear();
	FInputTokens->Clear();
	FStack->Clear();
}

// The GOLDParser is reset and the internal tables are cleared.
//-- procedure TGOLDParser.Clear;
void wxGoldParser::Clear()
{
	//-- FSymbolTable.Clear;
	//-- FSymbolTable.Clear;
	//-- FRuleTable.Clear;
	//-- FCharacterSetTable.Clear;
	//-- FVariableList.Clear;
	//-- FTokens.Clear;
	//-- FInputTokens.Clear;
	//-- Reset;

	FSymbolTable->Clear();
	FRuleTable->Clear();
	FCharacterSetTable.Clear();
	FVariableList->Clear();
	FTokens->Clear();
	FInputTokens->Clear();
	Reset();
}

// If the Compiled Grammar Table file is successfully loaded
// the method returns True; otherwise False. This method must
// be called before any Parse calls are made.

//-- function TGOLDParser.LoadCompiledGrammar(const FileName : string) : boolean;
bool wxGoldParser::LoadCompiledGrammar(const wxString &FileName)
{
	//-- Reset;
	//-- Result := (FGrammarReader as TGrammarReader).LoadTables(Filename);
	
	Reset();
	return FGrammarReader->LoadTables(FileName);

}

// Opens the SourceString for parsing. If successful the method returns True; otherwise False.
//-- function TGOLDParser.OpenTextString(Text: String): Boolean;
bool wxGoldParser::OpenTextString(const wxString &Text)
{
	//-- Reset;
	//-- FSource.Text := Text;
	//-- PrepareToParse;
	//-- Result := True;
	
	Reset();
	FSource->SetText(Text);
	PrepareToParse();
	return true;
}


//-- procedure TGOLDParser.PrepareToParse;
void wxGoldParser::PrepareToParse()
{
	//-- var Start: TToken;
	//-- begin
	//--    //Added 12/23/2001: The token stack is empty until needed
	//--    Start := TToken.Create;
	//--    Start.State := FInitialLALRState;
	//--    Start.ParentSymbol := SymbolTable[(FGrammarReader as TGrammarReader).StartSymbol];
	//--    FStack.Push(Start);

	GpToken *Start = new GpToken();
	Start->SetState(FInitialLALRState);
	Start->SetParentSymbol(FSymbolTable->GetItem(FGrammarReader->GetStartSymbol()));
	FStack->Push(Start);
}

// Executes a parse.  When this method is called, the parsing engine
// reads information from the source text (either a string or a file)
// and then reports what action was taken. This ranges from a token
// being read and recognized from the source, a parse reduction, or a type of error.


//-- function TGOLDParser.Parse: Integer;
int wxGoldParser::Parse()
{
	// TODO: A lot of times a simple Pop or Top is done from the stack, but the memory is not
	// freed. I assume it is on another stack somewhere. Kind of tricky but keep an eye on it.
	// especially the ReadToken variable is leaking memory

	//-- var Done : Boolean;
	//--     ReadToken : TToken;
	//--     ParseResult : Integer;
	//-- begin
	//--   Result := gpMsgEmpty;

	int Result = gpMsgEmpty;
	int ParseResult;
	bool Done;
	GpToken *ReadToken = 0;

	//--   if (FActionTables.Count < 1) or (FDFA.Count < 1) then Result := gpMsgNotLoadedError

	if(FActionTables->GetCount() < 1 || FDFA->GetCount() < 1)
		Result = gpMsgNotLoadedError;
	//--   else begin
	else
	{	
	//--     Done := False;
	//--     while not Done do begin
		Done = false;
		while(!Done)
		{
	//--       if FInputTokens.Count = 0 then begin             //We must read a token
			if(FInputTokens->GetCount() == 0) 
			{
	//--         ReadToken := RetrieveToken(FSource);
	//--         if not Assigned(ReadToken) then begin
	//--           Result := gpMsgInternalError;
	//--           Done := True;

				ReadToken = RetrieveToken(*FSource);
				if(!ReadToken)
				{
					Result = gpMsgInternalError;
					Done = true;
				}
	//--         end else
	//--           if ReadToken.Kind <> SymbolTypeWhitespace then begin
				else if(ReadToken->GetKind() != GpSymbolTypeWhitespace)
				{
	//--             FInputTokens.Push(ReadToken);

					FInputTokens->Push(ReadToken);

	//--             if (FCommentLevel = 0) and (ReadToken.Kind <> SymbolTypeCommentLine)
	//--                and (ReadToken.Kind <> SymbolTypeCommentStart) then
	//--             begin
	//--               Result := gpMsgTokenRead;
	//--               Done := True;
	//--             end;

					if(FCommentLevel == 0 && (ReadToken->GetKind() != GpSymbolTypeCommentLine) &&
						(ReadToken->GetKind() != GpSymbolTypeCommentStart))
					{
						Result = gpMsgTokenRead;
						Done = true;
					}
				}

	//--           end else ReadToken.Free;
				else
					delete ReadToken;
			}
	//--         end else if FCommentLevel > 0 then begin        //We are in a block comment
			else if(FCommentLevel > 0)
			{					
	//--           ReadToken := FInputTokens.Pop;
				ReadToken = FInputTokens->Pop();
			
	//--           if Assigned(ReadToken) then

				if(ReadToken)
				{

	//--             case ReadToken.Kind of
	//--               SymbolTypeCommentStart : Inc(FCommentLevel);
	//--               SymbolTypeCommentEnd   : Dec(FCommentLevel);
	//--               SymbolTypeEnd          : begin
	//--                                          Result := gpMsgCommentError;
	//--                                          Done := True;
	//--                                        end;
	//--             else
	//--                  //Do nothing, ignore
	//--                  //The 'comment line' symbol is ignored as well
	//--             end;
	//-- 
	//--           ReadToken.Free;

					switch(ReadToken->GetKind())
					{
					case GpSymbolTypeCommentStart:
						FCommentLevel++;
						break;
					case GpSymbolTypeCommentEnd:
						FCommentLevel--;
						break;
					case GpSymbolTypeEnd:
						Result = gpMsgCommentError;
						Done = true;
						break;
					default:
						//Do nothing, ignore
						//The 'comment line' symbol is ignored as well
						break;
					}
				
					delete ReadToken;
				}
	//--         end else begin
			}
			else
			{
	//--           ReadToken := FInputTokens.Top;
	//--           if Assigned(ReadToken) then

				ReadToken = FInputTokens->Top();
				if(ReadToken)
				{
	//--             case ReadToken.Kind of
	//--               SymbolTypeCommentStart : begin
	//--                                          Inc(FCommentLevel);
	//--                                          FInputTokens.Pop;                           //Remove it
	//--                                        end;
	//--               SymbolTypeCommentLine  : begin
	//--                                          FInputTokens.Pop;                           //Remove it and rest of line
	//--                                          DiscardRestOfLine;                          //Procedure also increments the line number
	//--                                        end;
	//--               SymbolTypeError        : begin
	//--                                          Result := gpMsgLexicalError;
	//--                                          Done := True;
	//--                                        end;

					switch(ReadToken->GetKind())
					{
					case GpSymbolTypeCommentStart: 
						FCommentLevel++;
                        // TODO: Possible memleak!
                        FInputTokens->Pop();  //Remove it
                        //delete FInputTokens->Pop();  //Remove it
						break;
					
					case GpSymbolTypeCommentLine:
						// TODO: Possible memleak!
						FInputTokens->Pop();
						//delete FInputTokens->Pop();
                        DiscardRestOfLine();                          //Procedure also increments the line number
						break;

					case GpSymbolTypeError:
                        Result = gpMsgLexicalError;
						Done = true;
						break;

	//--             else begin                                     //FINALLY, we can parse the token
					default:
						{
	//--                    ParseResult := ParseToken(ReadToken);
	//--                     //NEW 12/2001: Now we are using the internal enumerated constant

							ParseResult = ParseToken(ReadToken);
							
							//NEW 12/2001: Now we are using the internal enumerated constant
							switch(ParseResult)
							{
	//--                    case ParseResult of
	//--                      ParseResultAccept : begin
	//--                        Result := gpMsgAccept;
	//--                        Done := True;
	//--                      end;

							case ParseResultAccept:
								Result = gpMsgAccept;
								Done = true;
								break;
								
	//--                      ParseResultInternalError : begin
	//--                        Result := gpMsgInternalError;
	//--                        Done := True;
	//--                      end;

							case ParseResultInternalError:
								Result = gpMsgInternalError;
								Done = true;
								break;

	//--                      ParseResultReduceNormal : begin
	//--                        Result := gpMsgReduction;
	//--                        Done := True;
	//--                      end;

							case ParseResultReduceNormal:
								Result = gpMsgReduction;
								Done = true;
								break;

								
	//--                      ParseResultShift : FInputTokens.Pop; //A simple shift, we must continue
	//--                                                           //Okay, remove the top token, it is on the stack

							case ParseResultShift:
								FInputTokens->Pop(); //A simple shift, we must continue
                                                      //Okay, remove the top token, it is on the stack
								break;
								
	//--                      ParseResultSyntaxError :  begin
	//--                        Result := gpMsgSyntaxError;
	//--                        Done := True;
	//--                      end;

							case ParseResultSyntaxError:
                                Result = gpMsgSyntaxError;
								Done = true;
								break;									
	//--                    end;
							}
						}
	//--                  end;
	//--             end;
					}
	//--         end;
				}
	//--       end;
			}
	//--    end;
		}
	//-- end;
	}

	return Result;

}

//-- function TGOLDParser.RetrieveToken(Source: TSourceFeeder): TToken;      //Symbol Index
GpToken *wxGoldParser::RetrieveToken(GpSourceFeeder &Source)
{
	//-- var Done: Boolean;
	//--     Found: Boolean;
	//--     CurrentDFA: Integer;
	//--     CurrentPosition: Integer;
	//--     LastAcceptState: Integer;
	//--     LastAcceptPosition: Integer;
	//--     ch: string;
	//--     n: Integer;
	//--     CharSetIndex: Integer;
	//--     comp1, comp2: string;
	//--     Target: Integer;
	//-- begin

	wxString ch;
	bool Found;
	size_t n;
	int CharsetIndex;
	wxString comp1, comp2;

	//--   Result := TToken.Create;
	//--   Done := False;

	GpToken *Result = new GpToken();
	bool Done = false;

	//--   CurrentDFA := FInitialDFAState;           //The first state is almost always #1.
	//--   CurrentPosition := 1;                    //Next byte in the input LookaheadStream
	//--   LastAcceptState := -1;                   //We have not yet accepted a character string
	//--   LastAcceptPosition := -1;

	int CurrentDFA = FInitialDFAState;
	int CurrentPosition = 1;	
	int LastAcceptState = -1;
	int LastAcceptPosition = -1;

	//--   Target := 0;

	int Target = 0;

	//--   if not FSource.Done then begin

	if(!FSource->Done())
	{

	//--     while not Done do begin

		while(!Done)
		{
	//--       ch := FSource.ReadFromBuffer(CurrentPosition, False, False);
	//--       if ch = '' then Found := False

			ch = FSource->ReadFromBuffer(CurrentPosition, false, false);
			if(ch.IsEmpty())
				Found = false;
	//--       else begin
			else
			{

	//--         n := 0;
	//--         Found := False;

				n = 0;
				Found = false;

	//--         while (n < DFA[CurrentDFA].EdgeCount) and (not Found) do begin

				while((n < FDFA->GetItem(CurrentDFA)->GetEdgeCount()) && !Found)
				{

	//--           CharSetIndex := DFA[CurrentDFA].Edges[n].Characters;
	//--           comp1 := CharacterSetTable.Strings[CharSetIndex];
	//--           comp2 := ch;

					CharsetIndex = FDFA->GetItem(CurrentDFA)->GetEdge(n)->GetCharacters();
					comp1 = FCharacterSetTable[CharsetIndex];
					comp2 = ch;

	//--           if FCompareMode = vbTextCompare then begin
	//--             comp1 := UpperCase(comp1);
	//--             comp2 := UpperCase(comp2);
	//--           end;

					if(FCompareMode == vbTextCompare) 
					{
						comp1.UpperCase();
						comp2.UpperCase();
					}
	//-- 
	//--           if Pos(comp2, comp1) <> 0 then begin
	//--             Found := True;
	//--             Target := DFA[CurrentDFA].Edges[n].TargetIndex;
	//--           end;

					if(comp1.Find(comp2) != -1)
					{
						Found = true;
						Target = FDFA->GetItem(CurrentDFA)->GetEdge(n)->GetTargetIndex();
					}

	//--           Inc(n);

					n++;
	//--         end;
	//--       end;
				}
			}

	//--        //======= This block-if statement checks whether an edge was found from the current state.
	//--        //======= If so, the state and current position advance. Otherwise it is time to exit the main loop
	//--        //======= and report the token found (if there was it fact one). If the LastAcceptState is -1,
	//--        //======= then we never found a match and the Error Token is created. Otherwise, a new token
	//--        //======= is created using the Symbol in the Accept State and all the characters that
	//--        //======= comprise it.
	//-- 
	//--       if Found then begin

			if(Found)
			{

	//--             //======= This code checks whether the target state accepts a token. If so, it sets the
	//--             //======= appropiate variables so when the algorithm in done, it can return the proper
	//--             //======= token and number of characters.
	//--         if DFA[Target].AcceptSymbol <> -1 then begin
	//--           LastAcceptState := Target;
	//--           LastAcceptPosition := CurrentPosition;
	//--         end;

				if(FDFA->GetItem(Target)->GetAcceptSymbol() != -1)
				{
					LastAcceptState = Target;
					LastAcceptPosition = CurrentPosition;
				}

	//--         CurrentDFA := Target;
	//--         Inc(CurrentPosition);

				CurrentDFA = Target;
				CurrentPosition ++;
			}
	//--       end else begin                                          //No edge found
			else
			{
	//--         Done := True;

				Done = true;

	//--         if LastAcceptState = -1 then begin                //Tokenizer cannot recognize symbol
	//--           Result.ParentSymbol := FErrorSymbol;
	//--           Result.DataVar := FSource.ReadFromBuffer(1, True, True);
	//--         end else begin                                            //Create Token, read characters
	//--           Result.ParentSymbol := SymbolTable[DFA[LastAcceptState].AcceptSymbol];
	//--           Result.DataVar := FSource.ReadFromBuffer(LastAcceptPosition, True, True);    //The data contains the total number of accept characters
	//--         end;

				if(LastAcceptState == -1)
				{
					Result->SetParentSymbol(FErrorSymbol);
					Result->SetDataVar(FSource->ReadFromBuffer(1, true, true));
				}
				else
				{
					Result->SetParentSymbol(FSymbolTable->GetItem(FDFA->GetItem(LastAcceptState)->GetAcceptSymbol()));
					Result->SetDataVar(FSource->ReadFromBuffer(LastAcceptPosition, true, true));
				}

	//--       end;
			}
	//--          //DoEvents
	//--     end;
		}
	//--   end else begin
	}
	else
	{
	//--     Result.DataVar := '';
	//--     Result.ParentSymbol := FEndSymbol;
	//--   end;

		Result->SetDataVar("");
		Result->SetParentSymbol(FEndSymbol);
	}

	//-- 
	//--    //======= Count Carriage Returns and increment the Line Number. This is done for the
	//--    //======= Developer and is not necessary for the DFA algorithm
	//--   for n := 1 To Length(Result.DataVar) do
	//--     if Result.DataVar[n] = #13 then Inc(FLineNumber);
	//-- 
	//-- end;

	FLineNumber += Result->GetDataVar().Freq('\n');

	return Result;
}


//-- procedure TGOLDParser.DiscardRestOfLine;
void wxGoldParser::DiscardRestOfLine()
{
	//-- var sTemp: string;
	//-- begin
	//--   //Kill the current line - basically for line comments
	//--   sTemp := FSource.ReadLine;
	//--    //01/26/2002: Fixed bug. Inc counter
	//--   Inc(FLineNumber);

	FSource->ReadLine();
	FLineNumber++;
}

//-- function TGOLDParser.ParseToken(NextToken: TToken): Integer;
int wxGoldParser::ParseToken(GpToken *NextToken)
{
	//-- var Index: Integer;
	//--     RuleIndex: Integer;
	//--     CurrentRule: TRule;
	//--     Head: TToken;
	//--     NewReduction: TReduction;
	//--     n: Integer;
	//-- begin
	//--    Result := ParseResultEmpty;
	
	int RuleIndex;
	GpRule *CurrentRule;
	GpToken *Head;
	GpReduction *NewReduction;
	int Result = ParseResultEmpty;
	size_t n;
	
	//--    Index := ActionTables[FCurrentLALR].ActionIndexForSymbol(NextToken.ParentSymbol.TableIndex);

	int Index = FActionTables->GetItem(FCurrentLALR)->ActionIndexForSymbol(NextToken->GetParentSymbol()->GetTableIndex());

	//--    if Index <> -1 then begin             //Work - shift or reduce
	if(Index != -1)
	{
	
	//--      FHaveReduction := False;       //Will be set true if a reduction is made
	//--      FTokens.Clear;

		FHaveReduction = false;
		FTokens->Clear();

	//--      case ActionTables[FCurrentLALR][Index].Action of

		switch(FActionTables->GetItem(FCurrentLALR)->GetItem(Index)->GetAction())
		{
	//--        ActionAccept : begin
	//--          FHaveReduction := True;
	//--          Result := ParseResultAccept;
	//--        end;
		case GpActionAccept:
			FHaveReduction = true;
			Result = ParseResultAccept;
			break;

	//--        ActionShift : begin
	//--          FCurrentLALR := ActionTables[FCurrentLALR][Index].Value;
	//--          NextToken.State := FCurrentLALR;
	//--          FStack.Push(NextToken);
	//--          Result := ParseResultShift;
	//--        end;
		case GpActionShift:
			FCurrentLALR = FActionTables->GetItem(FCurrentLALR)->GetItem(Index)->GetValue();
			NextToken->SetState(FCurrentLALR);
			FStack->Push(NextToken);
			Result = ParseResultShift;
			break;

	//--        ActionReduce : begin
		case GpActionReduce:
	//--             //Produce a reduction - remove as many tokens as members in the rule & push a nonterminal token
	//--          RuleIndex := ActionTables[FCurrentLALR][Index].Value;
	//--          CurrentRule := RuleTable[RuleIndex];

			RuleIndex = FActionTables->GetItem(FCurrentLALR)->GetItem(Index)->GetValue();
			CurrentRule = FRuleTable->GetItem(RuleIndex);

	//-- 
	//--             //======== Create Reduction
	//--          if (FTrimReductions) and (CurrentRule.ContainsOneNonTerminal) then begin
			if(FTrimReductions && CurrentRule->ContainsOneNonTerminal())
			{
	//--                //NEW 12/2001
	//--                //The current rule only consists of a single nonterminal and can be trimmed from the
	//--                //parse tree. Usually we create a new Reduction, assign it to the Data property
	//--                //of Head and push it on the stack. However, in this case, the Data property of the
	//--                //Head will be assigned the Data property of the reduced token (i.e. the only one
	//--                //on the stack).
	//--                //In this case, to save code, the value popped of the stack is changed into the head.
	//-- 
	//--             Head := FStack.Pop;
	//--             Head.ParentSymbol := CurrentRule.RuleNonterminal;
	//--             Result := ParseResultReduceEliminated;
				Head = FStack->Pop();
				Head->SetParentSymbol(CurrentRule->GetNonterminal());
				Result = ParseResultReduceEliminated;
			}
	//--          end else begin                                          //Build a Reduction
			else
			{
	//--            FHaveReduction := True;
	//--            NewReduction := TReduction.Create(CurrentRule);
	//--            for n := 0 to CurrentRule.SymbolCount - 1 do
	//--              NewReduction.InsertToken(0, FStack.Pop);
	//--            Head := TToken.Create;
	//--            Head.Reduction := NewReduction;
	//--            Head.ParentSymbol := CurrentRule.RuleNonterminal;
	//-- 
	//--            Result := ParseResultReduceNormal;

				FHaveReduction = true;
				NewReduction = new GpReduction(CurrentRule);

				for(n = 0; n < CurrentRule->GetSymbolCount(); n++)
					NewReduction->InsertToken(0, FStack->Pop());

				Head = new GpToken();
				Head->SetReduction(NewReduction);
				Head->SetParentSymbol(CurrentRule->GetNonterminal());

				Result = ParseResultReduceNormal;

	//--          end;
			}
	//--             //========== Goto
	//--          Index := FStack.Top.State;

			Index = FStack->Top()->GetState();

	//--             //========= If n is -1 here, then we have an Internal Table Error!!!!
	//--          n := ActionTables[Index].ActionIndexForSymbol(CurrentRule.RuleNonterminal.TableIndex);
	//--          if n <> -1 then begin
	//--            FCurrentLALR := ActionTables[Index][n].Value;
	//--            Head.State := FCurrentLALR;
	//--            FStack.Push(Head);
	//--          end else Result := ParseResultInternalError;

			n = FActionTables->GetItem(Index)->ActionIndexForSymbol(CurrentRule->GetNonterminal()->GetTableIndex());
			if(n != -1)
			{
				FCurrentLALR = FActionTables->GetItem(Index)->GetItem(n)->GetValue();
				Head->SetState(FCurrentLALR);
				FStack->Push(Head);
			}
			else
				Result = ParseResultInternalError;
	//--        end;
			break;
		}
	//--      end;
	}
//--    end else begin
	else
	{
//--       //=== Syntax Error! Fill Expected Tokens
//--     FTokens.Clear;
//--     for n := 0 to ActionTables[FCurrentLALR].Count - 1 do begin
//--          //01/26/2002: Fixed bug. EOF was not being added to the expected tokens
//--       case ActionTables[FCurrentLALR][n].Symbol.Kind of
//--         SymbolTypeTerminal, SymbolTypeEnd : begin
//--           Head := TToken.Create;
//--           Head.DataVar := '';
//--           Head.ParentSymbol := ActionTables[FCurrentLALR][n].Symbol;
//--           FTokens.Push(Head);
//--         end;
//--       end;
//--     end;
//--        //If pTokens.Count = 0 Then Stop
//--     Result := ParseResultSyntaxError;
//--   end;
//-- end;

		FTokens->Clear();
		for(n = 0; n < FActionTables->GetItem(FCurrentLALR)->GetCount(); n++)
		{
			switch(FActionTables->GetItem(FCurrentLALR)->GetItem(n)->GetSymbol()->GetKind())
			{
			case GpSymbolTypeTerminal:
			case GpSymbolTypeEnd:
				Head = new GpToken();
				Head->SetDataVar("");
				Head->SetParentSymbol(FActionTables->GetItem(FCurrentLALR)->GetItem(n)->GetSymbol());
				FTokens->Push(Head);
				break;
			}
		}

		Result = ParseResultSyntaxError;
	}

	return Result;
}

//-- function TGOLDParser.LoadCompiledGrammar(const Stream: TStream): boolean;
bool wxGoldParser::LoadCompiledGrammar(wxInputStream &Stream)
{
	//-- Reset;
	//-- Result := (FGrammarReader as TGrammarReader).LoadTables(Stream);
	Reset();
	return FGrammarReader->LoadTables(Stream);
}
