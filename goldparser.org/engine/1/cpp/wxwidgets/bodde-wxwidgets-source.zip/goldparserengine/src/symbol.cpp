//---------------------------------------------------------------------------
//
// Name:        Symbol.cpp
// Author:      Jorgen Bodde
// Created:     04/05/2004 09:09
// Copyright:   
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "symbol.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "symbol.h"

//----------------------------------------------------------------------------
// Symbol.cpp
//----------------------------------------------------------------------------

/* GpSymbol */

//-- const pkQuotedChars = ['|', '-', '+', '*', '?', '(', ')', '[', ']', '{', '}', '<', '>', '!'];

//-- constructor TSymbol.Create(aTableIndex : integer; aName : string; aKind : integer);
GpSymbol::GpSymbol(int aTableIndex, const wxString &aName, int aKind)
	: FTableIndex(aTableIndex)
	, FName(aName)
	, FKind(aKind)
{
	//-- inherited Create;
	//-- FTableIndex := aTableIndex;
	//-- FName := aName;
	//-- FKind := aKind;
}

GpSymbol::~GpSymbol()
{
}

//-- function TSymbol.PatternFormat(Source: string): string;
wxString GpSymbol::PatternFormat(const wxString &Source) const
{
	//-- for i := 1 to Length(Source) do
	//--   if Source[i] = '''' then  Result := Result + ''''''
	//--   else if (Source[i] in pkQuotedChars) or (Source[i] = '"')
	//--      then Result := Result + '''' + Source[i] + '''';

	wxString Result, str;
	for(size_t i = 0; i < Source.Length(); i++)
	{
		if(Source.GetChar(i) == '\'')
			Result.Append("''");
		else
		{
			switch(Source.GetChar(i))
			{
				case '|':
				case '-':
				case '+':
				case '*':
				case '?':
				case '(':
				case ')':
				case '[':
				case ']':
				case '{':
				case '}':
				case '<':
				case '>':
				case '!':
					str.Printf("'%c'", Source.GetChar(i));
					Result.Append(str);
					break;
				default:
					Result.Append(Source.GetChar(i));
					break;
			}
		}
	}

	return Result;
}

/* GpSymbolTable */

//-- constructor TSymbolTable.Create;
GpSymbolTable::GpSymbolTable()
{
	//-- inherited;
	//-- FList := TObjectList.Create(True);
}

GpSymbolTable::~GpSymbolTable()
{
	//-- FList.Free;
	//-- inherited;
	Clear();
}

//-- procedure TSymbolTable.Add(Value: TObject);
void GpSymbolTable::Add(GpSymbol *Value)
{
	//-- FList.Add(Value);

	FList.Add(Value);
}

//-- procedure TSymbolTable.Clear;
void GpSymbolTable::Clear()
{
	// owned, delete all present obects
  	GpSymbol *item;
  	for(size_t i = 0; i < FList.GetCount(); i++)
  	{
  		item = FList[i];
  		if(item)
  			delete item;
  	}

  	FList.Clear();
}

//-- function TSymbolTable.GetItem(Index: integer): TSymbol;
GpSymbol *GpSymbolTable::GetItem(size_t Index)
{
	//-- Result := FList[Index] as TSymbol;
	
	GpSymbol *Result = FList[Index];
	wxCHECK(Result, 0);

	return Result;
}

//-- procedure TSymbolTable.SetItem(Index: integer; const Value: TSymbol);
void GpSymbolTable::SetItem(size_t Index, GpSymbol *Value)
{
	//-- if Index >= Count then FList.Count := Index + 1;
	//-- if Assigned(Items[Index]) then Items[Index].Free;
	//-- FList[Index] := Value;

	// make list bigger
	while(Index >= GetCount())
		FList.Add(0);

  	// delete old item when present
  	GpSymbol *item = FList[Index];
  	if(item)
  		delete item;

  	FList[Index] = Value;
}
