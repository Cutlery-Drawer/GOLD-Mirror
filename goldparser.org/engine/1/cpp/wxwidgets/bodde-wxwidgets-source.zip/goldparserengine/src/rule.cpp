//---------------------------------------------------------------------------
//
// Name:        rule.cpp
// Author:      Jorgen Bodde
// Created:     04/05/2004 12:15
// Copyright:   (c) wxWidgets License  
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "rule.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "rule.h"

//----------------------------------------------------------------------------
// rule.cpp
//----------------------------------------------------------------------------

//-- constructor TRule.Create(aTableIndex : integer; aNonTerminal : TSymbol);
GpRule::GpRule(int aTableIndex, GpSymbol * aNonTerminal)
	: FTableIndex(aTableIndex)
	, FRuleNonterminal(aNonTerminal)
{
	//-- inherited Create;
	//-- FRuleSymbols := TObjectList.Create(False);
	//-- FTableIndex := aTableIndex;
	//-- FRuleNonterminal := aNonTerminal;
}

//-- destructor TRule.Destroy;
GpRule::~GpRule()
{
	//-- FRuleSymbols.Free;
	//-- inherited;

	FRuleSymbols.Clear();
}

//--procedure TRule.AddItem(Item: TSymbol);
void GpRule::AddItem(GpSymbol *Item )
{
	//-- FRuleSymbols.Add(Item);
	FRuleSymbols.Add(Item);
};

//--function TRule.Definition: string;
wxString GpRule::GetDefinition() const
{
	//-- var i : integer;
	//-- Result := '';
	//-- for i := 0 to SymbolCount - 1 do Result := Result + Symbols[i].Text + ' ';
	//-- Result := Trim(Result);

	wxString Result;
	for(size_t i = 0; i < GetSymbolCount(); i++)
	{
		Result << GetSymbols(i)->GetText();
		// if last one, no space, saves a trim call.
		if((i+1) < GetSymbolCount())
			Result << " ";
	}

	return Result;
}

//--function TRule.ContainsOneNonTerminal: Boolean;
bool GpRule::ContainsOneNonTerminal()
{
	//-- Result := (SymbolCount = 1) and (Symbols[0].Kind = SymbolTypeNonterminal);
	return (GetSymbolCount() == 1) && (GetSymbols(0)->GetKind() == GpSymbolTypeNonterminal);
}

/* TRuleTable */

//-- constructor TRuleTable.Create;
GpRuleTable::GpRuleTable()
{
	//-- inherited;
	//-- FList := TObjectList.Create(True);
}

//-- destructor TRuleTable.Destroy;
GpRuleTable::~GpRuleTable()
{
	//-- FList.Free;
	//-- inherited;

	Clear();
}

//-- procedure TRuleTable.Add(Value: TObject);
void GpRuleTable::Add(GpRule *Value)
{
	//-- FList.Add(Value);
	FList.Add(Value);
}

//-- procedure TRuleTable.Clear;
void GpRuleTable::Clear()
{
	//-- FList.Clear;

	// owned, delete all present obects
  	GpRule *item;
  	for(size_t i = 0; i < FList.GetCount(); i++)
  	{
  		item = FList[i];
  		if(item)
  			delete item;
  	}

  	FList.Clear();
}


//-- procedure TRuleTable.SetItem(Index: integer; const Value: TRule);
void GpRuleTable::SetItem(GpRule *Item, size_t Index)
{
	//-- if Index >= Count then FList.Count := Index + 1;
	//-- if Assigned(Items[Index]) then Items[Index].Free;
	//-- FList[Index] := Value;

	// make list bigger
	while(Index >= GetCount())
		FList.Add(0);

  	// delete old item when present
  	GpRule *item = GetItem(Index);
  	if(item)
  		delete item;

  	FList[Index] = Item;
}
