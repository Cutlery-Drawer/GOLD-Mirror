//---------------------------------------------------------------------------
//
// Name:        grammarreader.cpp
// Author:      Jorgen Bodde
// Created:     05/02/04
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "grammarreader.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include <wx/wfstream.h>

#include "grammarreader.h"
#include "goldparser.h"

#include <wx/arrimpl.cpp>
WX_DEFINE_OBJARRAY(wxVariantArray);

//-- constructor TGrammarReader.Create(aParser : TGoldParser);
GpGrammarReader::GpGrammarReader(wxGoldParser *aParser)
	: FParser(aParser)
	, FStartSymbol(0)
	//, FEntryCount(0)
	, FBufferPos(-1)
{
	//-- inherited Create;
	//-- FParser := aParser;
}

//-- destructor TGrammarReader.Destroy;
GpGrammarReader::~GpGrammarReader()
{
	//-- inherited Destroy;
}

//-- function TGrammarReader.OpenFile(const FileName: string) : boolean;
bool GpGrammarReader::OpenFile(const wxString &FileName)
{
	//-- var FS : TFileStream;
	//-- begin
	//--   try
	//--     FS := TFileStream.Create(Filename, fmOpenRead);
	//--     try

	bool value = ::wxFileExists(FileName);

	FBufferPos = -1;
	if(value)
	{
	//--       SetLength(FBuffer, FS.Size);
	//--       FS.ReadBuffer(FBuffer[1], FS.Size);
	//--       Result := True;
		wxFileInputStream FS(FileName);
		
		if(FS.IsOk())
		{
			FBuffer.Clear();
			
			int size = FS.GetSize();
			char *p = FBuffer.GetWriteBuf(size);
			FS.Read(p, size);
			FBuffer.UngetWriteBuf(size);

	//--       FBufferPos := 1;

			FBufferPos = 0;
			value = true;
		}

	//--     finally
	//--       FS.Free;
	//--     end;
	//--   except
	}
	
	//--     Result := False;
	//--     FBufferPos := -1;

	return value;
}

//-- function TGrammarReader.GetNextRecord: Boolean;
bool GpGrammarReader::GetNextRecord()
{
	//-- var TypeOfRecord: char;
	//--     i, Entries : Integer;
	//-- begin
	//--   Result := False;
	bool Result = false;
	wxChar TypeOfRecord;

	//--   TypeOfRecord := ReadByte;
	TypeOfRecord = ReadByte();
	int Entries;

	//--    //Structure below is ready for future expansion
	//--   case TypeOfRecord of
	switch(TypeOfRecord)
	{
	//--   'M': begin
	case 'M':
	//--          //Read the number of entry's
	//--          Entries := ReadInt16;

		Entries = ReadInt16();

	//--          VarClear(FCurrentRecord);
		//FCurrentRecord.MakeNull();

	//--          FCurrentRecord := VarArrayCreate([1, Entries], varVariant);
	//--          FEntryCount := Entries;
	//--          FEntryPos := 1;
	//--          for i := 1 to Entries do FCurrentRecord[i] := ReadEntry;
	//--          Result := True;

		FRecords.Clear();
		FEntryPos = 0;

		for(int i = 0; i < Entries; i++)
			FRecords.Add(ReadEntry());

		//FEntryCount = FRecords.GetCount();

		Result = true;
		break;
	//--        end;
	//--   end;
	}

	return Result;
}

//-- function TGrammarReader.ReadUniString: string;
wxString GpGrammarReader::ReadUniString()
{
//-- var uchr: integer;
//-- begin
//--   uchr := ReadInt16;
//--   while (uchr <> 0) do begin
//--     Result := Result + chr(uchr);
//--     uchr := ReadInt16;
//--   end;

	int uchr;
	wxString Value;

	uchr = ReadInt16();
	while(uchr)
	{
		Value << wxChar(uchr);
		uchr = ReadInt16();
	}

	return Value;
}

//-- function TGrammarReader.ReadInt16: Integer;
int GpGrammarReader::ReadInt16()
{
	//-- Result := ord(FBuffer[FBufferPos]) + ord(FBuffer[FBufferPos + 1]) * 256;
	//-- FBufferPos := FBufferPos + 2;

	int Result = 0;

	if((FBufferPos + 1) >= (long)FBuffer.Length())
		return Result;

	long low = (unsigned char)FBuffer.GetChar(FBufferPos), high = (unsigned char)FBuffer.GetChar(FBufferPos+1);
	Result = (low + (high << 8));
	FBufferPos += 2;

	return Result;
}

//-- function TGrammarReader.ReadByte: Char;
wxChar GpGrammarReader::ReadByte()
{
	//-- Result := FBuffer[FBufferPos];
	//-- Inc(FBufferPos);

	if(FBufferPos >= (int)FBuffer.Length())
		return '\0';

	FBufferPos++;
	return FBuffer.GetChar(FBufferPos-1);
}

//-- function TGrammarReader.ReadEntry: Variant;
wxVariant GpGrammarReader::ReadEntry()
{
//-- var EntryType: Char;
//-- begin
//--   EntryType := ReadByte;

	wxChar EntryType = ReadByte();
	wxVariant Result;

//--   case Ord(EntryType) of
	switch(EntryType)
	{
//--   EntryContentEmpty     :  Result := varEmpty;

	case EntryContentEmpty:
		Result.MakeNull();
		break;

//--   EntryContentInteger   :  Result := ReadInt16;
	case EntryContentInteger:
		Result = (long)ReadInt16(); 
		break;

//--   EntryContentBoolean   :  begin
//--                              Result := ReadByte;
//--                              if Result = #1 then Result := True else Result := False;
//--                            end;
	case EntryContentBoolean:
		Result = (bool)(ReadByte() == 1);
		break;

//--   EntryContentString    :  Result := ReadUniString;

	case EntryContentString:
		Result = ReadUniString();
		break;

//--   EntryContentByte      :  Result := ReadByte;
	case EntryContentByte:
		Result = ReadByte();
		break;
	}
//--   end;

	return Result;
}


//-- function TGrammarReader.RetrieveNext: Variant;
wxVariant GpGrammarReader::RetrieveNext()
{
	//-- if FEntryPos <= FEntryCount then begin
	//--    Result := FCurrentRecord[FEntryPos];
	//--    Inc(FEntryPos);
	//-- end else Result := varEmpty;

	wxVariant Result;
	if(FEntryPos < FRecords.GetCount())
	{
		Result = FRecords[FEntryPos];
		FEntryPos ++;
	}
	else
		Result.MakeNull();

	return Result;
}

//-- function TGrammarReader.DoLoadTables: Boolean;
bool GpGrammarReader::DoLoadTables()
{
	//--   var Id : String;
	//--   iDummy1, iDummy2, iDummy3, i : integer;
	//--   strDummy : string;
	//--   NewSymbol : TSymbol;
	//--   NewRule : TRule;
	//--   NewFAState : TFAState;
	//--   bAccept : boolean;
	//--   NewActionTable : TLRActionTable;
	//-- begin

	long val;
	int i;
	wxString Id;
	wxString s;
	int iDummy1, iDummy2, iDummy3;
	wxString strDummy;
	GpSymbol *NewSymbol;
	GpRule *NewRule;
	GpFaState *NewFAState;
	GpLRActionTable *NewActionTable;
	bool bAccept;

	//--   Parser.VariableList.Add('Name', '');
	//--   Parser.VariableList.Add('Version', '');
	//--   Parser.VariableList.Add('Author', '');
	//--   Parser.VariableList.Add('About', '');
	//--   Parser.VariableList.Add('Case Sensitive', '');
	//--   Parser.VariableList.Add('Start Symbol', '');

	wxCHECK(FParser, false);
	FParser->GetVariableList()->Add("Name");
	FParser->GetVariableList()->Add("Version");
	FParser->GetVariableList()->Add("Author");
	FParser->GetVariableList()->Add("About");
	FParser->GetVariableList()->Add("Case Sensitive");
	FParser->GetVariableList()->Add("Start Symbol");
	
	//--   Result := False;
	bool Result = false;

	//--   if FHeader = ReadUniString then begin
	if(ReadUniString().IsSameAs(FHeader))
	{
	//--     while (FBufferPos < Length(FBuffer)) do begin
		while(FBufferPos < (int)FBuffer.Length())
		{
	//--       Result := GetNextRecord;
	//--       Id := String(RetrieveNext);

			Result = GetNextRecord();
			Id = RetrieveNext().GetString();

	//--       case Ord(Id[1]) of
			switch(Id.GetChar(0))
			{
	//--         RecordIdParameters : begin
			case RecordIdParameters:

	//--           Parser.VariableList.Value['Name'] := RetrieveNext;
	//--           Parser.VariableList.Value['Version'] := RetrieveNext;
	//--           Parser.VariableList.Value['Author'] := RetrieveNext;
	//--           Parser.VariableList.Value['About'] := RetrieveNext;
	//--           Parser.VariableList.Value['Case Sensitive'] := RetrieveNext;
	//--           Parser.VariableList.Value['Start Symbol'] := RetrieveNext;
	//--           FStartSymbol := StrToInt(Parser.VariableList.Value['Start Symbol']);
	//--         end;

				FParser->GetVariableList()->SetValue("Name", RetrieveNext().GetString());
				FParser->GetVariableList()->SetValue("Version", RetrieveNext().GetString());
				FParser->GetVariableList()->SetValue("Author", RetrieveNext().GetString());
				FParser->GetVariableList()->SetValue("About", RetrieveNext().GetString());
				FParser->GetVariableList()->SetValue("Case Sensitive", RetrieveNext().GetString());
				
				s = RetrieveNext().GetString();
				FParser->GetVariableList()->SetValue("Start Symbol", s);
				if(s.ToLong(&val))
					FStartSymbol = val;
				else
					FStartSymbol = -1;
				break;

	//--         RecordIdTableCounts : begin
	//--           RetrieveNext; // for i := 0 to RetrieveNext - 1 do Parser.SymbolTable.Add(nil);
	//--           for i := 0 to RetrieveNext do Parser.CharacterSetTable.Add('');
	//--           RetrieveNext; // for i := 0 to RetrieveNext do Parser.RuleTable.Add(nil);
	//--           RetrieveNext; // for i := 0 to RetrieveNext do Parser.DFA.Add(nil);
	//--           RetrieveNext; // for i := 0 to RetrieveNext do Parser.ActionTable.Add(nil, 0, 0);
	//--         end;

			case RecordIdTableCounts:
				RetrieveNext();
				val = RetrieveNext().GetInteger();
				// TODO: Possibly one more (i = 0 to RetrieveNext is really from 0 to 32 and not 31)
				for(i = 0; i <= val; i++)
					FParser->GetCharacterSetTable().Add("");
				RetrieveNext();
				RetrieveNext();
				RetrieveNext();
				break;

	//--         RecordIdInitial : begin
	//--           Parser.InitialDFAState := RetrieveNext;
	//--           Parser.InitialLALRState := RetrieveNext;
	//--         end;

			case RecordIdInitial:
				FParser->SetInitialDFAState(RetrieveNext().GetInteger());
				FParser->SetInitialLALRState(RetrieveNext().GetInteger());
				break;

	//--         RecordIdSymbols : begin
	//--           iDummy1 := RetrieveNext;
	//--           strDummy := RetrieveNext;
	//--           iDummy2 := RetrieveNext;
	//-- 
	//--           NewSymbol := TSymbol.Create(iDummy1, strDummy, iDummy2);
	//-- 
	//--           RetrieveNext;
	//--           Parser.SymbolTable.Items[NewSymbol.TableIndex] := NewSymbol;
	//--         end;

			case RecordIdSymbols:
				iDummy1 = RetrieveNext().GetInteger();
				strDummy = RetrieveNext().GetString();
				iDummy2 = RetrieveNext().GetInteger();

				NewSymbol = new GpSymbol(iDummy1, strDummy, iDummy2);
				
				RetrieveNext();
				FParser->GetSymbolTable()->SetItem(NewSymbol->GetTableIndex(), NewSymbol);
				break;

	//--         RecordIdCharSets : begin
	//--           iDummy1 := RetrieveNext;
	//--           Parser.CharacterSetTable.Strings[iDummy1] := RetrieveNext;
	//--         end;

			case RecordIdCharSets:
				iDummy1 = RetrieveNext().GetInteger();
				FParser->GetCharacterSetTable()[iDummy1] = RetrieveNext().GetString();
				break;

	//--         RecordIdRules : begin
	//--           iDummy1 := RetrieveNext;
	//--           NewRule := TRule.Create(iDummy1, Parser.SymbolTable.Items[RetrieveNext]);
	//--           RetrieveNext;
	//--           while FEntryPos <= FEntryCount do
	//--             NewRule.AddItem(Parser.SymbolTable.Items[RetrieveNext]);
	//--           Parser.RuleTable.Items[NewRule.TableIndex] := NewRule;
	//--         end;

			case RecordIdRules:
				iDummy1 = RetrieveNext().GetInteger();
				NewRule = new GpRule(iDummy1, FParser->GetSymbolTable()->GetItem(RetrieveNext().GetInteger()));
				RetrieveNext();
				while(FEntryPos < FRecords.GetCount())
					NewRule->AddItem(FParser->GetSymbolTable()->GetItem(RetrieveNext().GetInteger()));
				
				FParser->GetRuleTable()->SetItem(NewRule, NewRule->GetTableIndex());
				break;

	//--         RecordIdDFAStates : begin
	//--           NewFAState := TFAState.Create;
	//--           iDummy1 := RetrieveNext;
	//--           bAccept := RetrieveNext;
	//--           if bAccept then NewFAState.AcceptSymbol := RetrieveNext
	//--           else begin
	//--             NewFAState.AcceptSymbol := -1;
	//--             RetrieveNext;
	//--           end;
	//--           RetrieveNext;
	//--           while FEntryPos <= FEntryCount do begin
	//--             strDummy := RetrieveNext;
	//--             iDummy2 := RetrieveNext;
	//--             NewFAState.AddEdge(strDummy, iDummy2);
	//--             RetrieveNext;
	//--           end;
	//--           Parser.DFA.Items[iDummy1] := NewFAState;
	//--         end;

			case RecordIdDFAStates:
				NewFAState = new GpFaState();
				iDummy1 = RetrieveNext().GetInteger();
				bAccept = RetrieveNext();
				if(bAccept)
					NewFAState->SetAcceptSymbol(RetrieveNext().GetInteger());
				else
				{
					NewFAState->SetAcceptSymbol(-1);
					RetrieveNext();
				}
				
				RetrieveNext();
				while(FEntryPos < FRecords.GetCount())
				{
					strDummy = RetrieveNext().GetString();
					iDummy2 = RetrieveNext().GetInteger();
					NewFAState->AddEdge(strDummy, iDummy2);
					RetrieveNext();
				}
				
				FParser->GetDFA()->SetItem(NewFAState, iDummy1);
				break;

	//--         RecordIdLRTables : begin
	//--           NewActionTable := TLRActionTable.Create;
	//--           i := RetrieveNext;
	//--           RetrieveNext;
	//--           while FEntryPos <= FEntryCount do begin
	//--             iDummy1 := RetrieveNext;
	//--             iDummy2 := RetrieveNext;
	//--             iDummy3 := RetrieveNext;
	//--             NewActionTable.Add(Parser.SymbolTable[iDummy1], iDummy2, iDummy3);
	//--             RetrieveNext;
	//--           end;
	//--           Parser.ActionTables.Items[i] := NewActionTable;
	//--         end;

			case RecordIdLRTables:
				NewActionTable = new GpLRActionTable();
				val = RetrieveNext();
				RetrieveNext();
				while(FEntryPos < FRecords.GetCount())
				{
					iDummy1 = RetrieveNext().GetInteger();
					iDummy2 = RetrieveNext().GetInteger();
					iDummy3 = RetrieveNext().GetInteger();
					NewActionTable->Add(FParser->GetSymbolTable()->GetItem(iDummy1), iDummy2, iDummy3);
					RetrieveNext();
				}
				FParser->GetActionTables()->SetItem(NewActionTable, val);
				break;

	//--       end;
			}
	//--     end;
		}
	//--   end;
	}

	//--   Parser.VariableList.Value['Start Symbol'] := TSymbol(Parser.SymbolTable.Items[StrToInt(Parser.VariableList.Value['Start Symbol'])]).Name;
	
	if(FParser->GetSymbolTable()->GetCount() > 0)
	{
		FParser->GetVariableList()->GetValue("Start Symbol").ToLong(&val);
		FParser->GetVariableList()->SetValue("Start Symbol", FParser->GetSymbolTable()->GetItem(val)->GetName()); 
	}

	return Result;
} 

//-- function TGrammarReader.LoadTables(const Stream: TStream): boolean;
bool GpGrammarReader::LoadTables(wxInputStream &Stream)
{
	bool value = false;
	
	//-- Result := OpenStream(Stream) and DoLoadTables;
	if(OpenStream(Stream))
		value = DoLoadTables();

	return value;
}

//-- function TGrammarReader.LoadTables(const FileName: string): boolean;
bool GpGrammarReader::LoadTables(const wxString &FileName)
{
	bool value = false;

	//-- Result := OpenFile(FileName) and DoLoadTables;
	if(OpenFile(FileName))
		value = DoLoadTables();

	return value;
}

//-- function TGrammarReader.OpenStream(const Stream: TStream): boolean;
bool GpGrammarReader::OpenStream(wxInputStream &Stream)
{
	//--  try
	//--    SetLength(FBuffer, Stream.Size);
	//--    Stream.ReadBuffer(FBuffer[1], Stream.Size);
	//--
	//--    Result := True;
	//--    FBufferPos := 1;
	//--  except
	//--    Result := False;
	//--    FBufferPos := -1;
	//--  end;

	int size = Stream.GetSize();
	char *p = FBuffer.GetWriteBuf(size);
	Stream.Read(p, size);
	FBuffer.UngetWriteBuf(size);

	FBufferPos = 0;

	return (FBuffer.Length() > 0);
}
