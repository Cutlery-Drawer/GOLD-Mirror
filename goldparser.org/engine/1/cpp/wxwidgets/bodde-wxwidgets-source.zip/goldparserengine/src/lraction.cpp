//---------------------------------------------------------------------------
//
// Name:        lraction.cpp
// Author:      Jorgen Bodde
// Created:     5/4/2004 6:32PM
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "lraction.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "lraction.h"

GpLRAction::GpLRAction(GpSymbol *Symbol, int Action, int Value)
	: FSymbol(Symbol)
	, FAction(Action)
	, FValue(Value)
{
}

/* TLRActionTable */

//-- function TLRActionTable.ActionIndexForSymbol(SymbolIndex: Integer): Integer;
int GpLRActionTable::ActionIndexForSymbol(int SymbolIndex)
{
	//-- var i : integer;
	//-- begin
	//--   Result := -1;
	//--   for i := 0 to Count - 1 do
	//--     if Items[i].Symbol.TableIndex = SymbolIndex then begin
	//--       Result := i;
	//--       Exit;
	//--     end;
	//-- end;

	for(size_t i = 0; i < FList.GetCount(); i++)
	{
		if(GetItem(i)->GetSymbol()->GetTableIndex() == SymbolIndex) 
			return i;
	}
	return -1;
}

//-- procedure TLRActionTable.Add(TheSymbol: TSymbol; Action: Integer; Value: Integer);
void GpLRActionTable::Add(GpSymbol *TheSymbol, int Action, int Value)
{
	//-- FList.Add(TLRAction.Create);
	//-- Items[Count - 1].FSymbol := TheSymbol;
	//-- Items[Count - 1].FAction := Action;
	//-- Items[Count - 1].FValue := Value;

	FList.Add(new GpLRAction(TheSymbol, Action, Value));
};

//-- constructor TLRActionTable.Create;
GpLRActionTable::GpLRActionTable()
{
	//-- inherited;
	//-- FList := TObjectList.Create(True);
}

//-- destructor TLRActionTable.Destroy;
GpLRActionTable::~GpLRActionTable()
{
	//-- FList.Free;
	//-- inherited;
  	
	GpLRAction *item;
  	for(size_t i = 0; i < FList.GetCount(); i++)
  	{
  		item = FList[i];
  		if(item)
  			delete item;
  	}
  	
  	FList.Clear();
}


//-- procedure TLRActionTable.SetItem(Index: integer; const Value: TLRAction);
void GpLRActionTable::SetItem(GpLRAction *Value, size_t Index)
{
	//-- if Index >= Count then FList.Count := Index + 1;
	//-- if Assigned(Items[Index]) then Items[Index].Free;
	//-- FList[Index] := Value;
	
	// make list bigger
	while(Index >= GetCount()) 
		FList.Add(0);

  	// delete old item when present
  	GpLRAction *item = GetItem(Index);
  	if(item) 
  		delete item;
  		
  	FList[Index] = Value;
}

/* TLRActionTables */

//-- constructor TLRActionTables.Create;
GpLRActionTables::GpLRActionTables()
{
	//-- inherited;
	//-- FList := TObjectList.Create(True);
}

//-- destructor TLRActionTables.Destroy;
GpLRActionTables::~GpLRActionTables()
{
	//-- FList.Free;
	//-- inherited;

	GpLRActionTable *item;
  	for(size_t i = 0; i < FList.GetCount(); i++)
  	{
  		item = FList[i];
  		if(item)
  			delete item;
  	}
  	
  	FList.Clear();
}

//-- procedure TLRActionTables.SetItem(Index: integer; const Value: TLRActionTable);
void GpLRActionTables::SetItem(GpLRActionTable *Value, size_t Index)
{
	//-- if Index >= Count then FList.Count := Index + 1;
	//-- if Assigned(Items[Index]) then Items[Index].Free;
	//-- FList[Index] := Value;

	// make list bigger
	while(Index >= GetCount()) 
		FList.Add(0);

  	// delete old item when present
  	GpLRActionTable *item = GetItem(Index);
  	if(item) 
  		delete item;
  		
  	FList[Index] = Value;
}

