//---------------------------------------------------------------------------
//
// Name:        sourcefeeder.cpp
// Author:      Jorgen Bodde
// Created:     5/4/2004 7:11PM
// Copyright:   (c) wxWidgets License
//
//---------------------------------------------------------------------------

//#ifdef __GNUG__
//    #pragma implementation "sourcefeeder.h"
//#endif

/* for compilers that support precompilation
   includes "wx/wx.h" */

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "sourcefeeder.h"

//-- constructor TSourceFeeder.Create;
GpSourceFeeder::GpSourceFeeder()
{
	//-- inherited;
	//-- FStream := TStringStream.Create('');
}

//-- destructor TSourceFeeder.Destroy;
GpSourceFeeder::~GpSourceFeeder()
{
	//-- Stream.Free;
	//-- inherited;
}

//-- function TSourceFeeder.ReadFromBuffer(Size: Integer; DiscardReadText: Boolean; ReturnAllText: Boolean): String;
wxString GpSourceFeeder::ReadFromBuffer(size_t Size, bool DiscardReadText, bool ReturnAllText)
{
	//-- var SavePos : integer;
	//--     Available: Integer;
	//-- begin
	//--   SavePos := Stream.Position;
	//-- 
	//--   if (Stream.Position - 1) + Size > Stream.Size
	//--   then Available := Stream.Size - Stream.Position
	//--   else Available := Size;
	//-- 
	//--   if ReturnAllText then Result := Stream.ReadString(Available)
	//--   else Result := Copy(Stream.DataString, Stream.Position + Size, 1);
	//-- 
	//--   if not DiscardReadText then Stream.Position := SavePos;
	//-- end;

	wxString Result;
	int SavePos = FStream.GetPosition(), Available;

	if((FStream.GetPosition() + Size) > FStream.GetSize())
		Available = FStream.GetSize() - FStream.GetPosition();
	else
		Available = Size;

	// TODO: This is a weird construction. Why copy only one character from a size position? 
	// maybe Size means more like 'offset' in this construction. But oh well.
	if(ReturnAllText)
		Result = FStream.ReadString(Available);
	else
	{
		int Pos = FStream.GetPosition() + (Size-1);
		if(Pos < FStream.GetSize())
			Result = FStream.GetDataString().GetChar(Pos);
	}

	if(!DiscardReadText)
		FStream.SetPosition(SavePos);

	return Result;
}

//-- function TSourceFeeder.ReadLine: String;
wxString GpSourceFeeder::ReadLine()
{
	//-- var EndReached: Boolean;
	//--     ch: string;
	//-- begin
	//--   EndReached := False;
	//--   while not (EndReached) and (not Done) do begin
	//--     ch := ReadFromBuffer(1, True, True);
	//--     if (ch = #10) or (ch = #13) then begin
	//--       ch := ReadFromBuffer(1, False, True);
	//--       if (ch = #10) or (ch = #13) then ReadFromBuffer(1, True, True);
	//--       EndReached := True;
	//--     end else Result := Result + ch;
	//--   end;

	wxString Result;
	bool EndReached = false;
	while(!EndReached && !Done())
	{
		wxChar ch = FStream.GetCh();
		if(ch == '\n' || ch == '\r')
		{
			// check for another '\n' or '\r'
			ch = FStream.Peek(); 
			if(ch == '\n' || ch == '\r')
				FStream.GetCh();
			EndReached = true;
		}
		else
			Result << ch;
	}

	return Result;
}

//-- procedure TSourceFeeder.SetText(const Value: string);
void GpSourceFeeder::SetText(const wxString &Text)
{
	//-- FStream.Size := 0;
	//-- FStream.WriteString(Value);
	//-- FStream.Position := 0;

	FStream.SetDataString(Text);
}
