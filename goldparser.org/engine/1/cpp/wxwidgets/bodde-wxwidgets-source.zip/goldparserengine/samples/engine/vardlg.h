/////////////////////////////////////////////////////////////////////////////
// Name:        vardlg.h
// Purpose:     
// Author:      Jorgen Bodde
// Modified by: 
// Created:     05/16/04 12:53:01
// RCS-ID:      
// Copyright:   (c) Jorgen Bodde, based on wxWidgets license
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _VARDLG_H_
#define _VARDLG_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "vardlg.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/valtext.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_DIALOG 10006
#define SYMBOL_VARDIALOG_STYLE wxCAPTION|wxSYSTEM_MENU|wxCLOSE_BOX
#define SYMBOL_VARDIALOG_TITLE _("Enter variable value")
#define SYMBOL_VARDIALOG_IDNAME ID_DIALOG
#define SYMBOL_VARDIALOG_SIZE wxSize(400, 300)
#define SYMBOL_VARDIALOG_POSITION wxDefaultPosition
#define ID_TEXTCTRL2 10009
#define ID_TEXTCTRL3 10010
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif

/*!
 * VarDialog class declaration
 */

class VarDialog: public wxDialog
{    
    DECLARE_CLASS( VarDialog )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    VarDialog( );
    VarDialog( wxWindow* parent, wxWindowID id = SYMBOL_VARDIALOG_IDNAME, const wxString& caption = SYMBOL_VARDIALOG_TITLE, const wxPoint& pos = SYMBOL_VARDIALOG_POSITION, const wxSize& size = SYMBOL_VARDIALOG_SIZE, long style = SYMBOL_VARDIALOG_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_VARDIALOG_IDNAME, const wxString& caption = SYMBOL_VARDIALOG_TITLE, const wxPoint& pos = SYMBOL_VARDIALOG_POSITION, const wxSize& size = SYMBOL_VARDIALOG_SIZE, long style = SYMBOL_VARDIALOG_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin VarDialog event handler declarations

////@end VarDialog event handler declarations

////@begin VarDialog member function declarations

    wxString GetVarName() const { return _VarName ; }
    void SetVarName(wxString value) { _VarName = value ; }

    wxString GetIntValue() const { return _IntValue ; }
    void SetIntValue(wxString value) { _IntValue = value ; }

////@end VarDialog member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

    void SetReadOnly() {
        _VarNameText->Enable(false);
    };

////@begin VarDialog member variables
    wxTextCtrl* _VarNameText;
    wxString _VarName;
    wxString _IntValue;
////@end VarDialog member variables
};

#endif
    // _VARDLG_H_
