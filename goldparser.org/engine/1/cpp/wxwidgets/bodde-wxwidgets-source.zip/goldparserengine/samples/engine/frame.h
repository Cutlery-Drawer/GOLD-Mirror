/////////////////////////////////////////////////////////////////////////////
// Name:        frame.h
// Purpose:     
// Author:      Jorgen Bodde
// Modified by: 
// Created:     05/12/04 21:49:26
// RCS-ID:      
// Copyright:   (c) Jorgen Bodde, based on wxWidgets license
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _FRAME_H_
#define _FRAME_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "frame.cpop"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
#include "wx/listctrl.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
class wxListCtrl;
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_FRAME 10000
#define SYMBOL_GPTESTFRAME_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX
#define SYMBOL_GPTESTFRAME_TITLE _("Gp Engine Test")
#define SYMBOL_GPTESTFRAME_IDNAME ID_FRAME
#define SYMBOL_GPTESTFRAME_SIZE wxSize(400, 390)
#define SYMBOL_GPTESTFRAME_POSITION wxDefaultPosition
#define ID_PANEL 10001
#define ID_LISTCTRL 10004
#define ID_ADD_VAR 10005
#define ID_CHANGE_VAL 10007
#define ID_TEXTCTRL1 10008
#define ID_TEXTCTRL 10002
#define ID_TEST_ENG 10003
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif

/*!
 * GpTestFrame class declaration
 */

#include "variables.h"

class GpTestFrame: public wxFrame
{    
    DECLARE_CLASS( GpTestFrame )
    DECLARE_EVENT_TABLE()

private:
	GpVariableList _vars;

	void AddVarToList(const wxString &var, int value);

public:
    /// Constructors
    GpTestFrame( );
    GpTestFrame( wxWindow* parent, wxWindowID id = SYMBOL_GPTESTFRAME_IDNAME, const wxString& caption = SYMBOL_GPTESTFRAME_TITLE, const wxPoint& pos = SYMBOL_GPTESTFRAME_POSITION, const wxSize& size = SYMBOL_GPTESTFRAME_SIZE, long style = SYMBOL_GPTESTFRAME_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_GPTESTFRAME_IDNAME, const wxString& caption = SYMBOL_GPTESTFRAME_TITLE, const wxPoint& pos = SYMBOL_GPTESTFRAME_POSITION, const wxSize& size = SYMBOL_GPTESTFRAME_SIZE, long style = SYMBOL_GPTESTFRAME_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin GpTestFrame event handler declarations

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_ADD_VAR
    void OnAddVarClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_CHANGE_VAL
    void OnChangeValClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_TEST_ENG
    void OnTestEngClick( wxCommandEvent& event );

////@end GpTestFrame event handler declarations

////@begin GpTestFrame member function declarations


    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end GpTestFrame member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();


////@begin GpTestFrame member variables
    wxListCtrl* _VarList;
    wxTextCtrl* _FormulaText;
    wxTextCtrl* _LogWindow;
////@end GpTestFrame member variables
};

#endif
    // _FRAME_H_
