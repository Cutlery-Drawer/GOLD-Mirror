
/////////////////////////////////////////////////////////////////////////////
// Name:        GpTester.cpp
// Purpose:     GpTester Application
// Author:      Based on minimal.cpp by Julian Smart
// Modified by:
// Created:     04/30/04
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// SYMBOL_CONSTANTS
#define SYMBOL_EOF           0  /* (EOF) */
#define SYMBOL_ERROR         1  /* (Error) */
#define SYMBOL_WHITESPACE    2  /* (Whitespace) */
#define SYMBOL_MINUS         3  /* '-' */
#define SYMBOL_AMP           4  /* & */
#define SYMBOL_LPARAN        5  /* '(' */
#define SYMBOL_RPARAN        6  /* ')' */
#define SYMBOL_TIMES         7  /* '*' */
#define SYMBOL_COMMA         8  /* ; */
#define SYMBOL_DIV           9  /* / */
#define SYMBOL_PLUS          10  /* '+' */
#define SYMBOL_EQ            11  /* = */
#define SYMBOL_ID            12  /* Id */
#define SYMBOL_NUMBERLITERAL 13  /* NumberLiteral */
#define SYMBOL_RUNDE         14  /* runde */
#define SYMBOL_STRINGLITERAL 15  /* StringLiteral */
#define SYMBOL_ADDEXP        16  /* <Add Exp> */
#define SYMBOL_FUNCTION2OP   17  /* <Function 2 Op> */
#define SYMBOL_MULTEXP       18  /* <Mult Exp> */
#define SYMBOL_NEGATEEXP     19  /* <Negate Exp> */
#define SYMBOL_STATEMENT     20  /* <Statement> */
#define SYMBOL_VALUE         21  /* <Value> */

// RULE_CONSTANTS
#define RULE_STATEMENTIDEQ          0  /* <Statement> ::= Id = <Add Exp> */
#define RULE_ADDEXPPLUS             1  /* <Add Exp> ::= <Mult Exp> '+' <Add Exp> */
#define RULE_ADDEXPMINUS            2  /* <Add Exp> ::= <Mult Exp> '-' <Add Exp> */
#define RULE_ADDEXPAMP              3  /* <Add Exp> ::= <Mult Exp> & <Add Exp> */
#define RULE_ADDEXP                 4  /* <Add Exp> ::= <Mult Exp> */
#define RULE_MULTEXPTIMES           5  /* <Mult Exp> ::= <Negate Exp> '*' <Mult Exp> */
#define RULE_MULTEXPDIV             6  /* <Mult Exp> ::= <Negate Exp> / <Mult Exp> */
#define RULE_MULTEXP                7  /* <Mult Exp> ::= <Negate Exp> */
#define RULE_NEGATEEXPMINUS         8  /* <Negate Exp> ::= '-' <Value> */
#define RULE_NEGATEEXP              9  /* <Negate Exp> ::= <Value> */
#define RULE_VALUEID                10  /* <Value> ::= Id */
#define RULE_VALUESTRINGLITERAL     11  /* <Value> ::= StringLiteral */
#define RULE_VALUENUMBERLITERAL     12  /* <Value> ::= NumberLiteral */
#define RULE_VALUELPARANRPARAN      13  /* <Value> ::= '(' <Add Exp> ')' */
#define RULE_VALUELPARANCOMMARPARAN 14  /* <Value> ::= <Function 2 Op> '(' <Add Exp> , <Add Exp> ')' */
#define RULE_FUNCTION2OPRUNDE       15  /* <Function 2 Op> ::= runde */

#include "frame.h"

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWindows headers)
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/filename.h>

// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------

// the application icon (under Windows and OS/2 it is in resources)
#if defined(__WXGTK__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__) || defined(__WXX11__)
    #include "mondrian.xpm"
#endif

// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

// Define a new application type, each program should derive a class from wxApp
class GpTestApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------

    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
};

// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also declares the accessor function
// wxGetApp() which will return the reference of the right type (i.e. GpTestApp and
// not wxApp)
IMPLEMENT_APP(GpTestApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

// 'Main program' equivalent: the program execution "starts" here
bool GpTestApp::OnInit()
{
    // create the main application window
    GpTestAppFrame *frame = new GpTestAppFrame(NULL);

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    frame->Show(TRUE);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned FALSE here, the
    // application would exit immediately.
    return TRUE;
}
