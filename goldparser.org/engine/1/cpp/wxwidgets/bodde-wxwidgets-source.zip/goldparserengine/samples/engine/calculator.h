#ifndef __GOLDPARSER_H_
#define __GOLDPARSER_H_

// Symbols
#define Symbol_Eof           0  // (EOF)
#define Symbol_Error         1  // (Error)
#define Symbol_Whitespace    2  // (Whitespace)
#define Symbol_Minus         3  // '-'
#define Symbol_Percent       4  // '%'
#define Symbol_Lparan        5  // '('
#define Symbol_Rparan        6  // ')'
#define Symbol_Times         7  // '*'
#define Symbol_Div           8  // '/'
#define Symbol_Plus          9  // '+'
#define Symbol_Id            10 // Id
#define Symbol_Numberliteral 11 // NumberLiteral
#define Symbol_Stringliteral 12 // StringLiteral
#define Symbol_Addexp        13 // <Add Exp>
#define Symbol_Multexp       14 // <Mult Exp>
#define Symbol_Negateexp     15 // <Negate Exp>
#define Symbol_Value         16 // <Value>

// Rules
#define Rule_Addexp_Plus         0  // <Add Exp> ::= <Mult Exp> '+' <Add Exp>
#define Rule_Addexp_Minus        1  // <Add Exp> ::= <Mult Exp> '-' <Add Exp>
#define Rule_Addexp              2  // <Add Exp> ::= <Mult Exp>
#define Rule_Multexp_Times       3  // <Mult Exp> ::= <Negate Exp> '*' <Mult Exp>
#define Rule_Multexp_Div         4  // <Mult Exp> ::= <Negate Exp> '/' <Mult Exp>
#define Rule_Multexp_Percent     5  // <Mult Exp> ::= <Negate Exp> '%' <Mult Exp>
#define Rule_Multexp             6  // <Mult Exp> ::= <Negate Exp>
#define Rule_Negateexp_Minus     7  // <Negate Exp> ::= '-' <Value>
#define Rule_Negateexp           8  // <Negate Exp> ::= <Value>
#define Rule_Value_Id            9  // <Value> ::= Id
#define Rule_Value_Stringliteral 10 // <Value> ::= StringLiteral
#define Rule_Value_Numberliteral 11 // <Value> ::= NumberLiteral
#define Rule_Value_Lparan_Rparan 12 // <Value> ::= '(' <Add Exp> ')'

#include "goldparser.h"

/** \class GoldParserCtrl

	This class loads the proper grammar file, and uses the wxGoldParser object to parse the grammar and call
	the reduce methods accordingly to act upon the reductions.

	Fill this class with your methods, and act upon the reduction cases, to compile your own syntax tree,
	or perform calculations of any kind. See samples in the goldparser engine code for wxWidgets for more
	clarification.
*/

class GoldParserCtrl
{
private:
	wxGoldParser *_parser;
	GpVariableList *_vars;
	int _result;

public:
	// TODO: Create with grammar file already in place. Like GoldParserCtrl("grammar.cgt"); and
	// use GoldParserCtrl::IsOk to check op it
	
	GoldParserCtrl();
	~GoldParserCtrl();
	
	/** Sets the grammar file, and loads it. Whenever the grammar can't be loaded, the
		method returns with -1 for invalid file, and -2 for invalid grammar. if it returns
		with 0, everything is ok */
	int SetGrammarFile(const wxString &filename);

	/** Calls the parser. This will only work when there is a valid grammar file loaded.
	    It will return with 0 if the grammar was succesfully accepted, -1 means there were
	    errors */
	int Parse(const wxString &source, bool trimReductions = false, wxArrayString *messages = 0, wxArrayString *errors = 0);

	/** The heart of the parser. Every reduction is acted upon. For example when you have the reduction
	    <Result> ::= <RValue> '+' <LValue> and the <RValue>, <LValue> are numbers, you can return in the
	    current reduction something like this:

	    \code
	    // <Result> ::= <RValue> '+' <LValue>
	    case Result_RValue_Plus_LValue:
	    	R->SetTag(R->GetToken(0)->GetTag() + R->GetToken(2)->GetTag());
	    	break;

	 	// now where Result has been used in the rule, can be used to get that token back
	 	// again, like

	 	// <PrintStat> ::= print <Result>;
	 	case PrintStat_print_Result:
	 		printf("The value is %i", R->GetToken(1)->GetTag());
	 		break;

	 	// this way per reduction tree the user can act upon the current reduction and
	 	// send a value back up..

	    \endcode
	*/
	int ReplaceReduction(GpReduction *R, wxArrayString *errors = 0, wxArrayString *messages = 0);

	void SetVariableList(GpVariableList *list) {
		_vars = list;
	};

	int GetResult() const {
		return _result;
	};
};

#endif
