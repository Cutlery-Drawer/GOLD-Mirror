/////////////////////////////////////////////////////////////////////////////
// Name:        frame.h
// Purpose:     
// Author:      Jorgen Bodde
// Modified by: 
// Created:     05/11/04 19:48:19
// RCS-ID:      
// Copyright:   (c) Jorgen Bodde, distributed under wxWidgets license
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _FRAME_H_
#define _FRAME_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "frame.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
#include "wx/notebook.h"
#include "wx/listctrl.h"
#include "wx/treectrl.h"
////@end includes

#include "goldparser.h"

/*!
 * Forward declarations
 */

////@begin forward declarations
class wxListCtrl;
class wxTreeCtrl;
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_FRAME 10000
#define SYMBOL_GPTESTAPPFRAME_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxNO_FULL_REPAINT_ON_RESIZE
#define SYMBOL_GPTESTAPPFRAME_TITLE _("Test The Grammar")
#define SYMBOL_GPTESTAPPFRAME_IDNAME ID_FRAME
#define SYMBOL_GPTESTAPPFRAME_SIZE wxSize(599, 528)
#define SYMBOL_GPTESTAPPFRAME_POSITION wxDefaultPosition
#define ID_PANEL 10001
#define ID_CGT_PATH 10002
#define ID_BROWSE_DIR 10004
#define ID_PARSE_AREA 10003
#define ID_TRIM_REDUCTIONS 10005
#define ID_GO_PARSE 10006
#define ID_NOTEBOOK 10007
#define ID_PANEL1 10008
#define ID_TEXT_PARSETREE 10011
#define ID_PANEL2 10009
#define ID_MESSAGES 10012
#define ID_PANEL3 10010
#define ID_TREECTRL 10013
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif

/*!
 * GpTestAppFrame class declaration
 */

class GpTestAppFrame: public wxFrame
{    
    DECLARE_CLASS( GpTestAppFrame )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    GpTestAppFrame( );
    GpTestAppFrame( wxWindow* parent, wxWindowID id = SYMBOL_GPTESTAPPFRAME_IDNAME, const wxString& caption = SYMBOL_GPTESTAPPFRAME_TITLE, const wxPoint& pos = SYMBOL_GPTESTAPPFRAME_POSITION, const wxSize& size = SYMBOL_GPTESTAPPFRAME_SIZE, long style = SYMBOL_GPTESTAPPFRAME_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_GPTESTAPPFRAME_IDNAME, const wxString& caption = SYMBOL_GPTESTAPPFRAME_TITLE, const wxPoint& pos = SYMBOL_GPTESTAPPFRAME_POSITION, const wxSize& size = SYMBOL_GPTESTAPPFRAME_SIZE, long style = SYMBOL_GPTESTAPPFRAME_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin GpTestAppFrame event handler declarations

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BROWSE_DIR
    void OnBrowseDirClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_GO_PARSE
    void OnGoParseClick( wxCommandEvent& event );

////@end GpTestAppFrame event handler declarations

////@begin GpTestAppFrame member function declarations


    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end GpTestAppFrame member function declarations

private:
	void AddToReport(const wxString &Msg1, const wxString &Msg2, const wxString &Msg3, 
			         const wxString &Msg4, int LN);

	void DrawTTree(GpReduction *Reduction);
	void DrawTTree_R(GpReduction *R, wxTreeItemId ParentNode);

	void DrawReductionTree(GpReduction *TheReduction);
	void DrawReduction(GpReduction *TheReduction, int Indent);

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin GpTestAppFrame member variables
    wxTextCtrl* _CgtPath;
    wxTextCtrl* _TestText;
    wxCheckBox* _TrimReductions;
    wxTextCtrl* _TextParseTree;
    wxListCtrl* _Messages;
    wxTreeCtrl* _TTree;
////@end GpTestAppFrame member variables
};

#endif
    // _FRAME_H_
