/////////////////////////////////////////////////////////////////////////////
// Name:        frame.cpp
// Purpose:     
// Author:      Jorgen Bodde
// Modified by: 
// Created:     05/11/04 19:48:19
// RCS-ID:      
// Copyright:   (c) Jorgen Bodde, distributed under wxWidgets license
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "frame.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include <wx/filename.h>
#include <wx/filedlg.h>

#include "frame.h"
#include "mondrian.xpm"

////@begin XPM images
////@end XPM images

/*!
 * GpTestAppFrame type definition
 */

IMPLEMENT_CLASS( GpTestAppFrame, wxFrame )

/*!
 * GpTestAppFrame event table definition
 */

BEGIN_EVENT_TABLE( GpTestAppFrame, wxFrame )

////@begin GpTestAppFrame event table entries
    EVT_BUTTON( ID_BROWSE_DIR, GpTestAppFrame::OnBrowseDirClick )

    EVT_BUTTON( ID_GO_PARSE, GpTestAppFrame::OnGoParseClick )

////@end GpTestAppFrame event table entries

END_EVENT_TABLE()

/*!
 * GpTestAppFrame constructors
 */

GpTestAppFrame::GpTestAppFrame( )
{
}

GpTestAppFrame::GpTestAppFrame( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create( parent, id, caption, pos, size, style );
}

/*!
 * GpTestFrame creator
 */

bool GpTestAppFrame::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin GpTestAppFrame member initialisation
    _CgtPath = NULL;
    _TestText = NULL;
    _TrimReductions = NULL;
    _TextParseTree = NULL;
    _Messages = NULL;
    _TTree = NULL;
////@end GpTestAppFrame member initialisation

////@begin GpTestAppFrame creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end GpTestAppFrame creation

	SetIcon(wxIcon(mondrian_xpm));

    // set the columns in the wxListCtrl
    _Messages->InsertColumn(0, wxT("Messages"), wxLIST_FORMAT_LEFT, 200);
    _Messages->InsertColumn(1, wxT("Text1"), wxLIST_FORMAT_LEFT, 100);
    _Messages->InsertColumn(2, wxT("Text2"), wxLIST_FORMAT_LEFT, 100);
    _Messages->InsertColumn(3, wxT("Text3"), wxLIST_FORMAT_LEFT, 100);
    _Messages->InsertColumn(4, wxT("Line"));
   
	wxFileName path;
	path.AssignCwd();

	path.SetFullName("simple.cgt");
	_CgtPath->SetValue(path.GetFullPath());

    return TRUE;
}

/*!
 * Control creation for GpTestFrame
 */

void GpTestAppFrame::CreateControls()
{    
////@begin GpTestAppFrame content construction

    GpTestAppFrame* item1 = this;

    wxPanel* item2 = new wxPanel( item1, ID_PANEL, wxDefaultPosition, wxSize(599, -1), wxNO_BORDER|wxTAB_TRAVERSAL );

    wxBoxSizer* item3 = new wxBoxSizer(wxVERTICAL);
    item2->SetSizer(item3);
    item2->SetAutoLayout(TRUE);

    wxStaticBox* item4Static = new wxStaticBox(item2, wxID_ANY, _("GOLD Parser Input"));
    wxStaticBoxSizer* item4 = new wxStaticBoxSizer(item4Static, wxHORIZONTAL);
    item3->Add(item4, 0, wxGROW|wxALL|wxADJUST_MINSIZE, 5);

    wxFlexGridSizer* item5 = new wxFlexGridSizer(2, 2, 0, 0);
    item5->AddGrowableCol(1);
    item4->Add(item5, 1, wxGROW|wxALL, 5);

    wxStaticText* item6 = new wxStaticText( item2, wxID_STATIC, _("CGT File"), wxDefaultPosition, wxDefaultSize, 0 );
    item5->Add(item6, 0, wxALIGN_LEFT|wxALIGN_TOP|wxALL|wxADJUST_MINSIZE, 5);

    wxBoxSizer* item7 = new wxBoxSizer(wxHORIZONTAL);
    item5->Add(item7, 0, wxGROW|wxALIGN_TOP, 5);

    wxTextCtrl* item8 = new wxTextCtrl( item2, ID_CGT_PATH, _T(""), wxDefaultPosition, wxSize(433, -1), 0 );
    _CgtPath = item8;
    item7->Add(item8, 1, wxALIGN_TOP|wxALL, 5);

    wxButton* item9 = new wxButton( item2, ID_BROWSE_DIR, _("..."), wxDefaultPosition, wxSize(19, -1), wxBU_EXACTFIT );
    item7->Add(item9, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxStaticText* item10 = new wxStaticText( item2, wxID_STATIC, _("Test input"), wxDefaultPosition, wxDefaultSize, 0 );
    item5->Add(item10, 0, wxALIGN_LEFT|wxALIGN_TOP|wxALL|wxADJUST_MINSIZE, 5);

    wxTextCtrl* item11 = new wxTextCtrl( item2, ID_PARSE_AREA, _("b+c/(d*e)-c\n"), wxDefaultPosition, wxSize(457, 73), wxTE_MULTILINE );
    _TestText = item11;
    item5->Add(item11, 1, wxGROW|wxGROW|wxALL, 5);

    wxFlexGridSizer* item12 = new wxFlexGridSizer(1, 3, 0, 0);
    item12->AddGrowableRow(0);
    item12->AddGrowableCol(0);
    item12->AddGrowableCol(2);
    item3->Add(item12, 0, wxGROW, 5);

    wxCheckBox* item13 = new wxCheckBox( item2, ID_TRIM_REDUCTIONS, _("Trim reductions"), wxDefaultPosition, wxDefaultSize, 0 );
    _TrimReductions = item13;
    item13->SetValue(TRUE);
    item12->Add(item13, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    item12->Add(5, 5, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* item15 = new wxButton( item2, ID_GO_PARSE, _("&Parse"), wxDefaultPosition, wxDefaultSize, 0 );
    item12->Add(item15, 0, wxALIGN_RIGHT|wxALIGN_TOP|wxALL, 5);

    wxNotebook* item16 = new wxNotebook( item2, ID_NOTEBOOK, wxDefaultPosition, wxSize(200, 200), wxNB_TOP );
    wxPanel* item17 = new wxPanel( item16, ID_PANEL1, wxDefaultPosition, wxSize(100, 80), wxTAB_TRAVERSAL );
    wxBoxSizer* item18 = new wxBoxSizer(wxHORIZONTAL);
    item17->SetSizer(item18);
    item17->SetAutoLayout(TRUE);
    wxTextCtrl* item19 = new wxTextCtrl( item17, ID_TEXT_PARSETREE, _T(""), wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );
    _TextParseTree = item19;
    item18->Add(item19, 1, wxGROW, 5);
    item16->AddPage(item17, _("Ansi Reduction Tree"));
    wxPanel* item20 = new wxPanel( item16, ID_PANEL2, wxDefaultPosition, wxSize(100, 80), wxTAB_TRAVERSAL );
    wxBoxSizer* item21 = new wxBoxSizer(wxHORIZONTAL);
    item20->SetSizer(item21);
    item20->SetAutoLayout(TRUE);
    wxListCtrl* item22 = new wxListCtrl( item20, ID_MESSAGES, wxDefaultPosition, wxSize(100, 100), wxLC_REPORT|wxLC_SINGLE_SEL );
    _Messages = item22;
    item21->Add(item22, 1, wxGROW, 5);
    item16->AddPage(item20, _("Messages"));
    wxPanel* item23 = new wxPanel( item16, ID_PANEL3, wxDefaultPosition, wxSize(100, 80), wxTAB_TRAVERSAL );
    wxBoxSizer* item24 = new wxBoxSizer(wxHORIZONTAL);
    item23->SetSizer(item24);
    item23->SetAutoLayout(TRUE);
    wxTreeCtrl* item25 = new wxTreeCtrl( item23, ID_TREECTRL, wxDefaultPosition, wxSize(100, 100), wxTR_HAS_BUTTONS |wxTR_SINGLE );
    _TTree = item25;
    item24->Add(item25, 1, wxGROW, 5);
    item16->AddPage(item23, _("Treeview Reduction"));
    item3->Add(item16, 1, wxGROW, 5);

////@end GpTestAppFrame content construction
}

/*!
 * Should we show tooltips?
 */

bool GpTestAppFrame::ShowToolTips()
{
    return TRUE;
}
/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_GO_PARSE
 */

void GpTestAppFrame::OnGoParseClick( wxCommandEvent& event )
{
	//-- var
	//--    GP: TGOLDParser;
	//--    txt: string;
	//--    Response: Integer;
	//--    Done: Boolean;
	//--    ReductionNumber: Integer;
	//--    n: Integer;
	//-- begin
	//-- 

	wxString str, msg;
	int Response;
	size_t n;
	
	//--    SL.Clear;
	_Messages->DeleteAllItems();	

	//--    ReductionNumber := 0;
	int ReductionNumber = 0; 

	//--    GP := TGOLDParser.Create;

	wxGoldParser *GP = new wxGoldParser();

	//--    if GP.LoadCompiledGrammar(txtCGTFilePath.Text) then
	//--    begin
	if(GP->LoadCompiledGrammar(_CgtPath->GetValue()))
	{
	
	//--       txt := txtTestInput.Text;
		wxString txt = _TestText->GetValue();
	//-- 
	//--       GP.OpenTextString(txt);
	//--       GP.TrimReductions := chkTrimReductions.Checked;
	//--       txtParseTree.Clear;

		GP->OpenTextString(txt);
		GP->SetTrimReductions(_TrimReductions->GetValue());
		_TextParseTree->SetValue("");

	//-- 
	//--       Done := False;
	//--       while not Done do
	//--       begin
		bool Done = false;
		while(!Done)
		{
	//--          Response := GP.Parse;
			Response = GP->Parse();

	//--          case Response of
			switch(Response)
			{
	//--          gpMsgLexicalError:
	//--             begin
	//--                AddToReport('Lexical Error', 'Cannot recognize token', GP.CurrentToken.DataVar, '', GP.CurrentLineNumber);
	//--                txtParseTree.Text := 'Line ' + IntToStr(GP.CurrentLineNumber) + ': Lexical Error: Cannot recognize token: ' + GP.CurrentToken.DataVar;
	//--                Done := True;
	//--             end;

			case gpMsgLexicalError:
				AddToReport("Lexical Error", "Cannot recognise token", GP->GetCurrentToken()->GetDataVar(), "", 
						    GP->GetCurrentLineNumber());
				str.Printf("Line %i: Lexical Error: Cannot recognise token: %s", GP->GetCurrentLineNumber(), GP->GetCurrentToken()->GetDataVar().c_str());
				_TextParseTree->SetValue(str);
				Done = true;
				break;

	//--          gpMsgSyntaxError:
	//--             begin  
	//--                txt := '';
	//--                for n := 0 to GP.TokenTable.Count - 1 do
	//--                   txt := txt + ' ' + GP.TokenTable[n].Name;
	//-- 
	//--                AddToReport('Syntax Error', 'Expecting the following tokens', TrimLeft(txt), '', GP.CurrentLineNumber);
	//--                txtParseTree.Text := 'Line ' + IntToStr(GP.CurrentLineNumber) + ': Syntax Error: Expecting the following tokens: ' + Trim(txt);
	//--                Done := True;
	//--             end;

			case gpMsgSyntaxError:
				str.Clear();
				for(n = 0; n < GP->GetTokenTable()->GetCount(); n++)
				{
					str << " ";
					str << GP->GetTokenTable()->GetItem(n)->GetName();
				}

				AddToReport("Syntax Error", "Expecting the following tokens", str.Trim(false), "", 
							GP->GetCurrentLineNumber());
				msg.Printf("Line %i: Syntax Error: Expecting the following tokens: %s", GP->GetCurrentLineNumber(), str.c_str());
				_TextParseTree->SetValue(msg);
				Done = true;
				break;

	//--          gpMsgReduction:
	//--             begin
	//--                Inc(ReductionNumber);
	//--                GP.CurrentReduction.Tag := ReductionNumber;   //Mark the reduction
	//--                AddToReport('Reduce', GP.CurrentReduction.ParentRule.Text, IntToStr(ReductionNumber), IntToStr(GP.CurrentReduction.ParentRule.TableIndex), GP.CurrentLineNumber);
	//--             end;

			case gpMsgReduction:
				ReductionNumber++;
				GP->GetCurrentReduction()->SetTag(ReductionNumber);
				AddToReport("Reduce", GP->GetCurrentReduction()->GetParentRule()->GetText(), wxString::Format("%i", ReductionNumber), 
							wxString::Format("%i", GP->GetCurrentReduction()->GetParentRule()->GetTableIndex()),
							GP->GetCurrentLineNumber());
				break;

	//--          gpMsgAccept:
	//--             begin
	//--                //=== Success!
	//--                AddToReport('Accept', GP.CurrentReduction.ParentRule.Text, '', IntToStr(GP.CurrentReduction.ParentRule.TableIndex), GP.CurrentLineNumber);
	//--                DrawReductionTree(GP.CurrentReduction);
	//--                DrawTTree(GP.CurrentReduction);
	//--                Done := True;
	//--             end;

			case gpMsgAccept:
				// == success!
				AddToReport("Accept", GP->GetCurrentReduction()->GetParentRule()->GetText(), "",
							wxString::Format("%i", GP->GetCurrentReduction()->GetParentRule()->GetTableIndex()),
							GP->GetCurrentLineNumber());
				DrawReductionTree(GP->GetCurrentReduction());
				DrawTTree(GP->GetCurrentReduction());
				Done = true;
				break;

	//--          gpMsgTokenRead:
	//--             begin
	//--                AddToReport('Token Read', GP.CurrentToken.Name, GP.CurrentToken.Text, IntToStr(GP.CurrentToken.TableIndex), GP.CurrentLineNumber);
	//--             end;
			case gpMsgTokenRead:
				AddToReport("Token Read", GP->GetCurrentToken()->GetName(), GP->GetCurrentToken()->GetDataVar(), 
						    GP->GetCurrentToken()->GetText(), GP->GetCurrentLineNumber()); 
				break;

	//--          gpMsgInternalError:
	//--             begin
	//--                AddToReport('Internal Error', 'Something is horribly wrong', '', '', GP.CurrentLineNumber);
	//--                Done := True;
	//--             end;

			case gpMsgInternalError:
				AddToReport("Internal Error", "Something is horribly wrong", "", "", GP->GetCurrentLineNumber());
				Done = true;
				break;

	//--          gpMsgNotLoadedError:
	//--             begin
	//--                //=== Due to the if-statement above, this case statement should never be true
	//--                AddToReport('Not Loaded Error', 'Compiled Gramar Table not loaded', '', '', 0);
	//--                Done := True;
	//--             end;

			case gpMsgNotLoadedError:
				//=== Due to the if-statement above, this case statement should never be true
				AddToReport("Not Loaded Error", "Compiled Grammar Table not loaded", "", "", 0);
				Done = true;
				break;

	//--          gpMsgCommentError:
	//--             begin
	//--                AddToReport('Comment Error', 'Unexpected end of file', '', '', GP.CurrentLineNumber);
	//--                Done := True;
	//--             end;

			case gpMsgCommentError:
				AddToReport("Comment Error", "Unexpected end of file", "", "", GP->GetCurrentLineNumber());
				Done = true;
				break;
	//--          end;
			}
	//--       end;
		}
	//--    end else
	}
	//--       ShowMessage('Input file could not be opened!');
	else
		::wxMessageBox(_T("Input file cannot be opened"), _T("Error ..."),
                                wxOK | wxICON_ERROR | wxCENTRE, this);
	//-- 
	//--
	//--    GP.Free;

	delete GP;

	//-- 
	//--    Memo1.Lines.Assign(SL);
	//-- end;


}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BROWSE_DIR
 */

void GpTestAppFrame::OnBrowseDirClick( wxCommandEvent& event )
{
	wxFileName path(_CgtPath->GetValue());

	wxFileDialog *dlg = new wxFileDialog(this, "Select file to open ...", path.GetPath(),
		                                 "", "",   
                                         wxOPEN | wxHIDE_READONLY | wxCHANGE_DIR | wxFILE_MUST_EXIST);

	if(dlg->ShowModal() == wxID_OK)
        _CgtPath->SetValue(dlg->GetPath());

    dlg->Destroy();
}

void GpTestAppFrame::AddToReport(const wxString &Msg1, const wxString &Msg2, const wxString &Msg3, 
								 const wxString &Msg4, int LN)  
{
	//-- SL.Add(Format('"%s" , "%s" , "%s" , "%s" , "%d"', [Msg1,Msg2,Msg3,Msg4,LN]));
	//wxString str;
	//str.Printf("'%s', '%s', '%s', '%s', '%i'\n", Msg1.c_str(), Msg2.c_str(), Msg3.c_str(), Msg4.c_str(), LN);
	//_SL.Add(str);

	long index = _Messages->InsertItem(_Messages->GetItemCount(), Msg1);
	_Messages->SetItem(index, 1, Msg2);
	_Messages->SetItem(index, 2, Msg3);
	_Messages->SetItem(index, 3, Msg4);
	_Messages->SetItem(index, 4, wxString::Format("%i", LN));
}

//-- procedure DrawTTree_R(R : TReduction; ParentNode : TTreeNode);
void GpTestAppFrame::DrawTTree_R(GpReduction *R, wxTreeItemId ParentNode)
{
//-- var i : integer;
//-- begin

//--   for i := 0 to R.TokenCount - 1 do
	wxTreeItemId node;
	wxString str;
	for(int i = 0; i < R->GetTokenCount(); i++)
	{
//--     case R.Tokens[i].Kind of
		switch(R->GetToken(i)->GetKind())
		{
//--       SymbolTypeNonterminal : DrawTTree_R(R.Tokens[i].Reduction, TreeView1.Items.AddChild(ParentNode, R.Tokens[i].Reduction.ParentRule.Name));
		case GpSymbolTypeNonterminal:
			node = _TTree->AppendItem(ParentNode, R->GetToken(i)->GetReduction()->GetParentRule()->GetName());
			DrawTTree_R(R->GetToken(i)->GetReduction(), node);
			break;
//--       SymbolTypeTerminal    : TreeView1.Items.AddChild(ParentNode, R.Tokens[i].Name + ' : ' + R.Tokens[i].DataVar);
		case GpSymbolTypeTerminal:
			str.Printf("%s : %s", R->GetToken(i)->GetName().c_str(), R->GetToken(i)->GetDataVar().c_str());
			node = _TTree->AppendItem(ParentNode, str);
			break;
		default:
			break;
		}
//--     end;
	}

	_TTree->Expand(ParentNode);
//-- end;
}

//-- procedure TMain.DrawTTree(Reduction: TReduction);
void GpTestAppFrame::DrawTTree(GpReduction *Reduction)
{
//--   TreeView1.Items.BeginUpdate;
//--   try
//--     TreeView1.Items.Clear;

//--     DrawTTree_R(Reduction, TreeView1.Items.AddChild(nil,  Reduction.ParentRule.Name));

	_TTree->DeleteAllItems();

	wxTreeItemId root = _TTree->AddRoot(Reduction->GetParentRule()->GetName());
	DrawTTree_R(Reduction, root);

//--     TreeView1.FullExpand;
//--   finally
//--     TreeView1.Items.EndUpdate;
//--   end;
//-- end;
}

//-- procedure TMain.DrawReductionTree(TheReduction: TReduction);
void GpTestAppFrame::DrawReductionTree(GpReduction *TheReduction)
{
	//--     //This procedure starts the recursion that draws the parse tree.
	//-- 
	//--     txtParseTree.Visible := False;   //Keep the system from updating it until we are done
	//--     txtParseTree.Text := '';

	_TextParseTree->SetValue("");

	//--     DrawReduction(TheReduction, 0);

	DrawReduction(TheReduction, 0);
	//-- 
	//--     txtParseTree.Visible := True;
}

//-- procedure TMain.DrawReduction(TheReduction: TReduction; Indent: Integer);
void GpTestAppFrame::DrawReduction(GpReduction *TheReduction, int Indent)
{
	//-- Const
	//--    kIndentText = '|  ';

	wxString kIndentText("|  "), IndentText, TreeText;

	//-- var
	//--    n: Integer;
	//--    IndentText: string;
	//-- begin
	//--    //This is a simple recursive procedure that draws an ASCII version of the parse
	//--    //tree
	//-- 
	//-- 
	//--    IndentText := '';
	//--    for n := 1 to Indent do
	//--        IndentText := IndentText + kIndentText;
	for(int i = 0; i < Indent; i++)
		IndentText.Append(kIndentText);

	//--    //==== Display Reduction
	//--    PrintParseTree(IndentText + '+--' + TheReduction.ParentRule.Text);

	TreeText.Printf("%s+--%s\n", IndentText.c_str(), TheReduction->GetParentRule()->GetText().c_str());
	(*_TextParseTree) << TreeText;

	//--    //=== Display the children of the reduction
	//--    for n := 0 to TheReduction.TokenCount - 1 do

	for(int n = 0; n < TheReduction->GetTokenCount(); n++)
	{
	//--    begin
	//--        case TheReduction.Tokens[n].Kind of
		switch(TheReduction->GetToken(n)->GetKind())
		{
		case GpSymbolTypeNonterminal:
	//--           DrawReduction(TheReduction.Tokens[n].Reduction, (Indent + 1));
			DrawReduction(TheReduction->GetToken(n)->GetReduction(), Indent + 1);
			break;

	//--        else
		default:
	//--           PrintParseTree(IndentText + kIndentText + '+--' + TheReduction.Tokens[n].DataVar);
			TreeText.Printf("%s%s+--%s\n", IndentText.c_str(), kIndentText.c_str(),TheReduction->GetToken(n)->GetDataVar().c_str());
			(*_TextParseTree) << TreeText;			
			break;
	//--        end;
		}

	//--    end;
	}
	//-- end;
}


/*!
 * Get bitmap resources
 */

wxBitmap GpTestAppFrame::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin GpTestAppFrame bitmap retrieval
    return wxNullBitmap;
////@end GpTestAppFrame bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon GpTestAppFrame::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin GpTestAppFrame icon retrieval
    return wxNullIcon;
////@end GpTestAppFrame icon retrieval
}
