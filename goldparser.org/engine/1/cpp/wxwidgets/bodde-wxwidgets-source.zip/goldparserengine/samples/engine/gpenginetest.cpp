
/////////////////////////////////////////////////////////////////////////////
// Name:        gpenginetest.cpp
// Purpose:     Gpenginetest Test application
// Created:     05/12/04
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "frame.h"

// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------

// the application icon (under Windows and OS/2 it is in resources)
#if defined(__WXGTK__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__) || defined(__WXX11__)
    #include "mondrian.xpm"
#endif

// ----------------------------------------------------------------------------
// GpTestApp Class
// ----------------------------------------------------------------------------

class GpTestApp : public wxApp
{
public:
    virtual bool OnInit();
};

IMPLEMENT_APP(GpTestApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// GpTestApp Implementation
// ----------------------------------------------------------------------------

bool GpTestApp::OnInit()
{
    GpTestFrame *frame = new GpTestFrame(NULL);

    frame->Show(TRUE);
    return TRUE;
}

