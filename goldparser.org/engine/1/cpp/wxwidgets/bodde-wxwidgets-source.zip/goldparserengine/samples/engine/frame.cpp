/////////////////////////////////////////////////////////////////////////////
// Name:        frame.cpp
// Purpose:     
// Author:      Jorgen Bodde
// Modified by: 
// Created:     05/12/04 21:54:33
// RCS-ID:      
// Copyright:   (c) Jorgen Bodde, based on wxWidgets license
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "frame.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "wx/filename.h"

#include "calculator.h"
#include "frame.h"
#include "vardlg.h"

////@begin XPM images
////@end XPM images

/*!
 * GpTestFrame type definition
 */

IMPLEMENT_CLASS( GpTestFrame, wxFrame )

/*!
 * GpTestFrame event table definition
 */

BEGIN_EVENT_TABLE( GpTestFrame, wxFrame )

////@begin GpTestFrame event table entries
    EVT_BUTTON( ID_ADD_VAR, GpTestFrame::OnAddVarClick )

    EVT_BUTTON( ID_CHANGE_VAL, GpTestFrame::OnChangeValClick )

    EVT_BUTTON( ID_TEST_ENG, GpTestFrame::OnTestEngClick )

////@end GpTestFrame event table entries

END_EVENT_TABLE()

/*!
 * GpTestFrame constructors
 */

GpTestFrame::GpTestFrame( )
{
}

GpTestFrame::GpTestFrame( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create( parent, id, caption, pos, size, style );
}

/*!
 * GpTestFrame creator
 */

bool GpTestFrame::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin GpTestFrame member initialisation
    _VarList = NULL;
    _FormulaText = NULL;
    _LogWindow = NULL;
////@end GpTestFrame member initialisation

////@begin GpTestFrame creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end GpTestFrame creation

    // add columns
    _VarList->InsertColumn(0, "Name", wxLIST_FORMAT_LEFT, 150);
    _VarList->InsertColumn(1, "Value", wxLIST_FORMAT_LEFT, 145);

    // add some default vars

    AddVarToList("a", 1);
    AddVarToList("b", 20);
    AddVarToList("c", 10);
    AddVarToList("d", 6);
    AddVarToList("e", 12);

	(*_LogWindow) << "Enter a formula and make sure all variables you used are entered. Then press 'Calculate'"
		             "to start the calculation. Check the source calculator.cpp to see how the parse tree works..\n";

    return TRUE;
}

/*!
 * Control creation for GpTestFrame
 */

void GpTestFrame::CreateControls()
{    
////@begin GpTestFrame content construction

    GpTestFrame* item1 = this;

    wxPanel* item2 = new wxPanel( item1, ID_PANEL, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL );

    wxBoxSizer* item3 = new wxBoxSizer(wxVERTICAL);
    item2->SetSizer(item3);
    item2->SetAutoLayout(TRUE);

    wxStaticText* item4 = new wxStaticText( item2, wxID_STATIC, _("Enter variables"), wxDefaultPosition, wxDefaultSize, 0 );
    item3->Add(item4, 0, wxALIGN_LEFT|wxLEFT|wxRIGHT|wxTOP|wxADJUST_MINSIZE, 5);

    wxBoxSizer* item5 = new wxBoxSizer(wxHORIZONTAL);
    item3->Add(item5, 0, wxGROW, 5);

    wxListCtrl* item6 = new wxListCtrl( item2, ID_LISTCTRL, wxDefaultPosition, wxSize(100, 80), wxLC_REPORT );
    _VarList = item6;
    item5->Add(item6, 1, wxGROW|wxALL, 5);

    wxBoxSizer* item7 = new wxBoxSizer(wxVERTICAL);
    item5->Add(item7, 0, wxALIGN_CENTER_VERTICAL|wxTOP|wxBOTTOM, 5);

    wxButton* item8 = new wxButton( item2, ID_ADD_VAR, _("&Add Var"), wxDefaultPosition, wxDefaultSize, 0 );
    item7->Add(item8, 0, wxALIGN_RIGHT|wxRIGHT|wxTOP|wxBOTTOM, 5);

    wxButton* item9 = new wxButton( item2, ID_CHANGE_VAL, _("&Change Var"), wxDefaultPosition, wxDefaultSize, 0 );
    item7->Add(item9, 0, wxALIGN_RIGHT|wxRIGHT|wxTOP|wxBOTTOM, 5);

    wxBoxSizer* item10 = new wxBoxSizer(wxVERTICAL);
    item3->Add(item10, 1, wxGROW|wxALL, 5);

    wxStaticText* item11 = new wxStaticText( item2, wxID_STATIC, _("Enter formula"), wxDefaultPosition, wxDefaultSize, 0 );
    item10->Add(item11, 0, wxALIGN_LEFT|wxRIGHT|wxTOP|wxADJUST_MINSIZE, 5);

    wxTextCtrl* item12 = new wxTextCtrl( item2, ID_TEXTCTRL1, _("b+c/(d*e)-c"), wxDefaultPosition, wxSize(-1, 80), wxTE_MULTILINE );
    _FormulaText = item12;
    item10->Add(item12, 1, wxGROW|wxTOP|wxBOTTOM, 5);

    wxStaticText* item13 = new wxStaticText( item2, wxID_STATIC, _("Log window"), wxDefaultPosition, wxDefaultSize, 0 );
    item10->Add(item13, 0, wxALIGN_LEFT|wxRIGHT|wxTOP|wxADJUST_MINSIZE, 5);

    wxTextCtrl* item14 = new wxTextCtrl( item2, ID_TEXTCTRL, _T(""), wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );
    _LogWindow = item14;
    item10->Add(item14, 1, wxGROW|wxTOP|wxBOTTOM, 5);

    wxButton* item15 = new wxButton( item2, ID_TEST_ENG, _("&Calculate"), wxDefaultPosition, wxDefaultSize, 0 );
    item10->Add(item15, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

////@end GpTestFrame content construction
}

/*!
 * Should we show tooltips?
 */

bool GpTestFrame::ShowToolTips()
{
    return TRUE;
}

void GpTestFrame::AddVarToList(const wxString &var, int value)
{
	if(!_vars.VarExists(var))
	{
		wxString strval = wxString::Format("%i", value);
		_vars.SetValue(var, strval);

		// show in list

		int pos = _VarList->InsertItem(_VarList->GetItemCount(), var);
		_VarList->SetItem(pos, 1, strval);
	}
}
/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_TEST_ENG
 */

void GpTestFrame::OnTestEngClick( wxCommandEvent& event )
{
	wxArrayString errors, messages;
	GoldParserCtrl *p = new GoldParserCtrl();

	_LogWindow->SetValue("Calculating formula...\n");

	wxFileName grm;
	grm.AssignCwd();
	grm.SetFullName("simple.cgt");

	p->SetGrammarFile(grm.GetFullPath());
	p->SetVariableList(&_vars);
	int result = p->Parse(_FormulaText->GetValue(), false, &messages, &errors);

	if(result != 0)
	{
		if(result < 0)
			(*_LogWindow) << "A serious error occured during parsing!\n";
		else
			(*_LogWindow) << "There were errors!\n";

		for(size_t i = 0; i < errors.GetCount(); i++)
			(*_LogWindow) << "ERROR: " << errors[i] << "\n";
	}
	else
		(*_LogWindow) << "\nResult is :" << p->GetResult();

	delete p;
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_ADD_VAR
 */

void GpTestFrame::OnAddVarClick( wxCommandEvent& event )
{
    // Insert custom code here
    VarDialog *dlg = new VarDialog(this);
	if(dlg->ShowModal() == wxID_OK)
	{
		if(!_vars.VarExists(dlg->GetVarName()) && !dlg->GetVarName().IsEmpty())
		{
			long val = 0;
			if(dlg->GetIntValue().ToLong(&val))
				AddVarToList(dlg->GetVarName(), val);
		}
	}
	dlg->Destroy();
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_CHANGE_VAL
 */

void GpTestFrame::OnChangeValClick( wxCommandEvent& event )
{
    // Insert custom code here

	long item = _VarList->GetNextItem(-1,wxLIST_NEXT_ALL, wxLIST_STATE_SELECTED);    
    if (item != -1)
	{
		VarDialog *dlg = new VarDialog(this);

		dlg->SetVarName(_VarList->GetItemText(item));
		
		wxListItem col;
		col.SetId(item);
		col.SetColumn(1);
		col.SetMask(wxLIST_MASK_TEXT);
		_VarList->GetItem(col);

		dlg->SetIntValue(col.GetText());

		dlg->SetReadOnly();
		if(dlg->ShowModal() == wxID_OK)
		{
			_vars.SetValue(dlg->GetVarName(), dlg->GetIntValue());
			_VarList->SetItem(item, 1, dlg->GetIntValue());
		}

		dlg->Destroy();		
	}        

}



/*!
 * Get bitmap resources
 */

wxBitmap GpTestFrame::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin GpTestFrame bitmap retrieval
    return wxNullBitmap;
////@end GpTestFrame bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon GpTestFrame::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin GpTestFrame icon retrieval
    return wxNullIcon;
////@end GpTestFrame icon retrieval
}
