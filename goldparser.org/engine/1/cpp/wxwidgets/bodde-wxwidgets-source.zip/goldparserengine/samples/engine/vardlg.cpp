/////////////////////////////////////////////////////////////////////////////
// Name:        vardlg.cpp
// Purpose:     
// Author:      Jorgen Bodde
// Modified by: 
// Created:     05/16/04 12:53:01
// RCS-ID:      
// Copyright:   (c) Jorgen Bodde, based on wxWidgets license
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "vardlg.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "vardlg.h"

////@begin XPM images
////@end XPM images

/*!
 * VarDialog type definition
 */

IMPLEMENT_CLASS( VarDialog, wxDialog )

/*!
 * VarDialog event table definition
 */

BEGIN_EVENT_TABLE( VarDialog, wxDialog )

////@begin VarDialog event table entries
////@end VarDialog event table entries

END_EVENT_TABLE()

/*!
 * VarDialog constructors
 */

VarDialog::VarDialog( )
{
}

VarDialog::VarDialog( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create(parent, id, caption, pos, size, style);
}

/*!
 * VarDialog creator
 */

bool VarDialog::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin VarDialog member initialisation
    _IntValue = "";
    _VarNameText = NULL;
////@end VarDialog member initialisation

////@begin VarDialog creation
    SetExtraStyle(wxWS_EX_BLOCK_EVENTS);
    wxDialog::Create( parent, id, caption, pos, size, style );

    CreateControls();
    GetSizer()->Fit(this);
    GetSizer()->SetSizeHints(this);
    Centre();
////@end VarDialog creation
    return TRUE;
}

/*!
 * Control creation for VarDialog
 */

void VarDialog::CreateControls()
{    
////@begin VarDialog content construction

    VarDialog* item1 = this;

    wxBoxSizer* item2 = new wxBoxSizer(wxVERTICAL);
    item1->SetSizer(item2);
    item1->SetAutoLayout(TRUE);

    wxStaticText* item3 = new wxStaticText( item1, wxID_STATIC, _("Enter variable name"), wxDefaultPosition, wxDefaultSize, 0 );
    item2->Add(item3, 0, wxALIGN_LEFT|wxLEFT|wxRIGHT|wxTOP|wxADJUST_MINSIZE, 5);

    wxTextCtrl* item4 = new wxTextCtrl( item1, ID_TEXTCTRL2, _T(""), wxDefaultPosition, wxSize(200, -1), 0 );
    _VarNameText = item4;
    item2->Add(item4, 0, wxGROW|wxALL, 5);

    wxStaticText* item5 = new wxStaticText( item1, wxID_STATIC, _("Enter variable value"), wxDefaultPosition, wxDefaultSize, 0 );
    item2->Add(item5, 0, wxALIGN_LEFT|wxLEFT|wxRIGHT|wxTOP|wxADJUST_MINSIZE, 5);

    wxTextCtrl* item6 = new wxTextCtrl( item1, ID_TEXTCTRL3, _("0"), wxDefaultPosition, wxSize(200, -1), 0 );
    item2->Add(item6, 0, wxGROW|wxALL, 5);

    wxBoxSizer* item7 = new wxBoxSizer(wxHORIZONTAL);
    item2->Add(item7, 0, wxALIGN_CENTER_HORIZONTAL|wxTOP, 5);

    wxButton* item8 = new wxButton( item1, wxID_OK, _("&Ok"), wxDefaultPosition, wxDefaultSize, 0 );
    item8->SetDefault();
    item7->Add(item8, 1, wxALIGN_BOTTOM|wxALL, 5);

    wxButton* item9 = new wxButton( item1, wxID_CANCEL, _("&Cancel"), wxDefaultPosition, wxDefaultSize, 0 );
    item7->Add(item9, 0, wxALIGN_BOTTOM|wxALL, 5);


    // Set validators
    item4->SetValidator( wxTextValidator(wxFILTER_ALPHA, & _VarName) );
    item6->SetValidator( wxTextValidator(wxFILTER_NUMERIC, & _IntValue) );
////@end VarDialog content construction
}

/*!
 * Should we show tooltips?
 */

bool VarDialog::ShowToolTips()
{
    return TRUE;
}
