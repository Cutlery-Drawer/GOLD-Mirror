#ifndef __FASTATE_HPP_
#define __FASTATE_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/dynarray.h>

/*
'================================================================================
' Class Name:
'      FAState
'
' Instancing:
'      Private; Internal  (VB Setting: 1 - Private)
'
' Purpose:
'      Represents a state in the Deterministic Finite Automata which is used by
'      the tokenizer.
'
' Author(s):
'      Devin Cook
'      GOLDParser@DevinCook.com
'
' Dependacies:
'      FAEdge
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
*/

//-- TFAEdge = class
class GpFaEdge 
{
private:
	//-- FCharacters: Integer;
	int FCharacters;
	//-- FTargetIndex: Integer;
	int FTargetIndex;
	//-- procedure SetCharacters(const Value: integer);
	//-- procedure SetTargetIndex(const Value: integer);
public:
    GpFaEdge(int Characters, int TargetIndex);
    ~GpFaEdge();
    
    //-- property Characters : integer read FCharacters write SetCharacters;
	int GetCharacters() const {
		return FCharacters;
	};
	void SetCharacters(int Characters) {
		//-- FCharacters := Value;
		FCharacters = Characters;
	};

    //-- property TargetIndex : integer read FTargetIndex write SetTargetIndex;
	int GetTargetIndex() const {
		return FTargetIndex;
	};
	void SetTargetIndex(int TargetIndex) {
		//-- FTargetIndex := Value;
		FTargetIndex = TargetIndex;
	};
};

WX_DEFINE_ARRAY(GpFaEdge *, GpFaEdgeArray);

//-- TFAState = class
class GpFaState 
{
private:
	//-- FEdges: TObjectList;
	GpFaEdgeArray FEdges;

	//-- FAcceptSymbol: Integer;
	int FAcceptSymbol;

	//-- function GetEdgeCount: Integer;
	//-- function GetEdge(Index: Integer): TFAEdge;
	//-- procedure SetAcceptSymbol(const Value: Integer);
	//-- procedure Add(Characters, Target : integer);
	void Add(int Characters, int Target);
public:
	//-- constructor Create;
	GpFaState();

	//-- destructor Destroy; override;
	~GpFaState();

	//-- procedure AddEdge(Characters: string; Target: Integer);
	void AddEdge(const wxString &Characters, int Target);

	//-- property AcceptSymbol: Integer read FAcceptSymbol write SetAcceptSymbol;
	int GetAcceptSymbol() const {
		return FAcceptSymbol;
	};
	void SetAcceptSymbol(int AcceptSymbol) {
		//-- FAcceptSymbol := Value;
		FAcceptSymbol = AcceptSymbol;
	};

	//-- property EdgeCount: Integer read GetEdgeCount;
	size_t GetEdgeCount() const {
		//-- Result := FEdges.Count;
		return FEdges.GetCount();
	};

	//-- property Edges[Index : integer] : TFAEdge read GetEdge; default;
	GpFaEdge *GetEdge(int Index) {
		//-- Result := FEdges[Index] as TFAEdge;
		return FEdges[Index];
	};
};

WX_DEFINE_ARRAY(GpFaState *, GpFaStateArray);

//-- TFStateTable = class
class GpFStateTable 
{
private:
	//-- FList : TObjectList;
	GpFaStateArray FList;

	//-- function GetCount: integer;
	//-- function GetItem(Index: integer): TFAState;
	//-- procedure SetItem(Index: integer; const Value: TFAState);
public:
	//-- constructor Create;
	GpFStateTable();

	//-- destructor Destroy; override;
	~GpFStateTable();

	//-- procedure Add(Value : TObject);
	void Add(GpFaState *Value);

	//-- property Count : integer read GetCount;
	size_t GetCount() const {
		//-- Result := FList.Count;
		return FList.GetCount();
	};

	//-- property Items[Index : integer] : TFAState read GetItem write SetItem; default;
	GpFaState *GetItem(int Index) const {
		//-- Result := FList[Index] as TFAState;
		return FList[Index];
	};
	void SetItem(GpFaState *Value, int Index);
};

#endif
