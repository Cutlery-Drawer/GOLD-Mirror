#ifndef __VARIABLES_HPP_
#define __VARIABLES_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

// declare the array class here
#include <wx/dynarray.h>

/*
'================================================================================
' Class Name:
'      VariableList
'
' Instancing:
'      Private; Internal  (VB Setting: 1 - Private)
'
' Purpose:
'      This is a very simple class that stores a list of "variables". The GOLDParser
'      class uses a this class to store the parameter fields.
'
' Author(s):
'      Devin Cook
'      GOLDParser@DevinCook.com
'
' Dependacies:
'      (None)
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
================================================================================
*/

//-- TVariableList = class
class GpVariableList
{
private:
	//-- MemberList: TStringList;
	wxArrayString MemberListName;
	wxArrayString MemberListValue;

	//-- function GetCount: Integer;
	//-- function GetValue(Name: string): string;
	//-- procedure SetValue(Name: string; Value: string);
	//-- function GetName(Index: Integer): string;
public:
    //-- constructor Create;
	GpVariableList();

	//-- destructor Destroy; override;
	~GpVariableList();

	//-- procedure Add(Name: string; Value: string);
	void Add(const wxString &Name, const wxString &Value = wxEmptyString);

    //-- procedure Clear;
	void Clear();

    //-- property Count: Integer read GetCount;
	size_t GetCount() const {
		//-- Result := MemberList.Count;
		return MemberListName.GetCount();
	};

    //-- property Value[Name: string]: string read GetValue write SetValue;
	wxString GetValue(const wxString &Name) const;
	void SetValue(const wxString &Name, const wxString &Value);

    //-- property Names[Index : integer] : string read GetName;
	wxString GetNames(size_t Index) const;

	bool VarExists(const wxString &Name);
};

#endif
