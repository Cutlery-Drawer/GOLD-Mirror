#ifndef __TOKEN_HPP_
#define __TOKEN_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

// declare the array class here
#include <wx/dynarray.h>

//-- unit Token;

/*
'================================================================================
' Class Name:
'      Token
'
' Instancing:
'      Public; Creatable  (VB Setting: 5 - MultiUse)
'
' Purpose:
'       While the Symbol represents a class of terminals and nonterminals, the
'       Token represents an individual piece of information.
'       Ideally, the token would inherit directly from the Symbol Class, but do to
'       the fact that Visual Basic 5/6 does not support this aspect of Object Oriented
'       Programming, a Symbol is created as a member and its methods are mimicked.
'
' Author(s):
'      Devin Cook
'      GOLDParser@DevinCook.com
'
' Dependacies:
'      Symbol class
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
*/

#include <wx/variant.h>

#include "symbol.h"
#include "rule.h"

class GpToken;
WX_DEFINE_ARRAY(GpToken *, GpTokenArray);

//-- TToken = class;
//-- TReduction = class
class GpReduction
{
private:
	//-- FTokens: TObjectList;
	GpTokenArray FTokens;
	//-- FParentRule: TRule;
	GpRule *FParentRule;
	//-- FTag: Integer;
	int FTag;
	//-- function GetToken(Index: Integer): TToken;
	//-- function GetTokenCount: Integer;
	//-- procedure SetTag(const Value: Integer);
public:
	//-- constructor Create(const aParentRule : TRule);
	GpReduction(GpRule *aParentRule);

	//-- destructor Destroy; override;
	~GpReduction();

	//-- procedure InsertToken(Index : integer; Token : TToken);
	void InsertToken(int Index, GpToken *Token) {
		//-- FTokens.Insert(Index, Token);

		// TODO: Check if the insert wxArray action is the same as VCL insert
		FTokens.Insert(Token, Index);
	};

	//-- property ParentRule: TRule read FParentRule;
	GpRule *GetParentRule() const {
		return FParentRule;
	};

	//-- property TokenCount: Integer read GetTokenCount;
	int GetTokenCount() const {
		//-- Result := FTokens.Count;
		return FTokens.GetCount();
	};

	//-- property Tag: Integer read FTag write SetTag;
	int GetTag() const {
		return FTag;
	};
	void SetTag(int Tag) {
		//-- FTag := Value;
		FTag = Tag;
	};

	//-- property Tokens[Index: Integer]: TToken read GetToken;
	GpToken *GetToken(size_t Index) const {
		//-- Result := FTokens.items[Index] as TToken;
		return FTokens[Index];
	};

	/** This field is used to pass values back from the current reduction to a 
	    higher hierarchy. It works just like the lexx / yacc method of passing values 
		on the parse stack */
	wxVariant RetVal;
};

//TTokenStack = class;
class GpTokenStack;

//-- TToken = class;
class GpToken
{
private:
	//-- FState: Integer;
	int FState;
	//-- FDataVar: string;
	wxString FDataVar;
	//-- FReduction: TReduction;
	GpReduction *FReduction;
	//-- FParentSymbol: TSymbol;
	GpSymbol *FParentSymbol;
	//-- FOwnerStack : TTokenStack;
	GpTokenStack *FOwnerStack;
	//-- function GetKind: Integer;
	//-- function GetName: string;
	//-- procedure SetParentSymbol(Value: TSymbol);
	//-- procedure SetdataVar(Value: string);
	//-- procedure SetReduction(Value: TReduction);
	//-- function GetTableIndex: Integer;
	//-- function GetText: string;
	//-- procedure SetState(Value: Integer);
public:
	//-- constructor Create;
	GpToken();

	//-- destructor Destroy; override;
	~GpToken();

	// Returns an enumerated data type that denotes the symbol class of the token.

	//-- property Kind : Integer read GetKind;
	int GetKind() const {
		//--Result := ParentSymbol.Kind;
		wxCHECK(FParentSymbol, -1);
		return FParentSymbol->GetKind();
	};

	// Returns the name of the token. This is equivalent to the parent symbol's name.

	//-- property Name : string read GetName;
	wxString GetName() const {
		//-- Result := ParentSymbol.Name;
		wxCHECK(FParentSymbol, wxEmptyString);
		return FParentSymbol->GetName();
	};

	// Returns a reference the token's parent symbol.

	//-- property ParentSymbol : TSymbol read FParentSymbol write SetParentSymbol;
	GpSymbol *GetParentSymbol() const {
		return FParentSymbol;
	};
	void SetParentSymbol(GpSymbol *Symbol) {
		//-- FParentSymbol := Value;
		FParentSymbol = Symbol;
	};

	// Returns/sets the information stored in the token.
	// This can be either an standard data type or an object reference.

	//-- property DataVar : string read FDataVar write SetDataVar;
	wxString GetDataVar() const {
		return FDataVar;
	};
	void SetDataVar(const wxString &Value) {
		//-- FDataVar := Value;
		FDataVar = Value;
	};

	//-- property Reduction : TReduction read FReduction write SetReduction;
	GpReduction *GetReduction() const {
		return FReduction;
	};
	void SetReduction(GpReduction *Value) {
		//-- Assert(not Assigned(Reduction));
		//-- FReduction := Value;

		wxCHECK2(!FReduction, return);
		FReduction = Value;
	};

	// Returns the index of the token's parent symbol in the GOLDParser object's symbol table.
	//-- property TableIndex : Integer read GetTableIndex;
	int GetTableIndex() const {
		//-- Result := ParentSymbol.TableIndex;
		wxCHECK(FParentSymbol, -1);
		return FParentSymbol->GetTableIndex();
	};

	// Returns the text representation of the token's parent symbol.
	// In the case of nonterminals, the name is delimited by angle brackets,
	// special terminals are delimited by parenthesis and terminals
	// are delimited by single quotes (if special characters are present).

	//-- property Text : string read GetText;
	wxString GetText() const {
	   //-- Result := ParentSymbol.Text;
		wxCHECK(FParentSymbol, wxEmptyString);
		return FParentSymbol->GetText();
	};;

	//-- property State : Integer read FState write SetState;
	int GetState() const {
		return FState;
	};
	void SetState(int State) {
		//-- FState := Value;
		FState = State;
	};

	void SetOwnerStack(GpTokenStack *OwnerStack) {
		FOwnerStack = OwnerStack;
	};
	GpTokenStack *GetOwnerStack() const {
		return FOwnerStack;
	};
};

//-- TTokenStack = class
class GpTokenStack
{
private:
    //-- MemberList: TObjectList;
	GpTokenArray MemberList;
    //-- OwnedTokens : TObjectList;
	GpTokenArray OwnedTokens;
    //-- function GetCount: Integer;
    //-- function GetItem(Index: Integer): TToken;
    //-- procedure FreeOwnedTokens;
	void FreeOwnedTokens();
public:
    //-- constructor Create;
	GpTokenStack();

    //-- destructor Destroy; override;
	~GpTokenStack();

    //-- procedure Clear;
	void Clear();

    //-- procedure Push(TheToken: TToken);
	void Push(GpToken *TheToken);

    //-- function Pop: TToken;
	GpToken *Pop();

    //-- function Top: TToken;
	GpToken *Top();

    //-- property Count: Integer read GetCount;
	int GetCount() const {
		//-- Result := MemberList.Count;
		return MemberList.GetCount();
	};

    //-- property Items[Index: Integer]: TToken read GetItem; default;
	GpToken *GetItem(size_t Index) const;

	// due to allowing 'private' members to peek inside all classes
	// declared in the same unit, I need to rectify this in C++

	GpTokenArray &GetOwnedTokens() {
		return OwnedTokens;
	};

	GpTokenArray &GetMemberList() {
		return MemberList;
	};
};

#endif
