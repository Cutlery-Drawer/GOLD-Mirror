#ifndef __SYMBOL_HPP_
#define __SYMBOL_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

// declare the array class here
#include <wx/dynarray.h>

#define GpSymbolTypeNonterminal  0		// Normal nonterminal
#define GpSymbolTypeTerminal     1 		// Normal terminal
#define GpSymbolTypeWhitespace   2		// This Whitespace symbols is a special terminal
                                		// that is automatically ignored the the parsing engine.
                                  		// Any text accepted as whitespace is considered
                                  		// to be inconsequential and "meaningless".
#define GpSymbolTypeEnd          3      // The End symbol is generated when the tokenizer
                                  		// reaches the end of the source text.
#define GpSymbolTypeCommentStart 4		// This type of symbol designates the start of a block quote.
#define GpSymbolTypeCommentEnd   5		// This type of symbol designates the end of a block quote.
#define GpSymbolTypeCommentLine  6	    // When the engine reads a token that is recognized as
                                  		// a line comment, the remaining characters on the line
                                  		// are automatically ignored by the parser.
#define GpSymbolTypeError        7		// The Error symbol is a general-purpose means
                                  		// of representing characters that were not recognized
                                  		// by the tokenizer. In other words, when the tokenizer
                                  		// reads a series of characters that is not accepted
                                  		// by the DFA engine, a token of this type is created

/*
'================================================================================
' Class Name:
'      Symbol
'
' Instancing:
'      Public; Non-creatable  (VB Setting: 2- PublicNotCreatable)
'
' Purpose:
'       This class is used to store of the nonterminals used by the Deterministic
'       Finite Automata (DFA) and LALR Parser. Symbols can be either
'       terminals (which represent a class of tokens - such as identifiers) or
'       nonterminals (which represent the rules and structures of the grammar).
'       Terminal symbols fall into several catagories for use by the GOLD Parser
'       Engine which are enumerated below.
'
' Author(s):
'      Devin Cook
'      GOLDParser@DevinCook.com
'
' Dependacies:
'      (None)
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
*/

class GpSymbol
{
private:
	//-- FName: String;
	wxString FName;
	//-- FKind: Integer;
	int FKind;
	//-- FTableIndex: Integer;
	int FTableIndex;
	//-- function PatternFormat(Source: string): string;
    wxString PatternFormat(const wxString &Source) const;

public:
	//-- constructor Create(aTableIndex : integer; aName : string; aKind : integer);
    GpSymbol(int aTableIndex, const wxString &aName, int aKind); 

	virtual ~GpSymbol();

    // Returns an enumerated data type that denotes
    // the class of symbols that the object belongs to.

	//-- property Kind: Integer read FKind;
    int GetKind() const {
    	return FKind;
    };

	// Returns the index of the symbol in the GOLDParser object's Symbol Table.

	//-- property TableIndex: Integer read FTableIndex;
	int GetTableIndex() const {
    	return FTableIndex;
    };

    // Returns the text representation of the symbol.
    // In the case of nonterminals, the name is delimited by angle brackets,
    // special terminals are delimited by parenthesis
    // and terminals are delimited by single quotes (if special characters are present).

	// -- property Text: string read GetText;
	wxString GetText() const {

		//-- case Kind of
		//-- SymbolTypeNonterminal: Result := '<' + Name + '>';
		//-- SymbolTypeTerminal: Result := PatternFormat(Name);
		//-- else Result := '(' + Name + ')';
		//-- end;

		wxString Result;
  		switch(FKind)
  		{
  		case GpSymbolTypeNonterminal:
  			Result.Printf("<%s>", FName.c_str());
  			break;
  		case GpSymbolTypeTerminal:
  			Result = PatternFormat(FName);
  			break;
  		default:
  			Result.Printf("(%s)", FName.c_str());
  			break;
  		}

  		return Result;
    };

	// Returns the name of the symbol.

	//-- property Name: string read FName;
    wxString GetName() const {
    	return FName;
    };
};

WX_DEFINE_ARRAY(GpSymbol *, GpSymbolArray);

class GpSymbolTable
{
private:
	//-- FList : TObjectList;
    GpSymbolArray FList;

	//-- function GetCount: integer;
	//-- function GetItem(Index: integer): TSymbol;
	//-- procedure SetItem(Index: integer; const Value: TSymbol);
public:
	//-- constructor Create;
	GpSymbolTable();

	//-- destructor Destroy; override;
    virtual ~GpSymbolTable();

	//-- procedure Add(Value : TObject);
	void Add(GpSymbol *Value);

	//-- procedure Clear;
    void Clear();

	//-- property Count : integer read GetCount;
    size_t GetCount() {
		//-- Result := Flist.Count;
		return FList.GetCount();
    };

	//-- property Items[Index : integer] : TSymbol read GetItem write SetItem; default;
    GpSymbol *GetItem(size_t Index);
    void SetItem(size_t Index, GpSymbol *Item);
};

#endif
