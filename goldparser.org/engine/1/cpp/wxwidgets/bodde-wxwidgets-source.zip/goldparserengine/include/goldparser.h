
#ifndef __GOLDPARSER_HPP_
#define __GOLDPARSER_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

/*
'===================================================================
' Class Name:
'    GOLDParser (basic version)
'
' Instancing:
'      Public; Creatable  (VB Setting: 5 - MultiUse)
'
' Purpose:
'    This is the main class in the GOLD Parser Engine and is used to perform
'    all duties required to the parsing of a source text string. This class
'    contains the LALR(1) State Machine code, the DFA State Machine code,
'    character table (used by the DFA algorithm) and all other structures and
'    methods needed to interact with the developer.
'
'Author(s):
'   Devin Cook
'
'Public Dependencies:
'   Token, Rule, Symbol, Reduction
'
'Private Dependencies:
'   ObjectList, SimpleDatabase, SymbolList, StringList, VariableList, TokenStack
'
'Revision History:
'   June 9, 2001:
'      Added the ReductionMode property and modified the Reduction object (which was
'      used only for internal use). In addition the Reduction property was renamed to
'      CurrentReduction to avoid possible name conflicts in different programming languages
'      (which this VB source will be converted to eventually)
'   Sept 5, 2001:
'      I was alerted to an error in the engine logic by Szczepan Holyszewski [rulatir@poczta.arena.pl].
'      When reading tokens inside a block quote, the line-comment token would still eliminate the rest
'      of a line - possibly eliminating the block quote end.
'   Nov 28, 2001:
'      Fixed several errors.
'   December 2001:
'      Added the TrimReductions property and required logic
'===================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
 	  
 Delphi Version: 6.0

 Delphi GOLDParser version: 0.1 (very alpha!)


 Conversion Readme:

 This is a pretty straightforward conversion of the GOLDParser VB version.
 The most important difference is the GrammarReader and the SourceFeeder classes.
 These classes take care of reading the grammar and feeding the parser with code
 wich must be parsed. The reading of the grammar looks the same as in the VB
 version, but the LookaheadStream is not being used. The feeding of the source
 is also being done without the LookaheadStream.

 TODO's(in no particulair order):

 1. DONE 22 April 2002: Get rid of the Variant type's. It can be done without.
    The code will run faster without Variants. They can also produce weird errors.
 2. Optimize the code. Its currently a pretty straightforward conversion. It
    can be done better, wich will result in cleaner and faster code.
 3. Intensive testing. I did some tests, wich succeeded, but I want to test it
    more to be sure it does what it is supposed to do. Any input on this
    would be helpfull! ;)
 4. DONE 24 April 2002(well, I hope so!): Check if there are no memory leaks. I have the feeling there are some, but
    I have to get in to it.
 5. Write some documentation
 6. ALTHOUGH IT LOOKS LIKE ITS DONE: ALMOST DONE, JUST SOME MINOR THINGS: Make
    a nice component of this all so it can be easily used with a Delphi
    application
 7. DONE 23 April 2002: Make sure the interface has the same functionality compared to the VB
    ActiveX version.

 Warranty: None ofcourse :) If it works for you, GOOD! If it doesnt, don't demand
 that I will fix it. You can ask me, but I can't guarantee anything!


'================================================================================
'
'                 The GOLD Parser Freeware License Agreement
'                 ==========================================
'
'this software Is provided 'as-is', without any expressed or implied warranty.
'In no event will the authors be held liable for any damages arising from the
'use of this software.
'
'Permission is granted to anyone to use this software for any purpose. If you
'use this software in a product, an acknowledgment in the product documentation
'would be deeply appreciated but is not required.
'
'In the case of the GOLD Parser Engine source code, permission is granted to
'anyone to alter it and redistribute it freely, subject to the following
'restrictions:
'
'   1. The origin of this software must not be misrepresented; you must not
'      claim that you wrote the original software.
'
'   2. Altered source versions must be plainly marked as such, and must not
'      be misrepresented as being the original software.
'
'   3. This notice may not be removed or altered from any source distribution
'
'================================================================================
*/

#include <wx/stream.h>

#include "variables.h"
#include "lraction.h"
#include "fastate.h"
#include "rule.h"
#include "symbol.h"
#include "token.h"
#include "sourcefeeder.h"
#include "grammarreader.h"

#define gpMsgEmpty                  0        // Nothing
#define gpMsgTokenRead              1        // Each time a token is read, this message is generated.
#define gpMsgReduction              2        // When the engine is able to reduce a rule,
                                             // this message is returned. The rule that was
                                     	     // reduced is set in the GOLDParser's ReduceRule property.
                                     		 // The tokens that are reduced and correspond the
                                     		 // rule's definition are stored in the Tokens() property.
#define gpMsgAccept                 3        // The engine will returns this message when the source
                                     		 // text has been accepted as both complete and correct.
                                     		 // In other words, the source text was successfully analyzed.
#define gpMsgNotLoadedError         4        // Before any parsing can take place,
                                     		 // a Compiled Grammar Table file must be loaded.
#define gpMsgLexicalError           5        // The tokenizer will generate this message when
                                     		 // it is unable to recognize a series of characters
                                     		 // as a valid token. To recover, pop the invalid
                                     		 // token from the input queue.
#define gpMsgSyntaxError            6        // Often the parser will read a token that is not expected
                                     		 // in the grammar. When this happens, the Tokens() property
                                     		 // is filled with tokens the parsing engine expected to read.
                                     		 // To recover: push one of the expected tokens on the input queue.
#define gpMsgCommentError           7        // The parser reached the end of the file while reading a comment.
                                     		 // This is caused when the source text contains a "run-away"
                                     		 // comment, or in other words, a block comment that lacks the
                                     		 // delimiter.
#define gpMsgInternalError          8        // Something is wrong, very wrong

#define ParseResultEmpty            0
#define ParseResultAccept           1
#define ParseResultShift            2
#define ParseResultReduceNormal     3
#define ParseResultReduceEliminated 4
#define ParseResultSyntaxError      5
#define ParseResultInternalError    6

// flags to be used by the engine skeleton code

//#define wxGP_SHOW_ERRLOG 1	// shows the log window with messages when errors occur

//-- TCompareMode = (vbBinaryCompare, vbTextCompare);
enum GpCompareMode
{
	vbBinaryCompare = 0,
	vbTextCompare
};

//-- TGOLDParser = class
class GpGrammarReader;

class wxGoldParser
{
private:
    //-- FGrammarReader: TObject;
	GpGrammarReader *FGrammarReader;
	
    //-- FVariableList: TVariableList;
	GpVariableList *FVariableList;

    //-- FSymbolTable: TSymbolTable;
	GpSymbolTable *FSymbolTable;

    //-- FInitialDFAState: Integer;
	int FInitialDFAState;

    //-- FInitialLALRState: Integer;
	int FInitialLALRState;

    //-- FCharacterSetTable: TStringList;
	wxArrayString FCharacterSetTable;

    //-- FRuleTable: TRuleTable;
	GpRuleTable *FRuleTable;

    //-- FDFA: TFStateTable;
	GpFStateTable *FDFA;

    //-- FActionTables: TLRActionTables;
	GpLRActionTables *FActionTables;

    //-- FTablesLoaded: Boolean;
	bool FTablesLoaded;

    //-- FTrimReductions: Boolean;
	bool FTrimReductions;

    //-- FErrorSymbol: TSymbol;
	GpSymbol *FErrorSymbol;

    //-- FEndSymbol: TSymbol;
	GpSymbol *FEndSymbol;

    //-- FCompareMode: TCompareMode;
	int FCompareMode;

    //-- FCurrentLALR: Integer;
	int FCurrentLALR;

    //-- FLineNumber: Integer;
	int FLineNumber;

    //-- FCommentLevel: Integer;
	int FCommentLevel;

    //-- FHaveReduction: Boolean;
	bool FHaveReduction;

    //-- FStack: TTokenStack;
	GpTokenStack *FStack;

    //-- FTokens: TTokenStack;
	GpTokenStack *FTokens;

    //-- FInputTokens: TTokenStack;
	GpTokenStack *FInputTokens;

    //-- FSource: TSourceFeeder;
	GpSourceFeeder *FSource;

    //-- procedure PrepareToParse;
	void PrepareToParse();

    //-- function RetrieveToken(Source: TSourceFeeder): TToken;
	GpToken *RetrieveToken(GpSourceFeeder &Source);

    //-- procedure DiscardRestOfLine;
	void DiscardRestOfLine();

    //-- function ParseToken(NextToken: TToken): Integer;
	int ParseToken(GpToken *NextToken);

    //-- function GetCurrentReduction: TReduction;
    //-- procedure SetCurrentReduction(NewReduction: TReduction);
    //-- function GetCurrentToken: TToken;
public:
    //-- constructor Create;
    wxGoldParser();

	//-- destructor Destroy; override;
    ~wxGoldParser();

	// Resets the GOLDParser. The parser's internal tables are not affected.
	//-- procedure Reset;
	void Reset();
    
    // The GOLDParser is reset and the internal tables are cleared.
	//-- procedure Clear;
	void Clear();

    // Pushes the token onto the front of the GOLDParser's internal input queue.
    // It will be the next token analyzed by the parsing engine.
	//-- procedure PushInputToken(TheToken: TToken);
	void PushInputToken(GpToken *TheToken) {
		//-- FInputTokens.Push(TheToken);
		FInputTokens->Push(TheToken);
	};

    // If the Compiled Grammar Table file is successfully loaded
    // the method returns True; otherwise False. This method must
    // be called before any Parse calls are made.

	//-- function LoadCompiledGrammar(const FileName : string) : boolean; overload;
    //-- function LoadCompiledGrammar(const Stream : TStream) : boolean; overload;
	bool LoadCompiledGrammar(const wxString &FileName);
	bool LoadCompiledGrammar(wxInputStream &Stream);
    
    // Opens the SourceString for parsing. If successful the method returns True; otherwise False.
	//-- function OpenTextString(Text: String): Boolean;
    //-- function ReadTextString: string;
	bool OpenTextString(const wxString &Text);
	wxString ReadTextString() const {
		return FSource->GetText();
	};

    // Executes a parse.  When this method is called, the parsing engine
    // reads information from the source text (either a string or a file)
    // and then reports what action was taken. This ranges from a token
    // being read and recognized from the source, a parse reduction, or a type of error.

	//-- function Parse: Integer;
	int Parse();

    // Returns a string containing the value of the specified parameter.
    // The ParameterName is the same as the parameters entered in the
    // grammar's description. These include: Name, Version, Author, About,
    // Case Sensitive and Start Symbol. If the name specified is invalid,
    // this method will return an empty string.
	//-- function Parameter(ParamName: string): string;
	wxString Parameter(const wxString &ParamName) {
		//--  Result := FVariableList.Value[ParamName];
		return FVariableList->GetValue(ParamName);
	};


    // Removes the next token from the front of the parser's internal input queue.
	//-- function PopInputToken: TToken;
	GpToken *PopInputToken() {
	   //-- Result := FInputTokens.Pop;
		return FInputTokens->Pop();
	};

    // Returns/sets the TrimReductions flag. When this property is set to True,
    // the parser engine will automatically trim (i.e. remove) unneeded reductions
    // from the parse tree. For more information please click here.
	//-- property TrimReductions: Boolean read FTrimReductions write FTrimReductions;
	bool GetTrimReductions() const {
		return FTrimReductions;
	};
	void SetTrimReductions(bool Value) {
		FTrimReductions = Value;
	};

    // Returns/sets the reduction made by the parsing engine.
    // When a reduction takes place, this property will be set to
    // a Reduction object which will store the reduced rule and its related tokens.
    // This property may be reassigned a customized object if the developer so desire.
    // The value of this property is only valid when the Parse() method returns
    // the gpMsgReduction message.

	//-- property CurrentReduction: TReduction read GetCurrentReduction write SetCurrentReduction;
	GpReduction *GetCurrentReduction() const {
		//-- if FHaveReduction then Result := FStack.Top.Reduction
		//-- else Result := nil;
		if(FHaveReduction) 
			return FStack->Top()->GetReduction();
		return 0;
	};
	void SetCurrentReduction(GpReduction *Value) {
		//-- if FHaveReduction then FStack.Top.Reduction := NewReduction;
		if(FHaveReduction) 
			FStack->Top()->SetReduction(Value);
	};

	// Returns the current line in the source text.
    //-- property CurrentLineNumber: Integer read FLineNumber;
	int GetCurrentLineNumber() const {
		return FLineNumber;
	};

    // Returns the token that is ready to be parsed by the engine.
    // This property is only valid when when the gpMsgTokenRead message is
    // returned from the Parse method.
	//-- property CurrentToken: TToken read GetCurrentToken;
	GpToken *GetCurrentToken() const {
		//-- Result := FInputTokens.Top;
		return FInputTokens->Top();
	};
	
	//-- property VariableList : TVariableList read FVariableList;
	GpVariableList *GetVariableList() {
		return FVariableList;
	};

	// Returns the parser's internal Symbol Table.
    //-- property SymbolTable : TSymbolTable read FSymbolTable;
	GpSymbolTable *GetSymbolTable() {
		return FSymbolTable;
	};

    //-- property CharacterSetTable : TStringList read FCharacterSetTable;
	wxArrayString &GetCharacterSetTable() {
		return FCharacterSetTable;
	};

	// Returns the parser's Rule Table
    //-- property RuleTable : TRuleTable read FRuleTable;
	GpRuleTable *GetRuleTable() {
		return FRuleTable;
	};

	//-- property DFA : TFStateTable read FDFA;
	GpFStateTable *GetDFA() {
		return FDFA;
	};

    //-- property ActionTables : TLRActionTables read FActionTables;
	GpLRActionTables *GetActionTables() {
		return FActionTables;
	};

    //-- property InitialDFAState : integer read FInitialDFAState write FInitialDFAState;
	int GetInitialDFAState() const {
		return FInitialDFAState;
	};
	void SetInitialDFAState(int Value) {
		FInitialDFAState = Value;
	};
    
	//-- property InitialLALRState : integer read FInitialLALRState write FInitialLALRState;
	int GetInitialLALRState() const {
		return FInitialLALRState;
	};
	void SetInitialLALRState(int Value) {
		FInitialLALRState = Value;
	};

	// Returns the token Table.
    //-- property TokenTable : TTokenStack read FTokens;
	GpTokenStack *GetTokenTable() {
		return FTokens;
	};
};

#endif
