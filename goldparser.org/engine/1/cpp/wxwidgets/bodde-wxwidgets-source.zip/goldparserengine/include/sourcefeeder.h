#ifndef __SOURCEFEEDER_HPP_
#define __SOURCEFEEDER_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

/*
'================================================================================
' Class Name:
'      SourceFeeder
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
 	  
*/

#include "strstream.h"

//--TSourceFeeder = class
class GpSourceFeeder
{
private:
	//-- FStream : TStringStream;
	GpStringStream FStream;

	//-- procedure SetText(const Value: string);
	//-- function GetText: string;
public:
    //-- constructor Create;
    GpSourceFeeder();

	//-- destructor Destroy; override;
	~GpSourceFeeder();

    //-- function ReadFromBuffer(Size: Integer; DiscardReadText: Boolean; ReturnAllText: Boolean): String;
	wxString ReadFromBuffer(size_t Size, bool DiscardReadText, bool ReturnAllText);

    //-- function Done: Boolean;
	bool Done() const {
		return FStream.GetPosition() >= FStream.GetSize();
	};

    //-- function ReadLine: String;
	wxString ReadLine();

    //-- property Text: string read GetText write SetText;
	void SetText(const wxString &Text);
	wxString GetText() const {
		//-- Result := Stream.DataString;
		return FStream.GetDataString();
	};

    //-- property Stream : TStringStream read FStream;
	//GpStringStream &GetStream() {
	//	return FStream;
	//};
};


#endif
