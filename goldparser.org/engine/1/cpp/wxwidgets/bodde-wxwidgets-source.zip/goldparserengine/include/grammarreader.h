#ifndef __GRAMMARREADER_HPP_
#define __GRAMMARREADER_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/variant.h>
#include <wx/stream.h>

#include <wx/dynarray.h>
WX_DECLARE_OBJARRAY(wxVariant, wxVariantArray);

#include "variables.h"
#include "symbol.h"
#include "rule.h"
#include "fastate.h"
#include "lraction.h"
#include "goldparser.h"

#define FHeader "GOLD Parser Tables/v1.0"

#define EntryContentEmpty   69
#define EntryContentInteger 73
#define EntryContentString  83
#define EntryContentBoolean 66
#define EntryContentByte    98

#define RecordIdParameters  80   //P
#define RecordIdTableCounts 84   //T
#define RecordIdInitial     73   //I
#define RecordIdSymbols     83   //S
#define RecordIdCharSets    67   //C
#define RecordIdRules       82   //R
#define RecordIdDFAStates   68   //D
#define RecordIdLRTables    76   //L
#define RecordIdComment     33   //!

//-- TGrammarReader = class
class wxGoldParser;
class GpGrammarReader 
{
private:
    //-- FBufferPos: Integer;
	long FBufferPos;

    //-- FBuffer: string;
	wxString FBuffer;

    //-- FCurrentRecord: Variant;
	//wxVariant FCurrentRecord;
	wxVariantArray FRecords;

    //-- FEntryPos: Integer;
	size_t FEntryPos;

    //-- FEntryCount: Integer;
	//int FEntryCount;

    //-- FStartSymbol: Integer;
	int FStartSymbol;

    //-- FParser : TGoldParser;
	wxGoldParser *FParser;
    
	//-- function ReadUniString: string;
	wxString ReadUniString();

    //-- function ReadInt16: Integer;
	int ReadInt16();

    //-- function ReadByte: Char;
	wxChar ReadByte();

    //-- function ReadEntry: Variant;
	wxVariant ReadEntry();

    //-- function OpenFile(const FileName: string): boolean;
	bool OpenFile(const wxString &FileName);

    //-- function OpenStream(const Stream : TStream) : boolean;
	bool OpenStream(wxInputStream &Stream);

protected:
    //-- function DoLoadTables : boolean;
	bool DoLoadTables();

public:
    //-- constructor Create(aParser : TGoldParser);
	GpGrammarReader(wxGoldParser *aParser);

    //-- destructor Destroy; override;
	~GpGrammarReader();

    //-- function GetNextRecord: Boolean;
	bool GetNextRecord();

    //-- function RetrieveNext: Variant;
	wxVariant RetrieveNext();

    //-- function LoadTables(const FileName : string): boolean; overload;
	bool LoadTables(const wxString &FileName);

    //-- function LoadTables(const Stream : TStream): boolean; overload;
	bool LoadTables(wxInputStream &Stream);

    //-- property Buffer: string read FBuffer;
	wxString GetBuffer() const {
		return FBuffer;
	};

    //-- property StartSymbol: Integer read FStartSymbol write FStartSymbol;
	int GetStartSymbol() const {
		return FStartSymbol;
	};
	void SetStartSymbol(int Value) {
		FStartSymbol = Value;
	};
    
	//-- property Parser : TGOLDParser read FParser;
	wxGoldParser *GetParser() {
		return FParser;
	};
};

#endif
