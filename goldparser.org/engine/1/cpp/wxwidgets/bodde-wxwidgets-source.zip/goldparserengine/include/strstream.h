#ifndef __STRSTREAM_HPP_
#define __STRSTREAM_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

enum
{
	// Offset is from the beginning of DataString. Seek moves to the position Offset. Offset must be >= 0.
	soFromBeginning	= 0,
	// Offset is from the current position. Seek moves to Position + Offset.
	soFromCurrent,
	// Offset is from the end of Memory. Offset must be <= 0 to indicate a number of bytes before the end of the DataString.
	soFromEnd
};

class GpStringStream
{
private:
	size_t FPosition;
	wxString FDataString;

public:
    GpStringStream();
    virtual ~GpStringStream();

	virtual int Read(void *Buffer, int Count);
	wxString ReadString(int Count);
	virtual int Seek(int Offset, int Origin);
	virtual int Write(const void *Buffer, int Count);
	void WriteString(const wxString &String);

	size_t GetPosition() const {
		return FPosition;
	};
	void SetPosition(size_t Position);

	size_t GetSize() const {
		return FDataString.Length();
	};

	wxChar GetCh();

	wxChar Peek() const;

	void SetDataString(const wxString &Value);

	void Empty();

	const wxString &GetDataString() const {
		return FDataString;
	};

private:
};


#endif
