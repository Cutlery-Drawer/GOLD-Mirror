#ifndef __RULE_HPP_
#define __RULE_HPP_

//-- unit Rule;

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

// declare the array class here
#include <wx/dynarray.h>

/*
'================================================================================
' Class Name:
'      Rule
'
' Instancing:
'      Public; Non-creatable  (VB Setting: 2- PublicNotCreatable)
'
' Purpose:
'      The Rule class is used to represent the logical structures of the grammar.
'      Rules consist of a head containing a nonterminal followed by a series of
'      both nonterminals and terminals.
'
' Author(s):
'      Devin Cook
'      GOLDParser@DevinCook.com
'
' Dependacies:
'      Symbol Class, SymbolList Class
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl
 */

#include "symbol.h"

//-- TRule = class
class GpRule
{
private:
	//-- FRuleNonterminal: TSymbol;
	GpSymbol *FRuleNonterminal;

	//-- FRuleSymbols: TObjectList;
	GpSymbolArray FRuleSymbols;

	//-- FTableIndex: Integer;
	int FTableIndex;

	//-- function GetSymbolCount: Integer;
	//-- function GetNonterminal: TSymbol;
	//-- function GetSymbols(Index: Integer): TSymbol;
public:
	//-- constructor Create(aTableIndex : integer; aNonTerminal : TSymbol);
	GpRule(int aTableIndex, GpSymbol * aNonTerminal);

	//-- destructor Destroy; override;
	~GpRule();

	//-- procedure AddItem(Item: TSymbol);
	void AddItem(GpSymbol *Item );

	//-- function Name: string;
	wxString GetName() const {
		//-- Result := '<' + FRuleNonterminal.Name + '>';

		wxCHECK(FRuleNonterminal, wxEmptyString);
		wxString Result;
		Result << "<" << FRuleNonterminal->GetName() << ">";

		return Result;
	};

	//-- function Definition: string;
	wxString GetDefinition() const;

	//-- function ContainsOneNonTerminal: Boolean;
	bool ContainsOneNonTerminal();

	// Returns the Backus-Noir representation of the rule.

	//-- function Text: String;
	wxString GetText() const {
		//-- Result := Name + ' ::= ' + Definition;

		wxString Result;
		Result << GetName() << " ::= " << GetDefinition();

		return Result;
	};

	// Returns the number of symbols that consist the body (right-hand-side) of the rule.

	//-- property SymbolCount: Integer read GetSymbolCount;
	size_t GetSymbolCount() const {
		//-- Result := FRuleSymbols.Count;
		return FRuleSymbols.GetCount();
	};

	// Returns the head symbol of the rule.

	//-- property RuleNonterminal: TSymbol read GetNonterminal;
	GpSymbol *GetNonterminal() const {
		//-- Result := FRuleNonterminal;
		return FRuleNonterminal;
	};

	// Returns the index of the rule in the GOLDParser object's Rule Table.

	//-- property TableIndex: Integer read FTableIndex;
	int GetTableIndex() const {
		return FTableIndex;
	};

	// Returns one of the symbols that consist the body of the rule.
	// The index of the symbol ranges from 0 to SymbolCount -1

	//-- property Symbols[Index: Integer]: TSymbol read GetSymbols;
	GpSymbol *GetSymbols(int Index) const {
		//-- Result := FRuleSymbols[Index] as TSymbol;
		return FRuleSymbols[Index];
	};
};

WX_DEFINE_ARRAY(GpRule *, GpRuleArray);

//-- TRuleTable = class
class GpRuleTable
{
private:
	//-- FList : TObjectList;
	GpRuleArray FList;

	//-- function GetCount: integer;
	//-- function GetItem(Index: integer): TRule;
	//-- procedure SetItem(Index: integer; const Value: TRule);
public:
	//-- constructor Create;
	GpRuleTable();

	//-- destructor Destroy; override;
	~GpRuleTable();

	//-- procedure Add(Value : TObject);
	void Add(GpRule *Value);

	//-- procedure Clear;
	void Clear();

	//-- property Count : integer read GetCount;
	size_t GetCount() const {
		//-- Result := FList.Count;
		return FList.GetCount();
	};

	//-- property Items[Index : integer] : TRule read GetItem write SetItem; default;
	void SetItem(GpRule *Item, size_t Index);
	GpRule *GetItem(int Index) const {
		//-- Result := FList[Index] as TRule;
		return FList[Index];
	};

};

#endif
