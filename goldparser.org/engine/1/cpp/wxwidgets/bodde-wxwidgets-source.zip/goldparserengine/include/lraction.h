
#ifndef __LRACTION_HPP_
#define __LRACTION_HPP_

//#ifdef __GNUG__
//    // tell GCC this class is 'interface only' this means
//    // inline expansion is expanded at compile point
//    #pragma interface
//#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/dynarray.h>

/*
'================================================================================
' Class Name:
'      LRAction
'
' Instancing:
'      Private; Internal  (VB Setting: 1 - Private)
'
' Purpose:
'      This class represents an action in a LALR State. There is one and only one
'      action for any given symbol.
'
' Author(s):
'      Devin Cook
'      GOLDParser@DevinCook.com
'
' Dependacies:
'      (None)
'
'================================================================================
 Conversion to Delphi:
      Beany
      Beany@cloud.demon.nl
 Conversion to wxWidgets C++:
 	  Jorgen Bodde
 	  jorgb@xs4all.nl

*/

#include "symbol.h"

#define GpActionShift  1      //Shift a symbol and goto a state
#define GpActionReduce 2      //Reduce by a specified rule
#define GpActionGoto   3      //Goto to a state on reduction
#define GpActionAccept 4      //Input successfully parsed
#define GpActionError  5      //Programmars see this often!

//-- TLRAction = class
class GpLRAction
{
private:
    //-- FSymbol: TSymbol;
	GpSymbol *FSymbol;
    //-- FAction: Integer;
	int FAction;
    //-- FValue: Integer;
	int FValue;
    //-- function GetSymbol: TSymbol;
    //-- function GetSymbolIndex: Integer;
public:
	GpLRAction(GpSymbol *Symbol, int Action, int Value);
	
	//-- property Value: Integer read FValue;
	int GetValue() const {
		return FValue;
	};
    
	//-- property Action: Integer read FAction;
	int GetAction() const {
		return FAction;
	};

    //-- property Symbol: TSymbol read GetSymbol;
	GpSymbol *GetSymbol() const {
		//-- Result := FSymbol;
		return FSymbol;
	};

    //-- property SymbolIndex: Integer read GetSymbolIndex;
	int GetSymbolIndex() const {
		//-- Result := FSymbol.TableIndex;
		wxCHECK(FSymbol, -1);
		return FSymbol->GetTableIndex();
	};
};

WX_DEFINE_ARRAY(GpLRAction *, GpLRActionArray);

//-- TLRActionTable = class
class GpLRActionTable
{
private:
    //-- FList : TObjectList;
	GpLRActionArray FList;

    //-- function GetCount: integer;
    //-- function GetItem(Index: integer): TLRAction;
    //-- procedure SetItem(Index: integer; const Value: TLRAction);
public:
    //-- constructor Create;
	GpLRActionTable();

    //-- destructor Destroy; override;
	~GpLRActionTable();

    //-- procedure Add(TheSymbol: TSymbol; Action: Integer; Value: Integer);
	void Add(GpSymbol *TheSymbol, int Action, int Value);

    //-- function ActionIndexForSymbol(SymbolIndex: Integer): Integer;
	int ActionIndexForSymbol(int SymbolIndex);

    //-- property Count : integer read GetCount;
	size_t GetCount() const {
		//-- Result := FList.Count;
		return FList.GetCount();
	};

    //-- property Items[Index : integer] : TLRAction read GetItem write SetItem; default;
	GpLRAction  *GetItem(int Index) const {
		//-- Result := FList[Index] as TLRAction;
		return FList[Index];
	};
	void SetItem(GpLRAction *Value, size_t Index);
};

WX_DEFINE_ARRAY(GpLRActionTable *, GpLRActionTableArray);

//-- TLRActionTables = class
class GpLRActionTables
{
private:
    //-- FList : TObjectList;
	GpLRActionTableArray FList;

    //-- function GetCount: integer;
    //-- function GetItem(Index: integer): TLRActionTable;
    //-- procedure SetItem(Index: integer; const Value: TLRActionTable);
public:
    //-- constructor Create;
	GpLRActionTables();

    //-- destructor Destroy; override;
	~GpLRActionTables();

    //-- property Count : integer read GetCount;
	size_t GetCount() const {
		//-- Result := FList.Count;
		return FList.GetCount();
	};

    //-- property Items[Index : integer] : TLRActionTable read GetItem write SetItem; default;
	GpLRActionTable *GetItem(int Index) const {
		//-- Result := FList[Index] as TLRActionTable;
		return FList[Index];
	};
	void SetItem(GpLRActionTable *Value, size_t Index);
};

#endif
